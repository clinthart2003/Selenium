# -*- coding: utf-8 -*-
# --------------------------------------------------------------------------------------------------
# ThreatQuotient Proprietary and Confidential
# Copyright ©2016 ThreatQuotient, Inc. All rights reserved.
#
# NOTICE: All information contained herein, is, and remains the property of ThreatQuotient, Inc.
# The intellectual and technical concepts contained herein are proprietary to ThreatQuotient, Inc.
# and its suppliers and may be covered by U.S. and Foreign Patents, patents in process, and are
# protected by trade secret or copyright law.
#
# Dissemination of this information or reproduction of this material is strictly forbidden unless
# prior written permission is obtained from ThreatQuotient, Inc.
# --------------------------------------------------------------------------------------------------

import json

from aiohttp import HttpProcessingError

from threatq.core.lib.http import ClientResponse
from threatq.core.lib.http.auth import HMACAuth
from threatq.core.lib.markup import (
    ActionParam,
    Accordion,
    Button,
    Column,
    Heading,
    Info,
    MultiMarkup,
    Paragraph,
    PreformattedText,
    Table,
)
from threatq.core.lib.plugins import APIPluginResponse, HTTPAPIPlugin, action
from threatq.core.lib.utils import parse_fqdn


class ConsoleUtils(HTTPAPIPlugin):
    """Enrichment data made available by the Linux console"""

    entry_points = ('consoleutils',)
    user_field_spec = [
        'api_username',
        {
            'name': 'api_key',
            'mask': True,
        },
    ]
    friendly_name = 'Console Utils'
    external_endpoints = ['http://localhost']
    version = '1.0.0'
    logo = 'http://www.omgubuntu.co.uk/wp-content/uploads/2016/09/terminal-icon.png'
    status_text_overrides = {
        503: 'Rate limit reached, please try again later.',
    }

    def setup(self):
        pass

    @action(
        accepts={'indicator': ['FQDN']},
        help='Nslookup'
    )
    async def nslookup(self, indicator):

        import socket
        res = socket.gethostbyname(indicator['value'])
        add_without_attrs_button = Button(
            label='Add Indicators',
            action='add',
            object_type='indicator',
            action_params=dict(
                type='IP Address',
                value=Column(0),
            ),
        )
        markup = Table(
            title='Resolved IP Addresses',
            headings=['Value'],
            rows=[[res]],
            buttons=[add_without_attrs_button],
        )

        return APIPluginResponse(data=res, markup=markup)

    @action(
        accepts={'indicator': ['FQDN','IP Address']},
        help='Dig'
    )
    async def dig(self, indicator):
        import subprocess
        import shlex
        import re

        add_without_attrs_button = Button(
            label='Add Indicators',
            action='add',
            object_type='indicator',
            action_params=dict(
                type='IP Address',
                value=Column(0),
            ),
        )

        add_without_attrs_button_fqdn = Button(
            label='Add Indicators',
            action='add',
            object_type='indicator',
            action_params=dict(
                type='FQDN',
                value=Column(0),
            ),
        )

        if indicator['type']['name'] == "IP Address":
            cmd='dig -x %s' % indicator['value']
        else:
            cmd='dig %s ANY +answer' % indicator['value']

        proc=subprocess.Popen(shlex.split(cmd),stdout=subprocess.PIPE)
        out,err=proc.communicate()

        out = out.decode('utf-8')
        
        ips = []
        mxs =[]
        nss =[]
        txt = []
        soa = []
        fqdns = []

        trip = False
        did = False
        for r in out.split('\n'):
            r = re.sub(r"\t+","&",r)
            r = r.lstrip()
            if r.find(';') == 0 or not r:
                continue

            r = re.sub(r" ","&",r)
            line = r.split('&')

            if not line or len(line) < 3:
                continue

            if line[3] == 'A':
                if not indicator['type']['name'] == "IP Address":
                    ips.append(line[4])
            elif line[3] == 'MX':
                mxs.append(line[4].rstrip('.'))
            elif line[3] == 'NS':
                nss.append(line[4].rstrip('.'))
            elif line[3] == 'TXT':
                txt.append(line[4])
            elif line[3] == 'SOA':
                soa.append(line[4])
            elif line[3] == 'PTR':
                fqdns.append(line[4].rstrip('.'))

        markup = MultiMarkup()
        markup.append(Heading('Dig Results'))
        markup.append(Paragraph("Command ran: %s" % cmd))
        
        if len(ips):
            resolvedmarkup = Table(
                title='Resolved IP Addresses',
                headings=['Value'],
                rows=[[x] for x in ips],
                buttons=[add_without_attrs_button],
            )
            markup.append(resolvedmarkup)

        if len(fqdns):
            resolvedmarkup = Table(
                title='Resolved Domain Addresses',
                headings=['Value'],
                rows=[[x] for x in fqdns],
                buttons=[add_without_attrs_button_fqdn],
            )
            markup.append(resolvedmarkup)

        if len(nss):
            nsmarkup = Table(
                title='Nameservers',
                headings=['Value'],
                rows=[[x] for x in nss],
                buttons=[add_without_attrs_button_fqdn],
            )
            markup.append(nsmarkup)

        if len(mxs):
            mxmarkup = Table(
                title='Mail Servers',
                headings=['Value'],
                rows=[[x] for x in mxs],
                buttons=[add_without_attrs_button_fqdn],
            )
            markup.append(mxmarkup)
        
        if len(soa):
            markup.append(PreformattedText('\n'.join(soa),title='SOA'))

        if len(txt):
            markup.append(PreformattedText('\n'.join(txt),title='TXT'))
        
        markup.append(Accordion(content=PreformattedText(out), title="Raw Response"))

        return APIPluginResponse(data=None, markup=markup)
