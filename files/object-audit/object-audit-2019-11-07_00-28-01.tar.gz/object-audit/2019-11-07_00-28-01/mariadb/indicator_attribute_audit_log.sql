-- MySQL dump 10.16  Distrib 10.3.9-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: threatquotient2
-- ------------------------------------------------------
-- Server version	10.3.9-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `indicator_attribute_audit_log`
--

DROP TABLE IF EXISTS `indicator_attribute_audit_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `indicator_attribute_audit_log` (
  `indicator_attribute_id` int(10) unsigned NOT NULL,
  `event_type` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `attribute_id` int(10) unsigned NOT NULL,
  `new_value` text COLLATE utf8_unicode_ci NOT NULL,
  `run_uuid` binary(16) DEFAULT NULL,
  `changed_by_source_id` int(10) unsigned DEFAULT NULL,
  `changed_at` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  PRIMARY KEY (`indicator_attribute_id`,`changed_at`,`attribute_id`),
  KEY `indicator_attribute_audit_log_indicator_attribute_id_index` (`indicator_attribute_id`),
  KEY `indicator_attribute_audit_log_event_type_index` (`event_type`),
  KEY `indicator_attribute_audit_log_attribute_id_index` (`attribute_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `indicator_attribute_audit_log`
--
-- WHERE:  `indicator_attribute_id` in (SELECT id FROM `object_audit_id_lookup` WHERE key_column = 'indicator_attribute_id')

LOCK TABLES `indicator_attribute_audit_log` WRITE;
/*!40000 ALTER TABLE `indicator_attribute_audit_log` DISABLE KEYS */;
INSERT  IGNORE INTO `indicator_attribute_audit_log` VALUES (41304,'added',36,'NCCIC:Observable-843e9509-7a42-4b0b-a3d8-1ea9039de35f',NULL,8,'2019-11-07 00:22:03.759'),(41305,'added',36,'NCCIC:Package-bdcfb4e2-af52-47f1-a625-318ddf67cc29',NULL,8,'2019-11-07 00:22:03.772'),(41307,'added',36,'NCCIC:URI-62ce3219-de20-4416-995d-7e8f23d62653',NULL,8,'2019-11-07 00:22:03.784'),(41309,'added',57,'The victim was redacted from the URI address. The domain, wufoo.com is a legitimate online form service owned by SurveyMonkey.',NULL,8,'2019-11-07 00:22:03.796'),(40636,'added',36,'NCCIC:URI-e1e7bbbf-981e-409c-a4f8-f6a747ccbd7d',NULL,8,'2019-11-07 00:21:40.299'),(40638,'added',57,'Connects to \"www.imageliners.com/nitel\"',NULL,8,'2019-11-07 00:21:40.313'),(40640,'added',36,'NCCIC:Observable-7fe33c63-e41b-4129-a50e-9ef83645b719',NULL,8,'2019-11-07 00:21:40.323'),(40642,'added',36,'NCCIC:Package-c52b3a4a-4191-446b-845a-c621367ad123',NULL,8,'2019-11-07 00:21:40.335'),(9555,'added',75,'URL Watchlist',NULL,8,'2019-11-07 00:08:55.233'),(9556,'added',57,'According to a trusted third party, this is a payload URL.',NULL,8,'2019-11-07 00:08:55.237'),(9557,'added',36,'NCCIC:Object-f135be0c-cf94-11e7-83dd-0050569c6b2d',NULL,8,'2019-11-07 00:08:55.241'),(9558,'added',36,'indicator-f135be0b-cf94-11e7-a71f-0050569c6b2d',NULL,8,'2019-11-07 00:08:55.245'),(9559,'added',36,'IB-17-20294A',NULL,8,'2019-11-07 00:08:55.249'),(9560,'added',36,'NCCIC:Observable-6973ec32-6138-494f-95aa-45b5c6e2094e',NULL,8,'2019-11-07 00:08:55.253'),(9561,'added',77,'Malicious URL Indicator',NULL,8,'2019-11-07 00:08:55.257'),(9562,'added',44,'Delivery',NULL,8,'2019-11-07 00:08:55.261'),(9563,'added',1,'https',NULL,8,'2019-11-07 00:08:55.265'),(9564,'added',2,'authuser=0&id=17HxItEeUg2cdIsg3VnMPqhUe5yEc5bgr',NULL,8,'2019-11-07 00:08:55.269'),(9610,'added',36,'NCCIC:Observable-971c8ecd-dbe6-47bf-b3f4-67f4f3c56082',NULL,8,'2019-11-07 00:08:55.471'),(9611,'added',36,'indicator-f135bdf0-cf94-11e7-bb9f-0050569c6b2d',NULL,8,'2019-11-07 00:08:55.475'),(9612,'added',36,'NCCIC:Object-f135bdf1-cf94-11e7-b364-0050569c6b2d',NULL,8,'2019-11-07 00:08:55.479'),(9613,'added',2,'authuser=0&id=14HDwZSKvR0fD_iv6nadCSm7LKv19MlC0',NULL,8,'2019-11-07 00:08:55.498'),(9623,'added',36,'NCCIC:Observable-19cf347d-0aad-454e-a3e8-727801fc3c3e',NULL,8,'2019-11-07 00:08:55.546'),(9624,'added',36,'NCCIC:Object-f135bdf4-cf94-11e7-ab96-0050569c6b2d',NULL,8,'2019-11-07 00:08:55.554'),(9625,'added',36,'indicator-f135bdf3-cf94-11e7-a318-0050569c6b2d',NULL,8,'2019-11-07 00:08:55.558'),(9626,'added',2,'authuser=0&id=1izsHmAct9vptBXTuRSOqGDBjj-0yOWSt',NULL,8,'2019-11-07 00:08:55.577'),(9627,'added',36,'NCCIC:Object-f135be06-cf94-11e7-bbb0-0050569c6b2d',NULL,8,'2019-11-07 00:08:55.585'),(9628,'added',36,'indicator-f135be05-cf94-11e7-9867-0050569c6b2d',NULL,8,'2019-11-07 00:08:55.593'),(9629,'added',36,'NCCIC:Observable-d983e01a-3b5b-4417-a75f-62a88b4f733b',NULL,8,'2019-11-07 00:08:55.608'),(9630,'added',2,'authuser=0&id=1oquCzJxsv0EeuvSca4r31k07asN2_pp4',NULL,8,'2019-11-07 00:08:55.616'),(9658,'added',36,'NCCIC:Observable-6004495d-1b5e-4a57-b7c6-29b562e7de79',NULL,8,'2019-11-07 00:08:55.748'),(9659,'added',36,'indicator-f135be02-cf94-11e7-a38a-0050569c6b2d',NULL,8,'2019-11-07 00:08:55.757'),(9660,'added',36,'NCCIC:Object-f135be03-cf94-11e7-bd51-0050569c6b2d',NULL,8,'2019-11-07 00:08:55.761'),(9661,'added',2,'authuser=0&id=1WegQDVKPDTdUB-gp4yqGqGcNPCVt6LHz',NULL,8,'2019-11-07 00:08:55.776'),(9721,'added',36,'indicator-f135bdf6-cf94-11e7-97d6-0050569c6b2d',NULL,8,'2019-11-07 00:08:56.029'),(9722,'added',36,'NCCIC:Observable-b6bf4e52-b40e-4f18-9a18-112fc1032f49',NULL,8,'2019-11-07 00:08:56.041'),(9723,'added',36,'NCCIC:Object-f135bdf7-cf94-11e7-be5a-0050569c6b2d',NULL,8,'2019-11-07 00:08:56.045'),(9724,'added',2,'authuser=0&id=1eMK86QEeKfnpWH_TkfPVJRGPRk6YxI7D',NULL,8,'2019-11-07 00:08:56.060'),(9743,'added',36,'NCCIC:Object-f135bdfd-cf94-11e7-83cb-0050569c6b2d',NULL,8,'2019-11-07 00:08:56.148'),(9744,'added',36,'indicator-f135bdfc-cf94-11e7-ad54-0050569c6b2d',NULL,8,'2019-11-07 00:08:56.157'),(9745,'added',36,'NCCIC:Observable-d12b46b2-f76a-475e-a64a-5cf6286e363d',NULL,8,'2019-11-07 00:08:56.161'),(9746,'added',2,'authuser=0&id=108Zu3Xx7yMIzqolAUuXLryhbnXkygm4y',NULL,8,'2019-11-07 00:08:56.173'),(9747,'added',36,'indicator-f135bdff-cf94-11e7-89c2-0050569c6b2d',NULL,8,'2019-11-07 00:08:56.180'),(9748,'added',36,'NCCIC:Observable-fb1d1e94-4c2e-4770-9816-15f94ba82bd2',NULL,8,'2019-11-07 00:08:56.188'),(9749,'added',36,'NCCIC:Object-f135be00-cf94-11e7-927b-0050569c6b2d',NULL,8,'2019-11-07 00:08:56.198'),(9750,'added',2,'authuser=0&id=1ssfADbXZy8Xydz92GYE8wB1ZedQrjSDj',NULL,8,'2019-11-07 00:08:56.214'),(9751,'added',36,'NCCIC:Object-f135be09-cf94-11e7-8c10-0050569c6b2d',NULL,8,'2019-11-07 00:08:56.222'),(9752,'added',36,'indicator-f135be08-cf94-11e7-bc32-0050569c6b2d',NULL,8,'2019-11-07 00:08:56.226'),(9753,'added',36,'NCCIC:Observable-2ae8cde4-5b8f-40e5-882f-f56bf74b7cea',NULL,8,'2019-11-07 00:08:56.234'),(9754,'added',2,'authuser=0&id=188a48hkZoADY_w_dg_9dVVxdfaK7ZD-I',NULL,8,'2019-11-07 00:08:56.254'),(9764,'added',36,'NCCIC:Object-f135bdfa-cf94-11e7-8a5b-0050569c6b2d',NULL,8,'2019-11-07 00:08:56.304'),(9765,'added',36,'NCCIC:Observable-b45fcbaf-0dac-4fa3-b55d-1b16bb2492ed',NULL,8,'2019-11-07 00:08:56.317'),(9766,'added',36,'indicator-f135bdf9-cf94-11e7-a08f-0050569c6b2d',NULL,8,'2019-11-07 00:08:56.321'),(9767,'added',2,'authuser=0&id=1e1Jx_g6VvsgClWE4KsA69gGTtYf4bcrv',NULL,8,'2019-11-07 00:08:56.340');
/*!40000 ALTER TABLE `indicator_attribute_audit_log` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-11-07  0:28:01
