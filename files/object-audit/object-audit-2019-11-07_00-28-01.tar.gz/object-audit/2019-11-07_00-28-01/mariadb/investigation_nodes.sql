-- MySQL dump 10.16  Distrib 10.3.9-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: threatquotient2
-- ------------------------------------------------------
-- Server version	10.3.9-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `investigation_nodes`
--

DROP TABLE IF EXISTS `investigation_nodes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `investigation_nodes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `investigation_id` int(10) unsigned NOT NULL,
  `viewpoint_id` int(10) unsigned DEFAULT NULL,
  `object_id` int(10) unsigned NOT NULL,
  `object_type` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `label` text COLLATE utf8_unicode_ci NOT NULL,
  `x` int(11) DEFAULT NULL,
  `y` int(11) DEFAULT NULL,
  `created_at` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `updated_at` datetime(3) NOT NULL DEFAULT current_timestamp(3) ON UPDATE current_timestamp(3),
  PRIMARY KEY (`id`),
  KEY `investigation_nodes_investigation_id_index` (`investigation_id`),
  KEY `investigation_nodes_viewpoint_id_index` (`viewpoint_id`),
  KEY `investigation_nodes_object_id_index` (`object_id`),
  KEY `investigation_nodes_object_type_index` (`object_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `investigation_nodes`
--
-- WHERE:  `object_type` = 'indicator' AND `object_id` IN (SELECT id FROM `object_audit_id_lookup` WHERE key_column = 'indicator_id')

LOCK TABLES `investigation_nodes` WRITE;
/*!40000 ALTER TABLE `investigation_nodes` DISABLE KEYS */;
/*!40000 ALTER TABLE `investigation_nodes` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`threatquotient`@`localhost`*/ /*!50003 TRIGGER trig_investigation_nodes_after_insert AFTER INSERT ON investigation_nodes
FOR EACH ROW BEGIN

  INSERT INTO object_relations (object_type, object_id, relation_type, relation_ids_json)
  VALUES
    ('investigation', NEW.investigation_id, NEW.object_type, JSON_ARRAY(NEW.object_id))
  ON DUPLICATE KEY UPDATE
    relation_ids_json = IF(
      relation_ids_json <> '[]' AND NOT JSON_CONTAINS(relation_ids_json, JSON_EXTRACT(VALUES(relation_ids_json), '$[0]')),
      JSON_ARRAY_APPEND(relation_ids_json, '$', JSON_EXTRACT(VALUES(relation_ids_json), '$[0]')),
      IF(relation_ids_json = '[]', JSON_ARRAY(NEW.object_id), VALUES(relation_ids_json))
    );

  INSERT INTO object_relations (object_type, object_id, relation_type, relation_ids_json)
  VALUES
    (NEW.object_type, NEW.object_id, 'investigation', JSON_ARRAY(NEW.investigation_id))
  ON DUPLICATE KEY UPDATE
    relation_ids_json = IF(
        relation_ids_json <> '[]' AND NOT JSON_CONTAINS(relation_ids_json, JSON_EXTRACT(VALUES(relation_ids_json), '$[0]')),
        JSON_ARRAY_APPEND(relation_ids_json, '$', JSON_EXTRACT(VALUES(relation_ids_json), '$[0]')),
        IF(relation_ids_json = '[]', JSON_ARRAY(NEW.investigation_id), VALUES(relation_ids_json))
    );

END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`threatquotient`@`localhost`*/ /*!50003 TRIGGER trig_investigation_nodes_after_delete AFTER DELETE ON investigation_nodes
FOR EACH ROW BEGIN

  DECLARE srcRemove VARCHAR(32);
  DECLARE destRemove VARCHAR(32);

  DELETE FROM
    investigation_node_properties
  WHERE
    node_id = OLD.id;

  SELECT
    JSON_SEARCH(relation_ids_json, 'one', OLD.investigation_id) INTO srcRemove
  FROM
    object_relations
  WHERE
    object_type = OLD.object_type AND
    object_id = OLD.object_id AND
    relation_type = 'investigation';

  IF IFNULL(srcRemove, '') <> ''
  THEN
    UPDATE
      object_relations
    SET
      relation_ids_json = JSON_REMOVE(relation_ids_json, JSON_UNQUOTE(srcRemove))
    WHERE
      object_type = OLD.object_type AND
      object_id = OLD.object_id AND
      relation_type = 'investigation';
  END IF;

  SELECT
    JSON_SEARCH(relation_ids_json, 'one', OLD.object_id) INTO destRemove
  FROM
    object_relations
  WHERE
    object_type = 'investigation' AND
    object_id = OLD.investigation_id AND
    relation_type = OLD.object_type;

  IF IFNULL(destRemove, '') <> ''
  THEN
    UPDATE
      object_relations
    SET
      relation_ids_json = JSON_REMOVE(relation_ids_json, JSON_UNQUOTE(destRemove))
    WHERE
      object_type = 'investigation' AND
      object_id = OLD.investigation_id AND
      relation_type = OLD.object_type;
  END IF;

END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-11-07  0:28:03
