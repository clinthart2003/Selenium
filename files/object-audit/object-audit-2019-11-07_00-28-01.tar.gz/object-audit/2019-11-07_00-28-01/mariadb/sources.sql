-- MySQL dump 10.16  Distrib 10.3.9-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: threatquotient2
-- ------------------------------------------------------
-- Server version	10.3.9-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `sources`
--

DROP TABLE IF EXISTS `sources`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sources` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `origin_id` int(10) unsigned NOT NULL,
  `reference_id` int(10) unsigned NOT NULL,
  `type` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `expire_days` smallint(6) DEFAULT NULL,
  `expires_needs_calc` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `score` int(11) DEFAULT NULL,
  `default_tlp_id` int(10) unsigned DEFAULT NULL,
  `created_at` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `updated_at` datetime(3) NOT NULL DEFAULT current_timestamp(3) ON UPDATE current_timestamp(3),
  `deleted_at` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_index` (`type`,`reference_id`),
  KEY `sources_origin_id_index` (`origin_id`),
  KEY `sources_reference_id_index` (`reference_id`),
  KEY `sources_updated_at_index` (`updated_at`),
  KEY `sources_expires_needs_calc_index` (`expires_needs_calc`),
  KEY `sources_default_tlp_id_index` (`default_tlp_id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sources`
--

LOCK TABLES `sources` WRITE;
/*!40000 ALTER TABLE `sources` DISABLE KEYS */;
INSERT  IGNORE INTO `sources` VALUES (1,0,1,'clients','ThreatQ Front End',NULL,'N',NULL,NULL,'2019-03-26 18:21:27.000','2019-03-26 18:21:27.000',NULL),(2,0,2,'clients','ThreatQ API',NULL,'N',NULL,NULL,'2019-03-26 18:21:27.000','2019-03-26 18:21:27.000',NULL),(3,0,3,'clients','ThreatQ Process Cop',NULL,'N',NULL,NULL,'2019-03-26 18:21:27.000','2019-03-26 18:21:27.000',NULL),(4,0,4,'clients','ThreatQ Scoring Plugin Access',NULL,'N',NULL,NULL,'2019-03-26 18:21:27.000','2019-03-26 18:21:27.000',NULL),(5,0,1,'plugins','Domain Tools',NULL,'N',NULL,NULL,'2019-03-26 18:21:42.000','2019-03-26 18:21:42.000',NULL),(6,0,2,'plugins','Emerging Threats',NULL,'N',NULL,NULL,'2019-03-26 18:21:45.000','2019-03-26 18:21:45.000',NULL),(7,0,3,'plugins','VirusTotal',NULL,'N',NULL,NULL,'2019-03-26 18:21:48.000','2019-03-26 18:21:48.000',NULL),(8,0,1,'users','threatq@threatq.com',NULL,'N',NULL,NULL,'2019-11-06 22:51:20.000','2019-11-06 22:51:20.000',NULL),(9,0,1,'other_sources','JohnnyU',NULL,'N',NULL,NULL,'2019-11-06 23:31:33.942','2019-11-06 23:31:33.942',NULL),(10,0,2,'other_sources','FireEye 484650703',NULL,'N',NULL,NULL,'2019-11-06 23:40:07.225','2019-11-06 23:40:07.225',NULL),(11,0,3,'other_sources','FireEye 484638868',NULL,'N',NULL,NULL,'2019-11-06 23:40:07.225','2019-11-06 23:40:07.225',NULL),(12,0,4,'other_sources','FireEye 1694305',NULL,'N',NULL,NULL,'2019-11-06 23:40:46.274','2019-11-06 23:40:46.274',NULL),(13,0,5,'other_sources','FireEye 1694304',NULL,'N',NULL,NULL,'2019-11-06 23:40:46.274','2019-11-06 23:40:46.274',NULL),(14,0,6,'other_sources','FireEye 65807620',NULL,'N',NULL,NULL,'2019-11-06 23:41:26.290','2019-11-06 23:41:26.290',NULL),(15,0,2,'users','Super@threatq.com',NULL,'N',NULL,NULL,'2019-11-06 23:49:16.000','2019-11-06 23:49:16.000',NULL),(16,0,3,'users','admin@threatq.com',NULL,'N',NULL,NULL,'2019-11-06 23:49:36.000','2019-11-06 23:49:36.000',NULL),(17,0,4,'users','Analyst@threatq.com',NULL,'N',NULL,NULL,'2019-11-06 23:49:56.000','2019-11-06 23:49:56.000',NULL),(18,0,5,'users','Observer@threatq.com',NULL,'N',NULL,NULL,'2019-11-06 23:50:17.000','2019-11-06 23:50:17.000',NULL),(19,0,4,'connectors','abuse.ch SSLBL IP Blacklist',NULL,'N',NULL,NULL,'2019-11-07 00:10:00.000','2019-11-07 00:10:00.000',NULL),(20,0,8,'connectors','abuse.ch URLhaus Collected Payloads',NULL,'N',NULL,NULL,'2019-11-07 00:10:05.000','2019-11-07 00:10:05.000',NULL),(21,0,19,'connectors','Bambenek Consulting - Corebot Master',NULL,'N',NULL,NULL,'2019-11-07 00:10:10.000','2019-11-07 00:10:10.000',NULL),(22,0,29,'connectors','Bambenek Consulting - Kraken Master',NULL,'N',NULL,NULL,'2019-11-07 00:10:15.000','2019-11-07 00:10:15.000',NULL),(23,0,83,'connectors','Emerging Threats Compromised IPs',NULL,'N',NULL,NULL,'2019-11-07 00:10:21.000','2019-11-07 00:10:21.000',NULL),(24,0,86,'connectors','hpHosts FQDN',NULL,'N',NULL,NULL,'2019-11-07 00:10:26.000','2019-11-07 00:10:26.000',NULL),(25,0,88,'connectors','malc0de Domain',NULL,'N',NULL,NULL,'2019-11-07 00:10:31.000','2019-11-07 00:10:31.000',NULL),(26,0,89,'connectors','malc0de IP',NULL,'N',NULL,NULL,'2019-11-07 00:10:36.000','2019-11-07 00:10:36.000',NULL),(27,0,90,'connectors','Malware Domain List',NULL,'N',NULL,NULL,'2019-11-07 00:10:41.000','2019-11-07 00:10:41.000',NULL),(28,0,91,'connectors','Malware Domain List (Delisted)',NULL,'N',NULL,NULL,'2019-11-07 00:10:46.000','2019-11-07 00:10:46.000',NULL);
/*!40000 ALTER TABLE `sources` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`threatquotient`@`localhost`*/ /*!50003 TRIGGER trig_sources_before_insert BEFORE INSERT ON sources
FOR EACH ROW BEGIN

  DECLARE otherSourceId INTEGER UNSIGNED;
  DECLARE defaultTlpId INTEGER UNSIGNED;
  DECLARE otherSourceName VARCHAR(255);

  IF NEW.reference_id = 0 AND NEW.type = 'other_sources' AND NEW.name IS NOT NULL
  THEN
    SELECT
      name
    INTO
      otherSourceName
    FROM
      sources S
    WHERE
      LOWER(S.name) = LOWER(NEW.name);

    IF otherSourceName IS NOT NULL
    THEN
      SET NEW.name = otherSourceName;
    END IF;

    SELECT id
    INTO otherSourceId
    FROM other_sources OS
    WHERE
      OS.name = NEW.name
    AND
      OS.deleted_at IS NULL
    LIMIT 1;

    IF otherSourceId IS NULL
    THEN
      INSERT IGNORE INTO other_sources
      (
      name,
      created_at,
      updated_at
      )
      VALUES
      (
      NEW.name,
      NOW(3),
      NOW(3)
      )
      ON DUPLICATE KEY UPDATE
      updated_at = NOW(3),
      deleted_at = NULL;

      SELECT last_insert_id()
      INTO otherSourceId;
    END IF;

    SET NEW.reference_id = otherSourceId;
  END IF;

  IF NEW.name IS NULL
  THEN
    SET NEW.name = fn_source_name_from_reference(NEW.type, NEW.reference_id);
  END IF;

  IF ISNULL(NEW.default_tlp_id)
  THEN
    SELECT S.default_tlp_id
    INTO defaultTlpId
    FROM sources S
    WHERE
      LOWER(S.name) = LOWER(NEW.name) AND
      S.deleted_at IS NULL AND
      S.default_tlp_id IS NOT NULL
    LIMIT 1;
    SET NEW.default_tlp_id = defaultTlpId;
  END IF;

END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`threatquotient`@`localhost`*/ /*!50003 TRIGGER trig_sources_before_update BEFORE UPDATE ON sources
FOR EACH ROW BEGIN

  -- Expiration
  IF IFNULL(OLD.expire_days, '') <> IFNULL(NEW.expire_days, '') THEN
    SET NEW.expires_needs_calc = 'Y';
  END IF;

END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-11-07  0:28:01
