-- MySQL dump 10.16  Distrib 10.3.9-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: threatquotient2
-- ------------------------------------------------------
-- Server version	10.3.9-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `object_relations`
--

DROP TABLE IF EXISTS `object_relations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `object_relations` (
  `object_type` varchar(20) NOT NULL,
  `object_id` bigint(20) unsigned NOT NULL,
  `relation_type` varchar(20) NOT NULL,
  `relation_ids_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '[]',
  `relation_count` int(11) GENERATED ALWAYS AS (json_length(`relation_ids_json`)) VIRTUAL,
  `updated_at` datetime(3) NOT NULL DEFAULT current_timestamp(3) ON UPDATE current_timestamp(3),
  UNIQUE KEY `object_to_relation` (`object_type`,`object_id`,`relation_type`),
  KEY `object_by_type_and_id_index` (`object_type`,`object_id`),
  KEY `object_relations_count_index` (`relation_type`,`relation_count`),
  CONSTRAINT `object_relations_valid_json` CHECK (json_valid(`relation_ids_json`))
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `object_relations`
--
-- WHERE:  `object_type` = 'indicator' AND `object_id` IN (SELECT id FROM `object_audit_id_lookup` WHERE key_column = 'indicator_id')

LOCK TABLES `object_relations` WRITE;
/*!40000 ALTER TABLE `object_relations` DISABLE KEYS */;
INSERT  IGNORE INTO `object_relations` VALUES ('indicator',99958,'attachment','[80]',1,'2019-11-07 00:22:42.597'),('indicator',97061,'attachment','[79]',1,'2019-11-07 00:22:03.990'),('indicator',97061,'incident','[15]',1,'2019-11-07 00:22:03.967'),('indicator',97061,'indicator','[97060]',1,'2019-11-07 00:22:03.967'),('indicator',94239,'attachment','[78, 85]',2,'2019-11-07 00:27:22.225'),('indicator',94239,'incident','[14]',1,'2019-11-07 00:21:40.535'),('indicator',94239,'indicator','[94232, 94236, 94231, 94238]',4,'2019-11-07 00:21:40.535'),('indicator',7249,'attachment','[60]',1,'2019-11-07 00:08:56.546'),('indicator',7293,'attachment','[60]',1,'2019-11-07 00:08:56.708'),('indicator',7280,'attachment','[60]',1,'2019-11-07 00:08:56.651');
/*!40000 ALTER TABLE `object_relations` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-11-07  0:28:03
