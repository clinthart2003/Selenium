-- MySQL dump 10.16  Distrib 10.3.9-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: threatquotient2
-- ------------------------------------------------------
-- Server version	10.3.9-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `indicator_statuses`
--

DROP TABLE IF EXISTS `indicator_statuses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `indicator_statuses` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` char(32) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `user_editable` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `visible` varchar(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `include_in_export` varchar(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `protected` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `created_at` datetime(3) NOT NULL DEFAULT '0000-00-00 00:00:00.000',
  `updated_at` datetime(3) NOT NULL DEFAULT '0000-00-00 00:00:00.000',
  PRIMARY KEY (`id`),
  UNIQUE KEY `indicator_statuses_name_unique` (`name`),
  KEY `indicator_statuses_updated_at_index` (`updated_at`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `indicator_statuses`
--

LOCK TABLES `indicator_statuses` WRITE;
/*!40000 ALTER TABLE `indicator_statuses` DISABLE KEYS */;
INSERT  IGNORE INTO `indicator_statuses` VALUES (1,'Active','Poses a threat and is being exported to detection tools.','N','Y','Y','Y','2019-03-26 18:21:38.000','2019-03-26 18:21:38.000'),(2,'Expired','No longer poses a serious threat.','N','Y','Y','N','2019-03-26 18:21:38.000','2019-03-26 18:21:38.000'),(3,'Indirect','Associated to an active indicator or event (i.e. pDNS).','N','Y','Y','N','2019-03-26 18:21:38.000','2019-03-26 18:21:38.000'),(4,'Review','Requires further analysis.','N','Y','Y','N','2019-03-26 18:21:38.000','2019-03-26 18:21:38.000'),(5,'Whitelisted','Poses NO risk and should never be deployed.','N','Y','N','Y','2019-03-26 18:21:38.000','2019-03-26 18:21:38.000');
/*!40000 ALTER TABLE `indicator_statuses` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-11-07  0:28:01
