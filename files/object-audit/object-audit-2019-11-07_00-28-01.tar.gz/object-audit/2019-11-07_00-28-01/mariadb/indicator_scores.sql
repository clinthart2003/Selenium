-- MySQL dump 10.16  Distrib 10.3.9-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: threatquotient2
-- ------------------------------------------------------
-- Server version	10.3.9-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `indicator_scores`
--

DROP TABLE IF EXISTS `indicator_scores`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `indicator_scores` (
  `indicator_id` int(10) unsigned NOT NULL,
  `generated_score` decimal(5,2) NOT NULL DEFAULT 0.00,
  `manual_score` int(10) unsigned DEFAULT NULL,
  `score_config_hash` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `updated_at` datetime(3) NOT NULL DEFAULT current_timestamp(3) ON UPDATE current_timestamp(3),
  PRIMARY KEY (`indicator_id`),
  KEY `indicator_scores_score_config_hash_index` (`score_config_hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `indicator_scores`
--
-- WHERE:  `indicator_id` in (SELECT id FROM `object_audit_id_lookup` WHERE key_column = 'indicator_id')

LOCK TABLES `indicator_scores` WRITE;
/*!40000 ALTER TABLE `indicator_scores` DISABLE KEYS */;
INSERT  IGNORE INTO `indicator_scores` VALUES (99958,0.00,NULL,'7f8b888a2d2b462310d5227aa75e8c4a78973a96','2019-11-07 00:22:32.241','2019-11-07 00:22:32.241'),(99961,0.00,NULL,'7f8b888a2d2b462310d5227aa75e8c4a78973a96','2019-11-07 00:22:32.241','2019-11-07 00:22:32.241'),(97061,0.00,NULL,'7f8b888a2d2b462310d5227aa75e8c4a78973a96','2019-11-07 00:22:03.478','2019-11-07 00:22:03.478'),(97063,0.00,NULL,'7f8b888a2d2b462310d5227aa75e8c4a78973a96','2019-11-07 00:22:03.478','2019-11-07 00:22:03.478'),(94239,0.00,NULL,'7f8b888a2d2b462310d5227aa75e8c4a78973a96','2019-11-07 00:21:39.886','2019-11-07 00:21:39.886'),(94240,0.00,NULL,'7f8b888a2d2b462310d5227aa75e8c4a78973a96','2019-11-07 00:21:39.886','2019-11-07 00:21:39.886'),(7249,0.00,NULL,'7f8b888a2d2b462310d5227aa75e8c4a78973a96','2019-11-07 00:08:54.810','2019-11-07 00:08:54.810'),(7255,0.00,NULL,'7f8b888a2d2b462310d5227aa75e8c4a78973a96','2019-11-07 00:08:54.810','2019-11-07 00:08:54.810'),(7257,0.00,NULL,'7f8b888a2d2b462310d5227aa75e8c4a78973a96','2019-11-07 00:08:54.810','2019-11-07 00:08:54.810'),(7258,0.00,NULL,'7f8b888a2d2b462310d5227aa75e8c4a78973a96','2019-11-07 00:08:54.810','2019-11-07 00:08:54.810'),(7262,0.00,NULL,'7f8b888a2d2b462310d5227aa75e8c4a78973a96','2019-11-07 00:08:54.810','2019-11-07 00:08:54.810'),(7270,0.00,NULL,'7f8b888a2d2b462310d5227aa75e8c4a78973a96','2019-11-07 00:08:54.810','2019-11-07 00:08:54.810'),(7273,0.00,NULL,'7f8b888a2d2b462310d5227aa75e8c4a78973a96','2019-11-07 00:08:54.810','2019-11-07 00:08:54.810'),(7274,0.00,NULL,'7f8b888a2d2b462310d5227aa75e8c4a78973a96','2019-11-07 00:08:54.810','2019-11-07 00:08:54.810'),(7275,0.00,NULL,'7f8b888a2d2b462310d5227aa75e8c4a78973a96','2019-11-07 00:08:54.810','2019-11-07 00:08:54.810'),(7277,0.00,NULL,'7f8b888a2d2b462310d5227aa75e8c4a78973a96','2019-11-07 00:08:54.810','2019-11-07 00:08:54.810'),(7293,0.00,NULL,'7f8b888a2d2b462310d5227aa75e8c4a78973a96','2019-11-07 00:08:54.810','2019-11-07 00:08:54.810'),(7294,0.00,NULL,'7f8b888a2d2b462310d5227aa75e8c4a78973a96','2019-11-07 00:08:54.810','2019-11-07 00:08:54.810'),(7280,0.00,NULL,'7f8b888a2d2b462310d5227aa75e8c4a78973a96','2019-11-07 00:08:54.810','2019-11-07 00:08:54.810'),(7286,0.00,NULL,'7f8b888a2d2b462310d5227aa75e8c4a78973a96','2019-11-07 00:08:54.810','2019-11-07 00:08:54.810');
/*!40000 ALTER TABLE `indicator_scores` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`threatquotient`@`localhost`*/ /*!50003 TRIGGER trig_indicator_scores_after_insert AFTER INSERT ON indicator_scores
FOR EACH ROW BEGIN

  -- Audit Logging
  INSERT INTO indicator_score_audit_log (indicator_score_id, event_type, field, new_value, changed_by_source_id)
  VALUES (NEW.indicator_id, 'added', 'generated_score', NEW.generated_score, @owner_source_id);

  INSERT INTO indicator_score_audit_log (indicator_score_id, event_type, field, new_value, changed_by_source_id)
  VALUES (NEW.indicator_id, 'added', 'manual_score', NEW.manual_score, @owner_source_id);

  -- touch parent
  IF IFNULL(@TOUCH_PARENT_INDICATOR, TRUE)
  THEN
    SET @SCORE_INDICATOR_OLD = @SCORE_INDICATOR;
    SET @SCORE_INDICATOR = FALSE;

    UPDATE
      indicators
    SET
      updated_at = updated_at,
      touched_at = NOW(3)
    WHERE
      id = NEW.indicator_id;

    SET @SCORE_INDICATOR = @SCORE_INDICATOR_OLD;
  END IF;

END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`threatquotient`@`localhost`*/ /*!50003 TRIGGER trig_indicator_scores_after_update AFTER UPDATE ON indicator_scores
FOR EACH ROW BEGIN

  -- Audit Logging
  IF IFNULL(OLD.generated_score, '') <> IFNULL(NEW.generated_score, '')
  THEN
    INSERT INTO
      indicator_score_audit_log (indicator_score_id, event_type, field, new_value, changed_by_source_id)
    VALUES
      (NEW.indicator_id, 'updated', 'generated_score', NEW.generated_score, @owner_source_id);

    SET @SCORE_INDICATOR_OLD = @SCORE_INDICATOR;
    SET @SCORE_INDICATOR = FALSE;

    UPDATE
      indicators
    SET
      updated_at = NOW(3)
    WHERE
      id = NEW.indicator_id;

    SET @SCORE_INDICATOR = @SCORE_INDICATOR_OLD;
  END IF;

  IF IFNULL(OLD.manual_score, '') <> IFNULL(NEW.manual_score, '')
  THEN
    INSERT INTO
      indicator_score_audit_log (indicator_score_id, event_type, field, new_value, changed_by_source_id)
    VALUES
      (NEW.indicator_id, 'updated', 'manual_score', NEW.manual_score, @owner_source_id);

    SET @SCORE_INDICATOR_OLD = @SCORE_INDICATOR;
    SET @SCORE_INDICATOR = FALSE;

    UPDATE
      indicators
    SET
      updated_at = NOW(3)
    WHERE
      id = NEW.indicator_id;

    SET @SCORE_INDICATOR = @SCORE_INDICATOR_OLD;
  END IF;

  -- touch parent
  IF IFNULL(@TOUCH_PARENT_INDICATOR, TRUE)
  THEN
    SET @SCORE_INDICATOR_OLD = @SCORE_INDICATOR;
    SET @SCORE_INDICATOR = FALSE;

    UPDATE indicators
    SET
      updated_at = updated_at,
      touched_at = NOW(3)
    WHERE
      id = NEW.indicator_id;

    SET @SCORE_INDICATOR = @SCORE_INDICATOR_OLD;
  END IF;

END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-11-07  0:28:01
