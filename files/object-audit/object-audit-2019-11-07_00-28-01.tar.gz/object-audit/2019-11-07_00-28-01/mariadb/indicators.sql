-- MySQL dump 10.16  Distrib 10.3.9-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: threatquotient2
-- ------------------------------------------------------
-- Server version	10.3.9-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `indicators`
--

DROP TABLE IF EXISTS `indicators`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `indicators` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type_id` int(10) unsigned NOT NULL,
  `status_id` int(10) unsigned NOT NULL,
  `class` enum('host','network') COLLATE utf8_unicode_ci NOT NULL,
  `hash` char(32) COLLATE utf8_unicode_ci NOT NULL,
  `value` text COLLATE utf8_unicode_ci NOT NULL,
  `description` longtext COLLATE utf8_unicode_ci DEFAULT NULL,
  `last_detected_at` datetime(3) DEFAULT NULL,
  `expires_at` datetime(3) DEFAULT NULL,
  `expired_at` datetime(3) DEFAULT NULL,
  `expires_needs_calc` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `expires_calculated_at` datetime(3) DEFAULT NULL,
  `created_at` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `updated_at` datetime(3) NOT NULL DEFAULT current_timestamp(3) ON UPDATE current_timestamp(3),
  `touched_at` datetime(3) NOT NULL DEFAULT current_timestamp(3) ON UPDATE current_timestamp(3) COMMENT 'Date and time the Indicator or its'' relational data was modified.',
  `deleted_at` datetime(3) DEFAULT NULL,
  `sync_hash` char(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `indicators_type_id_index` (`type_id`),
  KEY `indicators_status_id_index` (`status_id`),
  KEY `indicators_created_at_index` (`created_at`),
  KEY `indicators_class_index` (`class`),
  KEY `indicators_hash_index` (`hash`),
  KEY `indicators_last_detected_at_index` (`last_detected_at`),
  KEY `indicators_deleted_at_index` (`deleted_at`),
  KEY `indicators_value_index` (`value`(255)),
  KEY `indicators_type_id_hash_index` (`type_id`,`hash`),
  KEY `indicators_expires_at_index` (`expires_at`),
  KEY `indicators_expired_at_index` (`expired_at`),
  KEY `indicators_expires_calculated_at_index` (`expires_calculated_at`),
  KEY `indicators_touched_at_index` (`touched_at`),
  KEY `indicators_updated_at_index` (`updated_at`),
  KEY `indicators_expires_needs_calc_index` (`expires_needs_calc`),
  KEY `sync_hash_index` (`sync_hash`)
) ENGINE=InnoDB AUTO_INCREMENT=135270 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `indicators`
--
-- WHERE:  `id` in (SELECT id FROM `object_audit_id_lookup` WHERE key_column = 'indicator_id')

LOCK TABLES `indicators` WRITE;
/*!40000 ALTER TABLE `indicators` DISABLE KEYS */;
INSERT  IGNORE INTO `indicators` VALUES (99958,10,4,'network','1a9d7445f3b08f6f0cae67bcac94597f','jamaican-vents.autos',NULL,NULL,NULL,NULL,'N','2019-11-07 00:26:47.206','2019-11-07 00:22:32.241','2019-11-07 00:22:32.241','2019-11-07 00:22:42.615',NULL,'41b003d45e351aa214564320da634e0c'),(99961,10,4,'network','1a9d7445f3b08f6f0cae67bcac94597f','jamaican-vents.autos',NULL,NULL,NULL,NULL,'N',NULL,'2019-11-07 00:22:32.241','2019-11-07 00:22:32.241','2019-11-07 00:22:32.241',NULL,'41b003d45e351aa214564320da634e0c'),(97061,10,4,'network','f102210da46957d1a1dace98b1ba6c49','[redacted].wufoo.com',NULL,NULL,NULL,NULL,'N','2019-11-07 00:26:32.131','2019-11-07 00:22:03.478','2019-11-07 00:22:03.478','2019-11-07 00:22:04.001',NULL,'8e53a1bc33f9a9646ec8ffddb24bd07b'),(97063,10,4,'network','f102210da46957d1a1dace98b1ba6c49','[redacted].wufoo.com',NULL,NULL,NULL,NULL,'N',NULL,'2019-11-07 00:22:03.478','2019-11-07 00:22:03.478','2019-11-07 00:22:03.478',NULL,'8e53a1bc33f9a9646ec8ffddb24bd07b'),(94239,10,4,'network','56e96958cf1206175b6c2f35087549a9','tinyurl.com',NULL,NULL,NULL,NULL,'N','2019-11-07 00:27:22.693','2019-11-07 00:21:39.886','2019-11-07 00:21:39.886','2019-11-07 00:27:22.225',NULL,'a2748a57f83e4294d6862ede2e1586a1'),(94240,10,4,'network','56e96958cf1206175b6c2f35087549a9','tinyurl.com',NULL,NULL,NULL,NULL,'N',NULL,'2019-11-07 00:21:39.886','2019-11-07 00:21:39.886','2019-11-07 00:21:39.886',NULL,'a2748a57f83e4294d6862ede2e1586a1'),(7249,28,4,'network','147126fd9c9ba220bd840edccd6ad5e0','docs.google.com/uc',NULL,NULL,NULL,NULL,'N','2019-11-07 00:10:08.363','2019-11-07 00:08:54.810','2019-11-07 00:08:54.810','2019-11-07 00:08:56.641',NULL,'7a9e7852794ff57d2cec90bc4e83864b'),(7255,28,4,'network','147126fd9c9ba220bd840edccd6ad5e0','docs.google.com/uc',NULL,NULL,NULL,NULL,'N',NULL,'2019-11-07 00:08:54.810','2019-11-07 00:08:54.810','2019-11-07 00:08:54.810',NULL,'7a9e7852794ff57d2cec90bc4e83864b'),(7257,28,4,'network','147126fd9c9ba220bd840edccd6ad5e0','docs.google.com/uc',NULL,NULL,NULL,NULL,'N',NULL,'2019-11-07 00:08:54.810','2019-11-07 00:08:54.810','2019-11-07 00:08:54.810',NULL,'7a9e7852794ff57d2cec90bc4e83864b'),(7258,28,4,'network','147126fd9c9ba220bd840edccd6ad5e0','docs.google.com/uc',NULL,NULL,NULL,NULL,'N',NULL,'2019-11-07 00:08:54.810','2019-11-07 00:08:54.810','2019-11-07 00:08:54.810',NULL,'7a9e7852794ff57d2cec90bc4e83864b'),(7262,28,4,'network','147126fd9c9ba220bd840edccd6ad5e0','docs.google.com/uc',NULL,NULL,NULL,NULL,'N',NULL,'2019-11-07 00:08:54.810','2019-11-07 00:08:54.810','2019-11-07 00:08:54.810',NULL,'7a9e7852794ff57d2cec90bc4e83864b'),(7270,28,4,'network','147126fd9c9ba220bd840edccd6ad5e0','docs.google.com/uc',NULL,NULL,NULL,NULL,'N',NULL,'2019-11-07 00:08:54.810','2019-11-07 00:08:54.810','2019-11-07 00:08:54.810',NULL,'7a9e7852794ff57d2cec90bc4e83864b'),(7273,28,4,'network','147126fd9c9ba220bd840edccd6ad5e0','docs.google.com/uc',NULL,NULL,NULL,NULL,'N',NULL,'2019-11-07 00:08:54.810','2019-11-07 00:08:54.810','2019-11-07 00:08:54.810',NULL,'7a9e7852794ff57d2cec90bc4e83864b'),(7274,28,4,'network','147126fd9c9ba220bd840edccd6ad5e0','docs.google.com/uc',NULL,NULL,NULL,NULL,'N',NULL,'2019-11-07 00:08:54.810','2019-11-07 00:08:54.810','2019-11-07 00:08:54.810',NULL,'7a9e7852794ff57d2cec90bc4e83864b'),(7275,28,4,'network','147126fd9c9ba220bd840edccd6ad5e0','docs.google.com/uc',NULL,NULL,NULL,NULL,'N',NULL,'2019-11-07 00:08:54.810','2019-11-07 00:08:54.810','2019-11-07 00:08:54.810',NULL,'7a9e7852794ff57d2cec90bc4e83864b'),(7277,28,4,'network','147126fd9c9ba220bd840edccd6ad5e0','docs.google.com/uc',NULL,NULL,NULL,NULL,'N',NULL,'2019-11-07 00:08:54.810','2019-11-07 00:08:54.810','2019-11-07 00:08:54.810',NULL,'7a9e7852794ff57d2cec90bc4e83864b'),(7293,10,4,'network','c127a550cf236dec481d0c94aa5b47f0','dooblo.net',NULL,NULL,NULL,NULL,'N','2019-11-07 00:10:08.499','2019-11-07 00:08:54.810','2019-11-07 00:08:54.810','2019-11-07 00:08:56.711',NULL,'253363d267d4a9602c5f168dfcbf95d0'),(7294,10,4,'network','c127a550cf236dec481d0c94aa5b47f0','dooblo.net',NULL,NULL,NULL,NULL,'N',NULL,'2019-11-07 00:08:54.810','2019-11-07 00:08:54.810','2019-11-07 00:08:54.810',NULL,'253363d267d4a9602c5f168dfcbf95d0'),(7280,10,4,'network','e09edfbadb0ac99a3a74f5a743ad3c31','haberkat.com',NULL,NULL,NULL,NULL,'N','2019-11-07 00:10:08.453','2019-11-07 00:08:54.810','2019-11-07 00:08:54.810','2019-11-07 00:08:56.671',NULL,'58deb25bc5e6e8f4f0dd2635bc3e1628'),(7286,10,4,'network','e09edfbadb0ac99a3a74f5a743ad3c31','haberkat.com',NULL,NULL,NULL,NULL,'N',NULL,'2019-11-07 00:08:54.810','2019-11-07 00:08:54.810','2019-11-07 00:08:54.810',NULL,'58deb25bc5e6e8f4f0dd2635bc3e1628');
/*!40000 ALTER TABLE `indicators` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`threatquotient`@`localhost`*/ /*!50003 TRIGGER trig_indicators_before_insert BEFORE INSERT ON indicators
FOR EACH ROW BEGIN

  IF new.status_id = fn_indicator_status_id('Expired')
  THEN
    SET new.expired_at = NOW(3);
  END IF;

  SET NEW.sync_hash = MD5(CONCAT(NEW.value, NEW.type_id));

END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`threatquotient`@`localhost`*/ /*!50003 TRIGGER trig_indicators_after_insert AFTER INSERT ON indicators
FOR EACH ROW BEGIN

  INSERT INTO
    indicator_audit_log (indicator_id, event_type, field, new_value, run_uuid, changed_by_source_id)
  VALUES
    (NEW.id, 'added', 'value', NEW.value, fn_uuid_to_binary(@CONNECTOR_RUN_UUID), @OWNER_SOURCE_ID);

  INSERT INTO
    indicator_audit_log (indicator_id, event_type, field, new_value, run_uuid, changed_by_source_id)
  VALUES
    (NEW.id, 'added', 'type_id', NEW.type_id, fn_uuid_to_binary(@CONNECTOR_RUN_UUID), @OWNER_SOURCE_ID);

  INSERT INTO
    indicator_audit_log (indicator_id, event_type, field, new_value, run_uuid, changed_by_source_id)
  VALUES
    (NEW.id, 'added', 'status_id', NEW.status_id, fn_uuid_to_binary(@CONNECTOR_RUN_UUID), @OWNER_SOURCE_ID);

  INSERT INTO
    indicator_audit_log (indicator_id, event_type, field, new_value, run_uuid, changed_by_source_id)
  VALUES
    (NEW.id, 'added', 'class', NEW.class, fn_uuid_to_binary(@CONNECTOR_RUN_UUID), @OWNER_SOURCE_ID);

  INSERT INTO
    indicator_audit_log (indicator_id, event_type, field, new_value, run_uuid, changed_by_source_id)
  VALUES
    (NEW.id, 'added', 'description', NEW.description, fn_uuid_to_binary(@CONNECTOR_RUN_UUID), @OWNER_SOURCE_ID);

  IF NEW.last_detected_at IS NOT NULL
  THEN
    INSERT INTO
      indicator_audit_log (indicator_id, event_type, field, new_value, run_uuid, changed_by_source_id)
    VALUES
      (NEW.id, 'added', 'last_detected_at', NEW.last_detected_at, fn_uuid_to_binary(@CONNECTOR_RUN_UUID), @OWNER_SOURCE_ID);
  END IF;

  IF NEW.expires_at IS NOT NULL
  THEN
    INSERT INTO
      indicator_audit_log (indicator_id, event_type, field, new_value, run_uuid, changed_by_source_id)
    VALUES
      (NEW.id, 'added', 'expires_at', NEW.expires_at, fn_uuid_to_binary(@CONNECTOR_RUN_UUID), @OWNER_SOURCE_ID);
  END IF;

  IF NEW.expired_at IS NOT NULL
  THEN
    INSERT INTO
      indicator_audit_log (indicator_id, event_type, field, new_value, run_uuid, changed_by_source_id)
    VALUES
      (NEW.id, 'added', 'expired_at', NEW.expired_at, fn_uuid_to_binary(@CONNECTOR_RUN_UUID), @OWNER_SOURCE_ID);
  END IF;

  IF @CONNECTOR_RUN_UUID IS NOT NULL
  THEN
    INSERT INTO
      connector_run_objects (run_uuid, object_id, object_type)
    VALUES
      (fn_uuid_to_binary(@CONNECTOR_RUN_UUID), NEW.id, 'indicators');
  END IF;

  SET @TOUCH_PARENT_INDICATOR_OLD = @TOUCH_PARENT_INDICATOR;
  SET @TOUCH_PARENT_INDICATOR = FALSE;

  INSERT
  INTO
    indicator_scores
  (
    indicator_id,
    score_config_hash
  )
  VALUES
  (
    NEW.id,
    IF(
      fn_indicator_type_scorable(NEW.type_id) <> 'N',
      'pending_score',
      fn_score_config_hash()
    )
  );

  SET @TOUCH_PARENT_INDICATOR = @TOUCH_PARENT_INDICATOR_OLD;

END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`threatquotient`@`localhost`*/ /*!50003 TRIGGER trig_indicators_before_update BEFORE UPDATE ON indicators
FOR EACH ROW BEGIN
  DECLARE expiredStatusId INTEGER UNSIGNED;
  DECLARE whitelistedStatusId INTEGER UNSIGNED;

  -- Expiration
  IF IFNULL(OLD.expired_at, '') <> IFNULL(NEW.expired_at, '') THEN
    SET NEW.expires_calculated_at = NEW.touched_at;
  END IF;

  IF IFNULL(@PROTECT_INDICATOR_STATUS, FALSE) THEN
    IF fn_indicator_status_id_protected(OLD.status_id) <> 'N' THEN
      SET NEW.status_id = OLD.status_id;
    END IF;
  END IF;

  IF NEW.status_id <> OLD.status_id THEN
    SET expiredStatusId = fn_indicator_status_id('Expired');

    IF NEW.status_id = expiredStatusId THEN
      SET NEW.expires_at = NULL;
      SET NEW.expired_at = NOW(3);
    ELSE
      IF OLD.status_id = expiredStatusId THEN
        SET NEW.expired_at = NULL;
        SET NEW.expires_at = NULL;
      END IF;

      SET whitelistedStatusId = fn_indicator_status_id('Whitelisted');

      IF NEW.status_id = whitelistedStatusId THEN
        SET NEW.expired_at = NULL;
        SET NEW.expires_at = NULL;
      END IF;
    END IF;
  END IF;

  IF NOT NEW.expires_needs_calc = 'Y' THEN
    SET NEW.expires_needs_calc = fn_indicator_calc_expiration_needed(
        NEW.status_id,
        NEW.expires_at,
        NEW.expires_calculated_at,
        NEW.touched_at,
        NEW.deleted_at
    );
  END IF;

  IF OLD.type_id <> NEW.type_id OR OLD.value <> NEW.value THEN
    SET NEW.sync_hash = MD5(CONCAT(NEW.value, NEW.type_id));
  END IF;

  IF IFNULL(@SCORE_INDICATOR, TRUE) THEN
    IF (
      OLD.type_id <> NEW.type_id
      OR IFNULL(OLD.deleted_at, '') <> IFNULL(NEW.deleted_at, '')
    )
    AND NEW.deleted_at IS NULL THEN
      IF fn_indicator_type_scorable(NEW.type_id) <> 'N' THEN
        SET @TOUCH_PARENT_INDICATOR_OLD = @TOUCH_PARENT_INDICATOR;
        SET @TOUCH_PARENT_INDICATOR = FALSE;

        INSERT
        INTO
          indicator_scores
        (
          indicator_id,
          score_config_hash
        )
        VALUES
        (
          NEW.id,
          'pending_score'
        )
        ON DUPLICATE KEY
        UPDATE
          score_config_hash = 'pending_score';

        SET NEW.touched_at = NOW(3);

        SET @TOUCH_PARENT_INDICATOR = @TOUCH_PARENT_INDICATOR_OLD;
      END IF;
    END IF;
  END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`threatquotient`@`localhost`*/ /*!50003 TRIGGER trig_indicators_after_update AFTER UPDATE ON indicators
FOR EACH ROW BEGIN

  DECLARE connectorRunUuid BINARY(16);

  -- Audit Logging
  IF IFNULL(OLD.type_id, '') <> IFNULL(NEW.type_id, '')
  THEN
    INSERT INTO
      indicator_audit_log (indicator_id, event_type, field, new_value, run_uuid, changed_by_source_id)
    VALUES
      (NEW.id, 'updated', 'type_id', NEW.type_id, fn_uuid_to_binary(@CONNECTOR_RUN_UUID), @OWNER_SOURCE_ID)
    ON DUPLICATE KEY UPDATE
      event_type = VALUES(event_type),
      new_value = VALUES(new_value),
      changed_by_source_id = VALUES(changed_by_source_id);
  END IF;

  IF IFNULL(OLD.status_id, '') <> IFNULL(NEW.status_id, '')
  THEN
    INSERT INTO
      indicator_audit_log (indicator_id, event_type, field, new_value, run_uuid, changed_by_source_id)
    VALUES
      (NEW.id, 'updated', 'status_id', NEW.status_id, fn_uuid_to_binary(@CONNECTOR_RUN_UUID), @OWNER_SOURCE_ID)
    ON DUPLICATE KEY UPDATE
      event_type = VALUES(event_type),
      new_value = VALUES(new_value),
      changed_by_source_id = VALUES(changed_by_source_id);
  END IF;

  IF IFNULL(OLD.class, '') <> IFNULL(NEW.class, '')
  THEN
    INSERT INTO
      indicator_audit_log (indicator_id, event_type, field, new_value, run_uuid, changed_by_source_id)
    VALUES
      (NEW.id, 'updated', 'class', NEW.class, fn_uuid_to_binary(@CONNECTOR_RUN_UUID), @OWNER_SOURCE_ID)
    ON DUPLICATE KEY UPDATE
      event_type = VALUES(event_type),
      new_value = VALUES(new_value),
      changed_by_source_id = VALUES(changed_by_source_id);
  END IF;

  IF IFNULL(OLD.value, '') <> IFNULL(NEW.value, '')
  THEN
    INSERT INTO
      indicator_audit_log (indicator_id, event_type, field, new_value, run_uuid, changed_by_source_id)
    VALUES
      (NEW.id, 'updated', 'value', NEW.value, fn_uuid_to_binary(@CONNECTOR_RUN_UUID), @OWNER_SOURCE_ID)
    ON DUPLICATE KEY UPDATE
      event_type = VALUES(event_type),
      new_value = VALUES(new_value),
      changed_by_source_id = VALUES(changed_by_source_id);

    UPDATE
      investigation_nodes
    SET
      label = NEW.value
    WHERE
      object_id = NEW.id AND
      object_type = 'indicator';
  END IF;

  IF IFNULL(OLD.description, '') <> IFNULL(NEW.description, '')
  THEN
    INSERT INTO
      indicator_audit_log (indicator_id, event_type, field, new_value, run_uuid, changed_by_source_id)
    VALUES
      (NEW.id, 'updated', 'description', NEW.description, fn_uuid_to_binary(@CONNECTOR_RUN_UUID), @OWNER_SOURCE_ID)
    ON DUPLICATE KEY UPDATE
      event_type = VALUES(event_type),
      new_value = VALUES(new_value),
      changed_by_source_id = VALUES(changed_by_source_id);
  END IF;

  IF IFNULL(OLD.last_detected_at, '') <> IFNULL(NEW.last_detected_at, '')
  THEN
    INSERT INTO
      indicator_audit_log (indicator_id, event_type, field, new_value, run_uuid, changed_by_source_id)
    VALUES
      (NEW.id, 'updated', 'last_detected_at', IFNULL(NEW.last_detected_at, ''), fn_uuid_to_binary(@CONNECTOR_RUN_UUID), @OWNER_SOURCE_ID)
    ON DUPLICATE KEY UPDATE
      event_type = VALUES(event_type),
      new_value = VALUES(new_value),
      changed_by_source_id = VALUES(changed_by_source_id);
  END IF;

  IF IFNULL(OLD.expires_at, '') <> IFNULL(NEW.expires_at, '')
  THEN
    INSERT INTO
      indicator_audit_log (indicator_id, event_type, field, new_value, run_uuid, changed_by_source_id)
    VALUES
      (NEW.id, 'updated', 'expires_at', IFNULL(NEW.expires_at, ''), fn_uuid_to_binary(@CONNECTOR_RUN_UUID), @OWNER_SOURCE_ID)
    ON DUPLICATE KEY UPDATE
      event_type = VALUES(event_type),
      new_value = VALUES(new_value),
      changed_by_source_id = VALUES(changed_by_source_id);
  END IF;

  IF IFNULL(OLD.expired_at, '') <> IFNULL(NEW.expired_at, '')
  THEN
    INSERT INTO
      indicator_audit_log (indicator_id, event_type, field, new_value, run_uuid, changed_by_source_id)
    VALUES
      (NEW.id, 'updated', 'expired_at', IFNULL(NEW.expired_at, ''), fn_uuid_to_binary(@CONNECTOR_RUN_UUID), @OWNER_SOURCE_ID)
    ON DUPLICATE KEY UPDATE
      event_type = VALUES(event_type),
      new_value = VALUES(new_value),
      changed_by_source_id = VALUES(changed_by_source_id);
  END IF;

  IF IFNULL(OLD.deleted_at, '') <> IFNULL(new.deleted_at, '')
  THEN
    INSERT INTO
      indicator_audit_log (indicator_id, event_type, field, new_value, run_uuid, changed_by_source_id)
    VALUES
      (NEW.id, IF(NEW.deleted_at IS NULL, 'undeleted', 'deleted'), 'deleted_at', IFNULL(NEW.deleted_at, ''),
        fn_uuid_to_binary(@CONNECTOR_RUN_UUID), @OWNER_SOURCE_ID)
    ON DUPLICATE KEY UPDATE
      event_type = VALUES(event_type),
      new_value = VALUES(new_value),
      changed_by_source_id = VALUES(changed_by_source_id);

    -- cascade deleted
    IF NEW.deleted_at IS NOT NULL
    THEN

      -- prevent recursion in update triggers
      SET @TOUCH_PARENT_INDICATOR = FALSE;

      UPDATE
        object_links
      SET
        src_deleted = 'Y',
        deleted_at  = IFNULL(deleted_at, NEW.deleted_at)
      WHERE
        src_type = 'indicator' AND
        src_object_id = NEW.id;

      UPDATE
        object_links
      SET
        dest_deleted = 'Y',
        deleted_at  = IFNULL(deleted_at, NEW.deleted_at)
      WHERE
        dest_type = 'indicator' AND
        dest_object_id = NEW.id;

      UPDATE
        indicator_attributes
      SET
        deleted_at = IFNULL(deleted_at, NEW.deleted_at)
      WHERE
        indicator_id = NEW.id;

      UPDATE
        indicator_comments
      SET
        deleted_at = IFNULL(deleted_at, NEW.deleted_at)
      WHERE
        indicator_id = NEW.id;

      UPDATE
        indicator_sources
      SET
        deleted_at = IFNULL(deleted_at, NEW.deleted_at)
      WHERE
        indicator_id = NEW.id;

      DELETE FROM
        investigation_nodes
      WHERE
        object_id = NEW.id AND
        object_type = 'indicator';

      DELETE FROM
        watchlist
      WHERE
        object_id = NEW.id AND
        object_type = 'indicator';

      -- prevent recursion in update triggers
      SET @TOUCH_PARENT_INDICATOR = TRUE;

    END IF;

  END IF;

  IF @CONNECTOR_RUN_UUID IS NOT NULL
  THEN
    SELECT
      run_uuid
    INTO
      connectorRunUuid
    FROM
      connector_run_objects
    WHERE
      run_uuid = fn_uuid_to_binary(@CONNECTOR_RUN_UUID) AND object_id = NEW.id AND object_type = 'indicators';

    IF ISNULL(connectorRunUuid)
    THEN
      INSERT INTO
        connector_run_objects (run_uuid, object_id, object_type)
      VALUES
        (fn_uuid_to_binary(@CONNECTOR_RUN_UUID), NEW.id, 'indicators');
    END IF;
  END IF;

END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-11-07  0:28:01
