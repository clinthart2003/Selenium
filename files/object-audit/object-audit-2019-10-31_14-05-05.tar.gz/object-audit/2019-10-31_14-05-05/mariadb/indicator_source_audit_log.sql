-- MySQL dump 10.16  Distrib 10.3.9-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: threatquotient2
-- ------------------------------------------------------
-- Server version	10.3.9-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `indicator_source_audit_log`
--

DROP TABLE IF EXISTS `indicator_source_audit_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `indicator_source_audit_log` (
  `indicator_source_id` int(10) unsigned NOT NULL,
  `event_type` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `field` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `new_value` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `run_uuid` binary(16) DEFAULT NULL,
  `changed_by_source_id` int(10) unsigned DEFAULT NULL,
  `changed_at` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  PRIMARY KEY (`indicator_source_id`,`changed_at`,`field`),
  KEY `indicator_source_audit_log_indicator_source_id_index` (`indicator_source_id`),
  KEY `indicator_source_audit_log_event_type_index` (`event_type`),
  KEY `indicator_source_audit_log_field_index` (`field`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `indicator_source_audit_log`
--
-- WHERE:  `indicator_source_id` in (SELECT id FROM `object_audit_id_lookup` WHERE key_column = 'indicator_source_id')

LOCK TABLES `indicator_source_audit_log` WRITE;
/*!40000 ALTER TABLE `indicator_source_audit_log` DISABLE KEYS */;
INSERT  IGNORE INTO `indicator_source_audit_log` VALUES (1711607934,'added','source_id','622',NULL,481,'2019-03-15 15:26:44.919'),(1711605511,'added','source_id','622',NULL,481,'2019-03-15 15:26:13.509'),(1711605511,'added','tlp_id','3',NULL,481,'2019-03-15 15:26:13.509'),(1711562782,'added','source_id','622',NULL,481,'2019-03-15 15:14:09.520'),(1711562782,'added','tlp_id','3',NULL,481,'2019-03-15 15:14:09.520'),(1711562777,'added','source_id','622',NULL,481,'2019-03-15 15:14:09.520'),(1711562777,'added','tlp_id','3',NULL,481,'2019-03-15 15:14:09.520'),(1661581591,'added','source_id','622',NULL,481,'2019-03-11 17:25:39.061'),(1964294638,'added','source_id','39',NULL,653,'2019-06-18 04:37:59.012'),(33409132,'added','source_id','39',NULL,39,'2017-09-27 12:56:49.256'),(1964295084,'added','source_id','39',NULL,653,'2019-06-18 04:37:59.012'),(49603871,'added','source_id','39',NULL,39,'2017-10-01 21:45:16.441'),(1711620577,'added','published_at','2017-05-19 01:50:28.000',NULL,481,'2019-03-15 15:29:45.418'),(1711620577,'added','source_id','622',NULL,481,'2019-03-15 15:29:45.418'),(1711620577,'added','tlp_id','4',NULL,481,'2019-03-15 15:29:45.418'),(23,'added','source_id','12',NULL,10,'2017-09-14 06:38:25.811'),(33051279,'added','source_id','39',NULL,39,'2017-09-27 10:10:18.489'),(33051279,'updated','published_at','2014-03-25 18:06:41.000',NULL,39,'2017-10-12 15:57:12.307'),(33051279,'updated','published_at',NULL,NULL,653,'2019-06-18 04:32:10.741'),(648997230,'added','source_id','119',NULL,142,'2018-02-13 20:00:46.818'),(851110115,'added','source_id','222',NULL,146,'2018-06-01 13:08:29.378'),(896422212,'added','source_id','303',NULL,146,'2018-06-26 20:37:26.686'),(602,'added','source_id','12',NULL,10,'2017-09-14 06:49:37.072'),(1154335712,'added','source_id','39','�$}=��!��H�',39,'2019-01-30 11:13:30.040'),(1964291313,'added','source_id','39',NULL,653,'2019-06-18 04:37:56.030'),(1154335715,'added','source_id','39','�$}=��!��H�',39,'2019-01-30 11:13:30.042'),(1964291311,'added','source_id','39',NULL,653,'2019-06-18 04:37:56.030'),(1154335692,'added','source_id','39','�$}=��!��H�',39,'2019-01-30 11:13:30.024'),(1964291310,'added','source_id','39',NULL,653,'2019-06-18 04:37:56.030'),(1711620592,'added','published_at','2017-05-19 01:50:28.000',NULL,481,'2019-03-15 15:29:45.418'),(1711620592,'added','source_id','622',NULL,481,'2019-03-15 15:29:45.418'),(1711620592,'added','tlp_id','4',NULL,481,'2019-03-15 15:29:45.418'),(1103756315,'added','source_id','39','� fgw0����H�',39,'2019-01-25 07:06:09.686'),(2144969398,'added','source_id','651','��|��p����fla�',651,'2019-09-30 15:20:17.287'),(1711620593,'added','published_at','2017-05-19 01:50:28.000',NULL,481,'2019-03-15 15:29:45.418'),(1711620593,'added','source_id','622',NULL,481,'2019-03-15 15:29:45.418'),(1711620593,'added','tlp_id','4',NULL,481,'2019-03-15 15:29:45.418'),(1103756155,'added','source_id','39','� fgw0����H�',39,'2019-01-25 07:06:09.324'),(2144969382,'added','source_id','651','��|��p����fla�',651,'2019-09-30 15:20:16.686'),(1711620594,'added','published_at','2017-05-19 01:50:28.000',NULL,481,'2019-03-15 15:29:45.418'),(1711620594,'added','source_id','622',NULL,481,'2019-03-15 15:29:45.418'),(1711620594,'added','tlp_id','4',NULL,481,'2019-03-15 15:29:45.418'),(1103756373,'added','source_id','39','� fgw0����H�',39,'2019-01-25 07:06:09.815'),(2019343863,'added','source_id','651','�*Zr����fla�',651,'2019-07-10 15:48:46.563'),(1711620616,'added','published_at','2017-05-19 01:50:28.000',NULL,481,'2019-03-15 15:29:45.418'),(1711620616,'added','source_id','622',NULL,481,'2019-03-15 15:29:45.418'),(1711620616,'added','tlp_id','4',NULL,481,'2019-03-15 15:29:45.418'),(8651845,'added','source_id','39',NULL,39,'2017-09-18 12:32:09.077'),(8651845,'updated','published_at','2017-05-12 18:27:14.000',NULL,39,'2018-06-05 13:33:39.612'),(8651845,'updated','published_at',NULL,NULL,653,'2019-06-18 04:27:50.517'),(8651845,'updated','published_at','2017-05-12 18:27:14.000','�\r�8s�T��H�',39,'2019-07-29 02:57:14.844'),(1960728572,'added','source_id','651','�7;l]��6��fla�',651,'2019-06-14 00:00:21.220'),(1711620614,'added','published_at','2017-05-19 01:50:28.000',NULL,481,'2019-03-15 15:29:45.418'),(1711620614,'added','source_id','622',NULL,481,'2019-03-15 15:29:45.418'),(1711620614,'added','tlp_id','4',NULL,481,'2019-03-15 15:29:45.418'),(8651846,'added','source_id','39',NULL,39,'2017-09-18 12:32:09.085'),(8651846,'updated','published_at','2017-05-12 18:44:51.000',NULL,39,'2018-06-05 13:33:39.313'),(8651846,'updated','published_at',NULL,NULL,653,'2019-06-18 04:27:50.517'),(8651846,'updated','published_at','2017-05-12 18:44:51.000','�\r�8s�T��H�',39,'2019-07-29 02:57:14.394'),(1990150088,'added','source_id','651','隅J������fla�',651,'2019-06-29 15:55:48.898'),(1711620553,'added','published_at','2017-05-19 01:50:28.000',NULL,481,'2019-03-15 15:29:45.418'),(1711620553,'added','source_id','622',NULL,481,'2019-03-15 15:29:45.418'),(1711620553,'added','tlp_id','4',NULL,481,'2019-03-15 15:29:45.418'),(8651852,'added','source_id','39',NULL,39,'2017-09-18 12:32:09.094'),(8651852,'updated','published_at','2017-05-12 15:46:40.000',NULL,39,'2018-02-14 10:18:13.797'),(8651852,'updated','published_at',NULL,NULL,653,'2019-06-18 04:27:49.669'),(1964060856,'added','source_id','651','�t�?����fla�',651,'2019-06-18 02:57:01.262'),(1711620615,'added','published_at','2017-05-19 01:50:28.000',NULL,481,'2019-03-15 15:29:45.418'),(1711620615,'added','source_id','622',NULL,481,'2019-03-15 15:29:45.418'),(1711620615,'added','tlp_id','4',NULL,481,'2019-03-15 15:29:45.418'),(8651844,'added','source_id','39',NULL,39,'2017-09-18 12:32:09.065'),(8651844,'updated','published_at','2017-05-12 18:44:51.000',NULL,39,'2018-06-05 13:33:39.889'),(8651844,'updated','published_at',NULL,NULL,653,'2019-06-18 04:27:49.669'),(8651844,'updated','published_at','2017-05-12 18:44:51.000','�\r�8s�T��H�',39,'2019-07-29 02:57:14.802'),(1711620554,'added','published_at','2017-05-19 01:50:28.000',NULL,481,'2019-03-15 15:29:45.418'),(1711620554,'added','source_id','622',NULL,481,'2019-03-15 15:29:45.418'),(1711620554,'added','tlp_id','4',NULL,481,'2019-03-15 15:29:45.418'),(8651850,'added','source_id','39',NULL,39,'2017-09-18 12:32:09.091'),(8651850,'updated','published_at','2017-05-12 15:46:40.000',NULL,39,'2018-02-14 10:18:13.863'),(8651850,'updated','published_at',NULL,NULL,653,'2019-06-18 04:27:49.669'),(1964060854,'added','source_id','651','�t�?����fla�',651,'2019-06-18 02:57:01.148'),(1711620555,'added','published_at','2017-05-19 01:50:28.000',NULL,481,'2019-03-15 15:29:45.418'),(1711620555,'added','source_id','622',NULL,481,'2019-03-15 15:29:45.418'),(1711620555,'added','tlp_id','4',NULL,481,'2019-03-15 15:29:45.418'),(8651851,'added','source_id','39',NULL,39,'2017-09-18 12:32:09.093'),(8651851,'updated','published_at','2017-05-12 15:46:39.000',NULL,39,'2018-02-14 10:18:13.832'),(8651851,'updated','published_at',NULL,NULL,653,'2019-06-18 04:27:49.669'),(1964060852,'added','source_id','651','�t�?����fla�',651,'2019-06-18 02:57:01.008');
/*!40000 ALTER TABLE `indicator_source_audit_log` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-10-31 14:05:06
