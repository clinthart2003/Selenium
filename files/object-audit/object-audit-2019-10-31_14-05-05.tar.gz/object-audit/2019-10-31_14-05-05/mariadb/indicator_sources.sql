-- MySQL dump 10.16  Distrib 10.3.9-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: threatquotient2
-- ------------------------------------------------------
-- Server version	10.3.9-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `indicator_sources`
--

DROP TABLE IF EXISTS `indicator_sources`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `indicator_sources` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `indicator_id` int(10) unsigned NOT NULL,
  `source_id` int(10) unsigned NOT NULL,
  `creator_source_id` int(10) unsigned NOT NULL,
  `tlp_id` int(10) unsigned DEFAULT NULL,
  `created_at` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `updated_at` datetime(3) NOT NULL DEFAULT current_timestamp(3) ON UPDATE current_timestamp(3),
  `published_at` datetime(3) DEFAULT NULL,
  `deleted_at` datetime(3) DEFAULT NULL,
  `sync_hash` char(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_key` (`indicator_id`,`source_id`,`creator_source_id`),
  KEY `indicator_sources_tlp_id_index` (`tlp_id`),
  KEY `indicator_sources_published_at_index` (`published_at`),
  KEY `indicator_sources_updated_at_index` (`updated_at`),
  KEY `indicator_tlp_index` (`indicator_id`,`tlp_id`),
  KEY `sync_hash_index` (`sync_hash`)
) ENGINE=InnoDB AUTO_INCREMENT=2175941048 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `indicator_sources`
--
-- WHERE:  `indicator_id` in (SELECT id FROM `object_audit_id_lookup` WHERE key_column = 'indicator_id')

LOCK TABLES `indicator_sources` WRITE;
/*!40000 ALTER TABLE `indicator_sources` DISABLE KEYS */;
INSERT  IGNORE INTO `indicator_sources` VALUES (1711607934,13844370,622,481,NULL,'2019-03-15 15:26:44.919','2019-03-15 15:26:44.919',NULL,NULL,'573b4ee048b90306a3137a11bfa50408'),(1711605511,13844309,622,481,3,'2019-03-15 15:26:13.509','2019-03-15 15:26:13.509',NULL,NULL,'200d07f7d9ab4a17ce8b2d33d12a8af0'),(1711562782,13842319,622,481,3,'2019-03-15 15:14:09.520','2019-03-15 15:14:09.520',NULL,NULL,'353285be125acd042fa92db78738f64f'),(1711562777,13842316,622,481,3,'2019-03-15 15:14:09.520','2019-03-15 15:14:09.520',NULL,NULL,'6179c9247d770f7aa12f045dec99147c'),(1661581591,13749394,622,481,NULL,'2019-03-11 17:25:39.061','2019-03-11 17:25:39.061',NULL,NULL,'105929e6abdff6dd0ba69eced7a195f7'),(1964294638,12922652,39,39,NULL,'2019-01-10 22:38:11.681','2019-06-18 04:37:59.012',NULL,NULL,'b70a99b691d7636b44fa1b411341c094'),(33409132,3361708,39,39,NULL,'2017-09-27 12:56:49.256','2017-09-28 14:18:09.595',NULL,NULL,'541d5947c6a66d0333336ec1335b3371'),(1964295084,12940095,39,39,NULL,'2019-01-10 22:50:46.864','2019-06-18 04:37:59.012',NULL,NULL,'7e72c04a576d762e3af088196ab96101'),(49603871,4063043,39,39,NULL,'2017-10-01 21:45:16.441','2017-12-09 10:26:00.216',NULL,NULL,'2811280e75fb4c5899ef9790c22e296d'),(1711620577,13844736,622,481,4,'2019-03-15 15:29:45.418','2019-03-15 15:29:45.418','2017-05-19 01:50:28.000',NULL,'b054cae1f858ab24bf51a8abaeea09f1'),(23,23,12,10,NULL,'2017-09-14 06:38:25.811','2017-09-14 06:38:25.811',NULL,NULL,'7f3b531da7b09a0fac0c2e0c2ad35355'),(33051279,23,39,39,NULL,'2017-09-27 10:10:18.489','2019-06-18 04:32:10.741',NULL,NULL,'9822111c6cf657ac037831ea34f05208'),(648997230,23,119,142,NULL,'2018-02-13 20:00:46.818','2018-02-13 20:00:46.818',NULL,NULL,'1d4f68f263a0a9a354a763d8ab4c9d39'),(851110115,23,222,146,NULL,'2018-06-01 13:08:29.378','2018-06-01 13:08:29.378',NULL,NULL,'cca2ad41a49017d5850e4a4a3214fb0e'),(896422212,23,303,146,NULL,'2018-06-26 20:37:26.686','2018-06-26 20:37:26.686',NULL,NULL,'c335d7f04b379aebb901f2c1bef8c1d6'),(602,602,12,10,NULL,'2017-09-14 06:49:37.072','2017-09-14 06:49:37.072',NULL,NULL,'4cde67071ed1961810b3fbeb5c8bbd82'),(1154335712,12735005,39,39,NULL,'2019-01-30 11:13:30.040','2019-06-27 21:30:28.613',NULL,NULL,'b9542cc6b9b54b1a0fc4e43d97e1e99c'),(1964291313,12916295,39,39,NULL,'2019-01-10 19:55:32.190','2019-06-18 04:37:56.030',NULL,NULL,'7e79195fd64a00722ed998735b91a1ad'),(1154335715,12735006,39,39,NULL,'2019-01-30 11:13:30.042','2019-06-27 21:31:49.168',NULL,NULL,'b130b35d5074c49742c2705fdef10884'),(1964291311,12916294,39,39,NULL,'2019-01-10 19:55:31.632','2019-06-18 04:37:56.030',NULL,NULL,'3e20aed6f0c6212b6e0a4e34d73cdad7'),(1154335692,12735004,39,39,NULL,'2019-01-30 11:13:30.024','2019-06-27 21:30:28.676',NULL,NULL,'6700ef3c418e1c1836ea5696343d5aeb'),(1964291310,12916293,39,39,NULL,'2019-01-10 19:55:31.608','2019-06-18 04:37:56.030',NULL,NULL,'d4d320ac4efa5b272fb51c6fbc3c7bce'),(1711620592,13844750,622,481,4,'2019-03-15 15:29:45.418','2019-03-15 15:29:45.418','2017-05-19 01:50:28.000',NULL,'dbc4635298c89ff4db065d695a3b7275'),(1103756315,12202156,39,39,NULL,'2019-01-08 11:47:29.844','2019-06-18 04:29:28.804',NULL,NULL,'0f3a9eb70d0a7a4158afe7608fddc136'),(2144969398,12202156,651,651,NULL,'2019-09-30 15:20:17.287','2019-10-07 15:21:11.502',NULL,NULL,'10bbd50b5d55fbad678c90c079d4050f'),(1711620593,13844751,622,481,4,'2019-03-15 15:29:45.418','2019-03-15 15:29:45.418','2017-05-19 01:50:28.000',NULL,'abf3077a04276a848c244bc76cb7ca37'),(1103756155,12202091,39,39,NULL,'2019-01-08 11:47:29.514','2019-06-18 04:29:28.804',NULL,NULL,'c9ffc7da523c7b965a9602d23d430252'),(2144969382,12202091,651,651,NULL,'2019-09-30 15:20:16.686','2019-10-07 15:20:05.913',NULL,NULL,'54c56a15262c4c4f0c04ed11d9375f2d'),(1711620594,13844752,622,481,4,'2019-03-15 15:29:45.418','2019-03-15 15:29:45.418','2017-05-19 01:50:28.000',NULL,'6a14e86961c7eea151cd12c93c622e4a'),(1103756373,12202182,39,39,NULL,'2019-01-08 11:47:00.898','2019-06-18 04:29:27.987',NULL,NULL,'631c79503733f47738fcabfa2c52208e'),(2019343863,12202182,651,651,NULL,'2019-07-10 15:48:46.563','2019-10-07 15:19:38.799',NULL,NULL,'740a3779ecfcebc7e5fc070cf019728c'),(1711620616,13844774,622,481,4,'2019-03-15 15:29:45.418','2019-03-15 15:29:45.418','2017-05-19 01:50:28.000',NULL,'7795c3dea9f29a2de5a6c000b028b791'),(8651845,2713586,39,39,NULL,'2017-09-18 12:32:09.077','2019-07-29 02:59:42.880','2017-05-12 18:27:14.000',NULL,'481c721ec4a15aa5f6dff5814a0cf396'),(1960728572,2713586,651,651,NULL,'2019-06-14 00:00:21.220','2019-10-29 22:32:53.636',NULL,NULL,'ab815f724b6bf61fd30c755bd6484a7d'),(1711620614,13844772,622,481,4,'2019-03-15 15:29:45.418','2019-03-15 15:29:45.418','2017-05-19 01:50:28.000',NULL,'36101921cc905f53ab6b09bbb22f844a'),(8651846,2713587,39,39,NULL,'2017-09-18 12:32:09.085','2019-07-29 02:59:40.451','2017-05-12 18:44:51.000',NULL,'ec346a5c44d449cde8d6f7e1f185c064'),(1990150088,2713587,651,651,NULL,'2019-06-29 15:55:48.898','2019-07-04 15:49:47.544',NULL,NULL,'d7dbc03eeb0aebe2a675919246d93d19'),(1711620553,13844713,622,481,4,'2019-03-15 15:29:45.418','2019-03-15 15:29:45.418','2017-05-19 01:50:28.000',NULL,'73fb50ee1b18bb004f20b909f9db6d6a'),(8651852,2713593,39,39,NULL,'2017-09-18 12:32:09.094','2019-08-08 00:34:11.581',NULL,NULL,'ed5d209dd2e07750662e4f5d5ed7161a'),(1964060856,2713593,651,651,NULL,'2019-06-18 02:57:01.262','2019-10-16 15:19:08.881',NULL,NULL,'3c12c6080bfec851c2aadd6b312b8582'),(1711620615,13844773,622,481,4,'2019-03-15 15:29:45.418','2019-03-15 15:29:45.418','2017-05-19 01:50:28.000',NULL,'99ebbd21daa0167e660f638691de4529'),(8651844,2713585,39,39,NULL,'2017-09-18 12:32:09.065','2019-07-29 02:59:42.798','2017-05-12 18:44:51.000',NULL,'cc2d02eb2c9509cc41af78063cfb272c'),(1711620554,13844714,622,481,4,'2019-03-15 15:29:45.418','2019-03-15 15:29:45.418','2017-05-19 01:50:28.000',NULL,'cc3efea248051cdaa4ccf75bfe762582'),(8651850,2713591,39,39,NULL,'2017-09-18 12:32:09.091','2019-08-08 00:34:11.120',NULL,NULL,'cb4c58c5af6d52b642c32f2f9b036be4'),(1964060854,2713591,651,651,NULL,'2019-06-18 02:57:01.148','2019-10-15 15:19:40.958',NULL,NULL,'abbc9ffe66ce00a030d2ebec69ffb5cc'),(1711620555,13844715,622,481,4,'2019-03-15 15:29:45.418','2019-03-15 15:29:45.418','2017-05-19 01:50:28.000',NULL,'12396044cbad06c5ecba79713b6ebaf8'),(8651851,2713592,39,39,NULL,'2017-09-18 12:32:09.093','2019-08-08 00:34:11.683',NULL,NULL,'4057fe580e494350dc7793a43220f945'),(1964060852,2713592,651,651,NULL,'2019-06-18 02:57:01.008','2019-10-15 15:18:53.409',NULL,NULL,'f8899a4b5d24872df5132da41c5c2f7e');
/*!40000 ALTER TABLE `indicator_sources` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`threatquotient`@`localhost`*/ /*!50003 TRIGGER trig_indicator_sources_before_insert BEFORE INSERT ON indicator_sources
FOR EACH ROW BEGIN

  DECLARE defaultTlpId INTEGER UNSIGNED;

  SELECT fn_get_default_tlp_id_for_source(NEW.source_id) INTO defaultTlpId;

  IF (defaultTlpId IS NOT NULL) AND (NEW.tlp_id IS NULL)
  THEN
    SET NEW.tlp_id = defaultTlpId;
  END IF;

  SET NEW.sync_hash = MD5(CONCAT(NEW.indicator_id, '-', NEW.source_id, '-', NEW.creator_source_id));

END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`threatquotient`@`localhost`*/ /*!50003 TRIGGER trig_indicator_sources_after_insert AFTER INSERT ON indicator_sources
FOR EACH ROW BEGIN

  INSERT INTO
    indicator_source_audit_log (indicator_source_id, event_type, field, new_value, run_uuid, changed_by_source_id)
  VALUES
    (NEW.id, 'added', 'source_id', NEW.source_id, fn_uuid_to_binary(@CONNECTOR_RUN_UUID), @OWNER_SOURCE_ID);

  IF IFNULL(NEW.tlp_id, 0) <> 0
  THEN
    INSERT INTO
      indicator_source_audit_log (indicator_source_id, event_type, field, new_value, run_uuid, changed_by_source_id)
    VALUES
      (NEW.id, 'added', 'tlp_id', NEW.tlp_id, fn_uuid_to_binary(@CONNECTOR_RUN_UUID), @OWNER_SOURCE_ID);
  END IF;

  IF IFNULL(NEW.published_at, '0000-00-00 00:00:00.000') <> '0000-00-00 00:00:00.000'
  THEN
    INSERT INTO
      indicator_source_audit_log (indicator_source_id, event_type, field, new_value, run_uuid, changed_by_source_id)
    VALUES
      (NEW.id, 'added', 'published_at', NEW.published_at, fn_uuid_to_binary(@CONNECTOR_RUN_UUID), @OWNER_SOURCE_ID);
  END IF;

  IF @CONNECTOR_RUN_UUID IS NOT NULL
  THEN
    INSERT INTO
      connector_run_objects (run_uuid, object_id, object_type)
    VALUES
      (fn_uuid_to_binary(@CONNECTOR_RUN_UUID), NEW.id, 'indicator_sources');
  END IF;

  IF IFNULL(@SCORE_INDICATOR, TRUE) THEN
    IF fn_source_scorable(NEW.source_id) <> 'N' THEN
      SET @TOUCH_PARENT_INDICATOR_OLD = @TOUCH_PARENT_INDICATOR;
      SET @TOUCH_PARENT_INDICATOR = FALSE;

      INSERT
      INTO
        indicator_scores
      (
        indicator_id,
        score_config_hash
      )
      VALUES
      (
        NEW.indicator_id,
        'pending_score'
      )
      ON DUPLICATE KEY
      UPDATE
        score_config_hash = 'pending_score';

      SET @TOUCH_PARENT_INDICATOR = @TOUCH_PARENT_INDICATOR_OLD;
    END IF;
  END IF;

  -- touch parent
  IF IFNULL(@TOUCH_PARENT_INDICATOR, TRUE)
  THEN
    UPDATE
      indicators
    SET
      updated_at = updated_at,
      touched_at = NOW(3)
    WHERE
      id = NEW.indicator_id;
  END IF;

END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`threatquotient`@`localhost`*/ /*!50003 TRIGGER trig_indicator_sources_before_update BEFORE UPDATE ON indicator_sources
FOR EACH ROW BEGIN

  IF OLD.indicator_id <> NEW.indicator_id OR
    OLD.source_id <> NEW.source_id OR
    OLD.creator_source_id <> NEW.creator_source_id
  THEN
    SET NEW.sync_hash = MD5(CONCAT(NEW.indicator_id, '-', NEW.source_id, '-', NEW.creator_source_id));
  END IF;

END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`threatquotient`@`localhost`*/ /*!50003 TRIGGER trig_indicator_sources_after_update AFTER UPDATE ON indicator_sources
FOR EACH ROW indicator_sources_update_trigger: BEGIN

  DECLARE connectorRunUuid BINARY(16);

  IF (@TRIGGER_AFTER_UPDATE_INDICATOR_SOURCES = FALSE) AND (USER() = 'threatquotient@localhost')
  THEN
    LEAVE indicator_sources_update_trigger;
  END IF;

  -- Audit Logging
  IF IFNULL(OLD.source_id, '') <> IFNULL(NEW.source_id, '')
  THEN
    INSERT INTO
      indicator_source_audit_log (indicator_source_id, event_type, field, new_value, run_uuid, changed_by_source_id)
    VALUES
      (NEW.id, 'updated', 'value', NEW.source_id, fn_uuid_to_binary(@CONNECTOR_RUN_UUID), @OWNER_SOURCE_ID)
    ON DUPLICATE KEY UPDATE
      event_type = VALUES(event_type),
      new_value = VALUES(new_value),
      changed_by_source_id = VALUES(changed_by_source_id);
  END IF;

  IF IFNULL(OLD.tlp_id, 0) <> IFNULL(NEW.tlp_id, 0)
  THEN
    INSERT INTO
      indicator_source_audit_log (indicator_source_id, event_type, field, new_value, run_uuid, changed_by_source_id)
    VALUES
      (NEW.id, 'updated', 'tlp_id', NEW.tlp_id, fn_uuid_to_binary(@CONNECTOR_RUN_UUID), @OWNER_SOURCE_ID)
    ON DUPLICATE KEY UPDATE
      event_type = VALUES(event_type),
      new_value = VALUES(new_value),
      changed_by_source_id = VALUES(changed_by_source_id);
  END IF;

  IF IFNULL(OLD.published_at, '0000-00-00 00:00:00.000') <> IFNULL(NEW.published_at, '0000-00-00 00:00:00.000')
  THEN
    INSERT INTO
      indicator_source_audit_log (indicator_source_id, event_type, field, new_value, run_uuid, changed_by_source_id)
    VALUES
      (NEW.id, 'updated', 'published_at', NEW.published_at, fn_uuid_to_binary(@CONNECTOR_RUN_UUID), @OWNER_SOURCE_ID)
    ON DUPLICATE KEY UPDATE
      event_type = VALUES(event_type),
      new_value = VALUES(new_value),
      changed_by_source_id = VALUES(changed_by_source_id);
  END IF;

  IF @CONNECTOR_RUN_UUID IS NOT NULL
  THEN
    SELECT
      run_uuid
    INTO
      connectorRunUuid
    FROM
      connector_run_objects
    WHERE
      run_uuid = fn_uuid_to_binary(@CONNECTOR_RUN_UUID) AND object_id = NEW.id AND object_type = 'indicator_sources';

    IF ISNULL(connectorRunUuid)
    THEN
      INSERT INTO
        connector_run_objects (run_uuid, object_id, object_type)
      VALUES
        (fn_uuid_to_binary(@CONNECTOR_RUN_UUID), NEW.id, 'indicator_sources');
    END IF;
  END IF;

  IF IFNULL(@SCORE_INDICATOR, TRUE) THEN
    IF IFNULL(OLD.deleted_at, '') <> IFNULL(NEW.deleted_at, '') THEN
      SET @TOUCH_PARENT_INDICATOR_OLD = @TOUCH_PARENT_INDICATOR;
      SET @TOUCH_PARENT_INDICATOR = FALSE;

      INSERT
      INTO
        indicator_scores
      (
        indicator_id,
        score_config_hash
      )
      VALUES
      (
        NEW.indicator_id,
        'pending_score'
      )
      ON DUPLICATE KEY
      UPDATE
        score_config_hash = 'pending_score';

      SET @TOUCH_PARENT_INDICATOR = @TOUCH_PARENT_INDICATOR_OLD;
    END IF;
  END IF;

  -- touch parent
  IF IFNULL(@TOUCH_PARENT_INDICATOR, TRUE)
  THEN
    UPDATE
      indicators
    SET
      updated_at = updated_at,
      touched_at = NOW(3)
    WHERE
      id = NEW.indicator_id;
  END IF;

END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-10-31 14:05:05
