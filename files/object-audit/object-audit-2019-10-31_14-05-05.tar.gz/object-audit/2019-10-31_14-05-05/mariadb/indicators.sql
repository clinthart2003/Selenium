-- MySQL dump 10.16  Distrib 10.3.9-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: threatquotient2
-- ------------------------------------------------------
-- Server version	10.3.9-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `indicators`
--

DROP TABLE IF EXISTS `indicators`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `indicators` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type_id` int(10) unsigned NOT NULL,
  `status_id` int(10) unsigned NOT NULL,
  `class` enum('host','network') COLLATE utf8_unicode_ci NOT NULL,
  `hash` char(32) COLLATE utf8_unicode_ci NOT NULL,
  `value` text COLLATE utf8_unicode_ci NOT NULL,
  `description` longtext COLLATE utf8_unicode_ci DEFAULT NULL,
  `last_detected_at` datetime(3) DEFAULT NULL,
  `expires_at` datetime(3) DEFAULT NULL,
  `expired_at` datetime(3) DEFAULT NULL,
  `expires_needs_calc` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `expires_calculated_at` datetime(3) DEFAULT NULL,
  `created_at` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `updated_at` datetime(3) NOT NULL DEFAULT current_timestamp(3) ON UPDATE current_timestamp(3),
  `touched_at` datetime(3) NOT NULL DEFAULT current_timestamp(3) ON UPDATE current_timestamp(3) COMMENT 'Date and time the Indicator or its'' relational data was modified.',
  `deleted_at` datetime(3) DEFAULT NULL,
  `sync_hash` char(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `indicators_type_id_index` (`type_id`),
  KEY `indicators_status_id_index` (`status_id`),
  KEY `indicators_created_at_index` (`created_at`),
  KEY `indicators_class_index` (`class`),
  KEY `indicators_hash_index` (`hash`),
  KEY `indicators_last_detected_at_index` (`last_detected_at`),
  KEY `indicators_deleted_at_index` (`deleted_at`),
  KEY `indicators_value_index` (`value`(255)),
  KEY `indicators_type_id_hash_index` (`type_id`,`hash`),
  KEY `indicators_expires_at_index` (`expires_at`),
  KEY `indicators_expired_at_index` (`expired_at`),
  KEY `indicators_expires_calculated_at_index` (`expires_calculated_at`),
  KEY `indicators_touched_at_index` (`touched_at`),
  KEY `indicators_updated_at_index` (`updated_at`),
  KEY `indicators_expires_needs_calc_index` (`expires_needs_calc`),
  KEY `sync_hash_index` (`sync_hash`)
) ENGINE=InnoDB AUTO_INCREMENT=24592890 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `indicators`
--
-- WHERE:  `id` in (SELECT id FROM `object_audit_id_lookup` WHERE key_column = 'indicator_id')

LOCK TABLES `indicators` WRITE;
/*!40000 ALTER TABLE `indicators` DISABLE KEYS */;
INSERT  IGNORE INTO `indicators` VALUES (13844370,8,1,'network','1a9d7445f3b08f6f0cae67bcac94597f','jamaican-vents.autos',NULL,NULL,NULL,NULL,'N','2019-09-10 05:30:49.606','2019-03-15 15:26:44.708','2019-09-12 03:53:33.536','2019-09-12 03:53:33.536',NULL,'9f93593b59a80205506e2234dc3d95d8'),(13844372,8,1,'network','1a9d7445f3b08f6f0cae67bcac94597f','jamaican-vents.autos',NULL,NULL,NULL,NULL,'N','2019-09-10 05:30:49.613','2019-03-15 15:26:44.708','2019-09-12 03:53:33.553','2019-09-12 03:53:33.553',NULL,'9f93593b59a80205506e2234dc3d95d8'),(13844309,8,1,'network','f102210da46957d1a1dace98b1ba6c49','[redacted].wufoo.com',NULL,NULL,NULL,NULL,'N','2019-09-10 05:30:49.190','2019-03-15 15:26:13.493','2019-09-12 03:53:33.726','2019-09-12 03:53:33.726',NULL,'69797d5eaddb952d0adfc391bb537818'),(13844310,8,1,'network','f102210da46957d1a1dace98b1ba6c49','[redacted].wufoo.com',NULL,NULL,NULL,NULL,'N','2019-09-10 05:30:49.194','2019-03-15 15:26:13.493','2019-09-12 03:53:33.731','2019-09-12 03:53:33.731',NULL,'69797d5eaddb952d0adfc391bb537818'),(13842319,8,1,'network','c127a550cf236dec481d0c94aa5b47f0','dooblo.net',NULL,NULL,NULL,NULL,'N','2019-09-10 05:29:43.553','2019-03-15 15:14:09.352','2019-09-12 03:53:19.660','2019-09-12 03:53:19.660',NULL,'7d1766cffa6a45d9597cd5a864beb762'),(13842334,8,1,'network','c127a550cf236dec481d0c94aa5b47f0','dooblo.net',NULL,NULL,NULL,NULL,'N','2019-09-10 05:29:43.604','2019-03-15 15:14:09.352','2019-09-12 03:53:19.713','2019-09-12 03:53:19.713',NULL,'7d1766cffa6a45d9597cd5a864beb762'),(13842316,8,1,'network','e09edfbadb0ac99a3a74f5a743ad3c31','haberkat.com',NULL,NULL,NULL,NULL,'N','2019-09-10 05:29:43.542','2019-03-15 15:14:09.352','2019-09-12 03:53:19.648','2019-09-12 03:53:19.648',NULL,'4329c3b981af76e1a23aa41607f7cd7f'),(13842321,8,1,'network','e09edfbadb0ac99a3a74f5a743ad3c31','haberkat.com',NULL,NULL,NULL,NULL,'N','2019-09-10 05:29:43.560','2019-03-15 15:14:09.352','2019-09-12 04:05:42.992','2019-09-12 04:05:42.992',NULL,'4329c3b981af76e1a23aa41607f7cd7f'),(13749394,21,1,'network','04477960340c92bb2b130f77d80f69bf','app.adjust.com/q96t2k',NULL,NULL,NULL,NULL,'N','2019-09-10 07:49:25.475','2019-03-11 17:25:39.002','2019-09-12 13:47:04.390','2019-09-12 13:47:04.390',NULL,'2b6653028f0a3de56bf7236966c18090'),(13749395,21,1,'network','04477960340c92bb2b130f77d80f69bf','app.adjust.com/q96t2k',NULL,NULL,NULL,NULL,'N','2019-09-10 07:49:25.478','2019-03-11 17:25:39.002','2019-09-12 13:47:04.393','2019-09-12 13:47:04.393',NULL,'2b6653028f0a3de56bf7236966c18090'),(13749396,21,1,'network','04477960340c92bb2b130f77d80f69bf','app.adjust.com/q96t2k',NULL,NULL,NULL,NULL,'N','2019-09-10 07:49:25.480','2019-03-11 17:25:39.002','2019-09-12 13:47:04.406','2019-09-12 13:47:04.406',NULL,'2b6653028f0a3de56bf7236966c18090'),(13749397,21,1,'network','04477960340c92bb2b130f77d80f69bf','app.adjust.com/q96t2k',NULL,NULL,NULL,NULL,'N','2019-09-10 07:49:25.482','2019-03-11 17:25:39.002','2019-09-12 13:47:04.409','2019-09-12 13:47:04.409',NULL,'2b6653028f0a3de56bf7236966c18090'),(13749398,21,1,'network','04477960340c92bb2b130f77d80f69bf','app.adjust.com/q96t2k',NULL,NULL,NULL,NULL,'N','2019-09-10 07:49:25.485','2019-03-11 17:25:39.002','2019-09-12 13:47:04.403','2019-09-12 13:47:04.403',NULL,'2b6653028f0a3de56bf7236966c18090'),(12922652,13,1,'host','b92f19cab8ae3ab829473fb67c513329','windowsupdate',NULL,NULL,NULL,NULL,'N','2019-09-10 05:13:17.902','2019-01-10 22:37:44.478','2019-09-12 14:35:15.584','2019-09-12 14:35:15.584',NULL,'833e9113c41d1c4d10054abec102c229'),(3361708,13,1,'host','b92f19cab8ae3ab829473fb67c513329','windowsupdate',NULL,NULL,NULL,NULL,'N','2019-09-09 20:51:23.386','2017-09-27 12:56:48.775','2019-09-12 09:48:23.502','2019-09-12 09:48:23.502',NULL,'833e9113c41d1c4d10054abec102c229'),(12940095,14,1,'host','1fc5a74734314b4d41118278cb00adc8','Palermo90',NULL,NULL,NULL,NULL,'N','2019-09-10 05:10:24.849','2019-01-10 22:32:44.871','2019-09-12 14:46:04.645','2019-09-12 14:46:04.645',NULL,'e92ec59526f49a02c363e7a16e927541'),(4063043,14,1,'host','1fc5a74734314b4d41118278cb00adc8','Palermo90',NULL,NULL,NULL,NULL,'N','2019-09-10 03:02:46.462','2017-10-01 21:45:15.799','2019-09-12 12:53:47.755','2019-09-12 12:53:47.755',NULL,'e92ec59526f49a02c363e7a16e927541'),(13844736,7,1,'host','01f48786dedd273961e8c2f861e8c2f8','cmd.exe',NULL,NULL,NULL,NULL,'N','2019-09-10 05:30:50.102','2019-01-10 22:06:27.932','2019-09-12 04:06:09.095','2019-09-12 04:06:09.095',NULL,'f326920a34c41a76647a87629d599ea6'),(23,7,1,'host','01f48786dedd273961e8c2f861e8c2f8','cmd.exe',NULL,NULL,NULL,NULL,'N','2019-09-09 17:50:15.953','2017-09-14 06:38:25.774','2019-09-11 17:54:01.433','2019-09-11 17:54:01.433',NULL,'f326920a34c41a76647a87629d599ea6'),(602,7,1,'host','01f48786dedd273961e8c2f861e8c2f8','cmd.exe',NULL,NULL,NULL,NULL,'N','2019-09-09 17:50:16.618','2017-09-14 06:49:37.054','2019-09-11 17:21:23.644','2019-09-11 17:21:23.644',NULL,'f326920a34c41a76647a87629d599ea6'),(12735005,12,1,'host','40ca2bbc12d7801a4d07d2ad3200780a','0a6c5d14e492b04b0d6ad6a0554b9386',NULL,NULL,NULL,NULL,'N','2019-09-10 01:05:51.522','2019-01-10 19:55:20.021','2019-09-12 11:20:33.063','2019-09-12 11:20:33.063',NULL,'cc9f425be871c025e5114f35418d8287'),(12916295,12,1,'host','40ca2bbc12d7801a4d07d2ad3200780a','0a6c5d14e492b04b0d6ad6a0554b9386',NULL,NULL,NULL,NULL,'N','2019-09-09 14:54:51.963','2019-01-10 19:55:20.021','2019-09-11 16:05:17.204','2019-09-11 16:05:17.204',NULL,'cc9f425be871c025e5114f35418d8287'),(12735006,17,1,'host','31fa9dc64e627f5b60e53ea2d3ac47fe','925b5dd0dbe0672e0c2cd906d382fe3b498460062a140ee70b77d771a29c3d68',NULL,NULL,NULL,NULL,'N','2019-09-10 01:05:51.525','2019-01-10 19:55:19.563','2019-09-12 11:20:33.087','2019-09-12 11:20:33.087',NULL,'9e04b7e7dbc0179ac79ed64ee285cbac'),(12916294,17,1,'host','31fa9dc64e627f5b60e53ea2d3ac47fe','925b5dd0dbe0672e0c2cd906d382fe3b498460062a140ee70b77d771a29c3d68',NULL,NULL,NULL,NULL,'N','2019-09-10 05:07:48.240','2019-01-10 19:55:19.563','2019-09-12 14:35:08.283','2019-09-12 14:35:08.283',NULL,'9e04b7e7dbc0179ac79ed64ee285cbac'),(12735004,16,1,'host','583e3693975289ba4d7beb6dfb41a0e2','1ec530d4c52d35863a1b4b3dd6d6bac1c041e07c',NULL,NULL,NULL,NULL,'N','2019-09-10 01:05:51.519','2019-01-10 19:55:19.444','2019-09-12 11:20:33.070','2019-09-12 11:20:33.070',NULL,'669bf18c52e89d915b8435e1c7f31e2b'),(12916293,16,1,'host','583e3693975289ba4d7beb6dfb41a0e2','1ec530d4c52d35863a1b4b3dd6d6bac1c041e07c',NULL,NULL,NULL,NULL,'N','2019-09-10 05:07:48.237','2019-01-10 19:55:19.444','2019-09-12 14:35:08.287','2019-09-12 14:35:08.287',NULL,'669bf18c52e89d915b8435e1c7f31e2b'),(13844750,12,1,'host','dd990c986d818745e65eddc601e55b24','f107a717f76f4f910ae9cb4dc5290594',NULL,NULL,NULL,NULL,'N','2019-09-09 16:04:32.278','2019-01-08 11:47:15.705','2019-09-11 16:42:43.791','2019-09-11 16:42:43.791',NULL,'12edc45df705dd382e6e2a2a8b8d1404'),(12202156,12,1,'host','dd990c986d818745e65eddc601e55b24','f107a717f76f4f910ae9cb4dc5290594',NULL,NULL,NULL,NULL,'N','2019-10-07 15:25:05.873','2019-01-08 11:47:15.705','2019-09-30 15:20:16.537','2019-10-07 15:21:11.502',NULL,'12edc45df705dd382e6e2a2a8b8d1404'),(13844751,16,1,'host','260e7fadd964c92d5486f3b014c41efa','51e4307093f8ca8854359c0ac882ddca427a813c',NULL,NULL,NULL,NULL,'N','2019-09-10 05:30:50.142','2019-01-08 11:47:15.043','2019-09-12 04:06:09.090','2019-09-12 04:06:09.090',NULL,'66348547c2e2417200b8c031f5e81195'),(12202091,16,1,'host','260e7fadd964c92d5486f3b014c41efa','51e4307093f8ca8854359c0ac882ddca427a813c',NULL,NULL,NULL,NULL,'N','2019-10-07 15:20:06.226','2019-01-08 11:47:15.043','2019-09-30 15:20:16.475','2019-10-07 15:20:05.913',NULL,'66348547c2e2417200b8c031f5e81195'),(13844752,17,1,'host','7fb7fd142fe1bd3c5c70cad7a9b073e9','f8812f1deb8001f3b7672b6fc85640ecb123bc2304b563728e6235ccbe782d85',NULL,NULL,NULL,NULL,'N','2019-09-10 05:30:50.145','2019-01-08 11:46:52.107','2019-09-12 04:06:09.158','2019-09-12 04:06:09.158',NULL,'0e5bfaa2f0d6cc5150f997fd8fa6130d'),(12202182,17,1,'host','7fb7fd142fe1bd3c5c70cad7a9b073e9','f8812f1deb8001f3b7672b6fc85640ecb123bc2304b563728e6235ccbe782d85',NULL,NULL,NULL,NULL,'N','2019-10-07 15:20:03.405','2019-01-08 11:46:52.107','2019-09-30 15:19:12.361','2019-10-07 15:19:38.799',NULL,'0e5bfaa2f0d6cc5150f997fd8fa6130d'),(13844774,17,1,'host','1fc0260fd33128583ac62b26bfd41c1f','09a46b3e1be080745a6d8d88d6b5bd351b1c7586ae0dc94d0c238ee36421cafa',NULL,NULL,NULL,NULL,'N','2019-09-10 05:30:50.201','2019-01-06 19:04:58.217','2019-09-12 04:06:09.247','2019-09-12 04:06:09.247',NULL,'1933b963aacbcb26e4912bd68d94dbec'),(2713586,17,1,'host','1fc0260fd33128583ac62b26bfd41c1f','09a46b3e1be080745a6d8d88d6b5bd351b1c7586ae0dc94d0c238ee36421cafa',NULL,NULL,NULL,NULL,'N','2019-10-29 22:40:02.680','2017-09-18 12:32:08.070','2019-09-10 22:51:57.489','2019-10-29 22:32:53.636',NULL,'1933b963aacbcb26e4912bd68d94dbec'),(13844772,12,1,'host','31acf1c65431d8c31f59df614793c3dc','509c41ec97bb81b0567b059aa2f50fe8',NULL,NULL,NULL,NULL,'N','2019-09-09 16:04:32.816','2019-01-06 19:04:43.547','2019-09-11 16:42:44.083','2019-09-11 16:42:44.083',NULL,'765c6165c8248d5274d03e2ef365065c'),(2713587,12,1,'host','31acf1c65431d8c31f59df614793c3dc','509c41ec97bb81b0567b059aa2f50fe8',NULL,NULL,NULL,NULL,'N','2019-09-09 15:32:27.527','2017-09-18 12:32:08.070','2019-09-11 16:25:47.429','2019-09-11 16:25:47.429',NULL,'765c6165c8248d5274d03e2ef365065c'),(13844713,12,1,'host','d691101557305bb6f20a79d8f5fcd1cd','db349b97c37d22f5ea1d1841e3c89eb4',NULL,NULL,NULL,NULL,'N','2019-09-09 16:04:32.792','2019-01-06 19:04:42.879','2019-09-11 16:42:46.068','2019-09-11 16:42:46.068',NULL,'39514833e560f524010885970290d7c6'),(2713593,12,1,'host','d691101557305bb6f20a79d8f5fcd1cd','db349b97c37d22f5ea1d1841e3c89eb4',NULL,NULL,NULL,NULL,'N','2019-10-16 15:20:01.984','2017-09-18 12:32:08.070','2019-09-13 22:52:50.676','2019-10-16 15:19:08.881',NULL,'39514833e560f524010885970290d7c6'),(13844773,16,1,'host','04104cb5d1210739d15e43d0b5af1afe','87420a2791d18dad3f18be436045280a4cc16fc4',NULL,NULL,NULL,NULL,'N','2019-09-10 05:30:50.197','2019-01-06 19:04:42.615','2019-09-12 04:06:09.241','2019-09-12 04:06:09.241',NULL,'cab13f1a7d238bfe7f25fd2fb75f630a'),(2713585,16,1,'host','04104cb5d1210739d15e43d0b5af1afe','87420a2791d18dad3f18be436045280a4cc16fc4',NULL,NULL,NULL,NULL,'N','2019-09-10 10:10:24.953','2017-09-18 12:32:08.070','2019-09-12 01:54:11.269','2019-09-12 01:54:11.269',NULL,'cab13f1a7d238bfe7f25fd2fb75f630a'),(13844714,16,1,'host','353819a89ebcf69748fd98dcf99137ed','e889544aff85ffaf8b0d0da705105dee7c97fe26',NULL,NULL,NULL,NULL,'N','2019-09-10 09:23:21.653','2019-01-06 19:04:42.120','2019-09-12 04:06:09.402','2019-09-12 04:06:09.402',NULL,'abf5be7695c29509bf05ae161e61f7a7'),(2713591,16,1,'host','353819a89ebcf69748fd98dcf99137ed','e889544aff85ffaf8b0d0da705105dee7c97fe26',NULL,NULL,NULL,NULL,'N','2019-10-15 15:20:02.129','2017-09-18 12:32:08.070','2019-09-13 22:52:26.943','2019-10-15 15:19:40.958',NULL,'abf5be7695c29509bf05ae161e61f7a7'),(13844715,17,1,'host','6cde9212cc355079e2a5bf128a16992b','24d004a104d4d54034dbcffc2a4b19a11f39008a575aa614ea04703480b1022c',NULL,NULL,NULL,NULL,'N','2019-09-10 09:23:21.657','2019-01-06 19:04:41.338','2019-09-12 04:06:09.407','2019-09-12 04:06:09.407',NULL,'069acb3556d2b1050f7e9a22ae9376b6'),(2713592,17,1,'host','6cde9212cc355079e2a5bf128a16992b','24d004a104d4d54034dbcffc2a4b19a11f39008a575aa614ea04703480b1022c',NULL,NULL,NULL,NULL,'N','2019-10-15 15:20:02.132','2017-09-18 12:32:08.070','2019-09-13 22:52:26.923','2019-10-15 15:18:53.409',NULL,'069acb3556d2b1050f7e9a22ae9376b6');
/*!40000 ALTER TABLE `indicators` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`threatquotient`@`localhost`*/ /*!50003 TRIGGER trig_indicators_before_insert BEFORE INSERT ON indicators
FOR EACH ROW BEGIN

  IF new.status_id = fn_indicator_status_id('Expired')
  THEN
    SET new.expired_at = NOW(3);
  END IF;

  SET NEW.sync_hash = MD5(CONCAT(NEW.value, '-', NEW.type_id));

END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`threatquotient`@`localhost`*/ /*!50003 TRIGGER trig_indicators_after_insert AFTER INSERT ON indicators
FOR EACH ROW BEGIN

  INSERT INTO
    indicator_audit_log (indicator_id, event_type, field, new_value, run_uuid, changed_by_source_id)
  VALUES
    (NEW.id, 'added', 'value', NEW.value, fn_uuid_to_binary(@CONNECTOR_RUN_UUID), @OWNER_SOURCE_ID);

  INSERT INTO
    indicator_audit_log (indicator_id, event_type, field, new_value, run_uuid, changed_by_source_id)
  VALUES
    (NEW.id, 'added', 'type_id', NEW.type_id, fn_uuid_to_binary(@CONNECTOR_RUN_UUID), @OWNER_SOURCE_ID);

  INSERT INTO
    indicator_audit_log (indicator_id, event_type, field, new_value, run_uuid, changed_by_source_id)
  VALUES
    (NEW.id, 'added', 'status_id', NEW.status_id, fn_uuid_to_binary(@CONNECTOR_RUN_UUID), @OWNER_SOURCE_ID);

  INSERT INTO
    indicator_audit_log (indicator_id, event_type, field, new_value, run_uuid, changed_by_source_id)
  VALUES
    (NEW.id, 'added', 'class', NEW.class, fn_uuid_to_binary(@CONNECTOR_RUN_UUID), @OWNER_SOURCE_ID);

  INSERT INTO
    indicator_audit_log (indicator_id, event_type, field, new_value, run_uuid, changed_by_source_id)
  VALUES
    (NEW.id, 'added', 'description', NEW.description, fn_uuid_to_binary(@CONNECTOR_RUN_UUID), @OWNER_SOURCE_ID);

  IF NEW.last_detected_at IS NOT NULL
  THEN
    INSERT INTO
      indicator_audit_log (indicator_id, event_type, field, new_value, run_uuid, changed_by_source_id)
    VALUES
      (NEW.id, 'added', 'last_detected_at', NEW.last_detected_at, fn_uuid_to_binary(@CONNECTOR_RUN_UUID), @OWNER_SOURCE_ID);
  END IF;

  IF NEW.expires_at IS NOT NULL
  THEN
    INSERT INTO
      indicator_audit_log (indicator_id, event_type, field, new_value, run_uuid, changed_by_source_id)
    VALUES
      (NEW.id, 'added', 'expires_at', NEW.expires_at, fn_uuid_to_binary(@CONNECTOR_RUN_UUID), @OWNER_SOURCE_ID);
  END IF;

  IF NEW.expired_at IS NOT NULL
  THEN
    INSERT INTO
      indicator_audit_log (indicator_id, event_type, field, new_value, run_uuid, changed_by_source_id)
    VALUES
      (NEW.id, 'added', 'expired_at', NEW.expired_at, fn_uuid_to_binary(@CONNECTOR_RUN_UUID), @OWNER_SOURCE_ID);
  END IF;

  IF @CONNECTOR_RUN_UUID IS NOT NULL
  THEN
    INSERT INTO
      connector_run_objects (run_uuid, object_id, object_type)
    VALUES
      (fn_uuid_to_binary(@CONNECTOR_RUN_UUID), NEW.id, 'indicators');
  END IF;

  SET @TOUCH_PARENT_INDICATOR_OLD = @TOUCH_PARENT_INDICATOR;
  SET @TOUCH_PARENT_INDICATOR = FALSE;

  INSERT
  INTO
    indicator_scores
  (
    indicator_id,
    score_config_hash
  )
  VALUES
  (
    NEW.id,
    IF(
      fn_indicator_type_scorable(NEW.type_id) <> 'N',
      'pending_score',
      fn_score_config_hash()
    )
  );

  SET @TOUCH_PARENT_INDICATOR = @TOUCH_PARENT_INDICATOR_OLD;

END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`threatquotient`@`localhost`*/ /*!50003 TRIGGER trig_indicators_before_update BEFORE UPDATE ON indicators
FOR EACH ROW BEGIN
  DECLARE expiredStatusId INTEGER UNSIGNED;
  DECLARE whitelistedStatusId INTEGER UNSIGNED;

  -- Expiration
  IF IFNULL(OLD.expired_at, '') <> IFNULL(NEW.expired_at, '') THEN
    SET NEW.expires_calculated_at = NEW.touched_at;
  END IF;

  IF IFNULL(@PROTECT_INDICATOR_STATUS, FALSE) THEN
    IF fn_indicator_status_id_protected(OLD.status_id) <> 'N' THEN
      SET NEW.status_id = OLD.status_id;
    END IF;
  END IF;

  IF OLD.description IS NOT NULL AND IFNULL(@ALLOW_DESCRIPTION_OVERRIDE, TRUE) = FALSE
    THEN
    SET NEW.description = OLD.description;
  END IF;

  IF NEW.status_id <> OLD.status_id THEN
    SET expiredStatusId = fn_indicator_status_id('Expired');

    IF NEW.status_id = expiredStatusId THEN
      SET NEW.expires_at = NULL;
      SET NEW.expired_at = NOW(3);
    ELSE
      IF OLD.status_id = expiredStatusId THEN
        SET NEW.expired_at = NULL;
        SET NEW.expires_at = NULL;
      END IF;

      SET whitelistedStatusId = fn_indicator_status_id('Whitelisted');

      IF NEW.status_id = whitelistedStatusId THEN
        SET NEW.expired_at = NULL;
        SET NEW.expires_at = NULL;
      END IF;
    END IF;
  END IF;

  IF NOT NEW.expires_needs_calc = 'Y' THEN
    SET NEW.expires_needs_calc = fn_indicator_calc_expiration_needed(
        NEW.status_id,
        NEW.expires_at,
        NEW.expires_calculated_at,
        NEW.touched_at,
        NEW.deleted_at
    );
  END IF;

  IF OLD.type_id <> NEW.type_id OR OLD.value <> NEW.value THEN
    SET NEW.sync_hash = MD5(CONCAT(NEW.value, '-', NEW.type_id));
  END IF;

  IF IFNULL(@SCORE_INDICATOR, TRUE) THEN
    IF (
      OLD.type_id <> NEW.type_id
      OR IFNULL(OLD.deleted_at, '') <> IFNULL(NEW.deleted_at, '')
    )
    AND NEW.deleted_at IS NULL THEN
      SET @TOUCH_PARENT_INDICATOR_OLD = @TOUCH_PARENT_INDICATOR;
      SET @TOUCH_PARENT_INDICATOR = FALSE;

      INSERT
      INTO
        indicator_scores
      (
        indicator_id,
        score_config_hash
      )
      VALUES
      (
        NEW.id,
        'pending_score'
      )
      ON DUPLICATE KEY
      UPDATE
        score_config_hash = 'pending_score';

      SET NEW.touched_at = NOW(3);

      SET @TOUCH_PARENT_INDICATOR = @TOUCH_PARENT_INDICATOR_OLD;
    END IF;
  END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`threatquotient`@`localhost`*/ /*!50003 TRIGGER trig_indicators_after_update AFTER UPDATE ON indicators
FOR EACH ROW BEGIN

  DECLARE connectorRunUuid BINARY(16);

  -- Audit Logging
  IF IFNULL(OLD.type_id, '') <> IFNULL(NEW.type_id, '')
  THEN
    INSERT INTO
      indicator_audit_log (indicator_id, event_type, field, new_value, run_uuid, changed_by_source_id)
    VALUES
      (NEW.id, 'updated', 'type_id', NEW.type_id, fn_uuid_to_binary(@CONNECTOR_RUN_UUID), @OWNER_SOURCE_ID)
    ON DUPLICATE KEY UPDATE
      event_type = VALUES(event_type),
      new_value = VALUES(new_value),
      changed_by_source_id = VALUES(changed_by_source_id);
  END IF;

  IF IFNULL(OLD.status_id, '') <> IFNULL(NEW.status_id, '')
  THEN
    INSERT INTO
      indicator_audit_log (indicator_id, event_type, field, new_value, run_uuid, changed_by_source_id)
    VALUES
      (NEW.id, 'updated', 'status_id', NEW.status_id, fn_uuid_to_binary(@CONNECTOR_RUN_UUID), @OWNER_SOURCE_ID)
    ON DUPLICATE KEY UPDATE
      event_type = VALUES(event_type),
      new_value = VALUES(new_value),
      changed_by_source_id = VALUES(changed_by_source_id);
  END IF;

  IF IFNULL(OLD.class, '') <> IFNULL(NEW.class, '')
  THEN
    INSERT INTO
      indicator_audit_log (indicator_id, event_type, field, new_value, run_uuid, changed_by_source_id)
    VALUES
      (NEW.id, 'updated', 'class', NEW.class, fn_uuid_to_binary(@CONNECTOR_RUN_UUID), @OWNER_SOURCE_ID)
    ON DUPLICATE KEY UPDATE
      event_type = VALUES(event_type),
      new_value = VALUES(new_value),
      changed_by_source_id = VALUES(changed_by_source_id);
  END IF;

  IF IFNULL(OLD.value, '') <> IFNULL(NEW.value, '')
  THEN
    INSERT INTO
      indicator_audit_log (indicator_id, event_type, field, new_value, run_uuid, changed_by_source_id)
    VALUES
      (NEW.id, 'updated', 'value', NEW.value, fn_uuid_to_binary(@CONNECTOR_RUN_UUID), @OWNER_SOURCE_ID)
    ON DUPLICATE KEY UPDATE
      event_type = VALUES(event_type),
      new_value = VALUES(new_value),
      changed_by_source_id = VALUES(changed_by_source_id);

    UPDATE
      investigation_nodes
    SET
      label = NEW.value
    WHERE
      object_id = NEW.id AND
      object_type = 'indicator';
  END IF;

  IF IFNULL(OLD.description, '') <> IFNULL(NEW.description, '')
  THEN
    INSERT INTO
      indicator_audit_log (indicator_id, event_type, field, new_value, run_uuid, changed_by_source_id)
    VALUES
      (NEW.id, 'updated', 'description', NEW.description, fn_uuid_to_binary(@CONNECTOR_RUN_UUID), @OWNER_SOURCE_ID)
    ON DUPLICATE KEY UPDATE
      event_type = VALUES(event_type),
      new_value = VALUES(new_value),
      changed_by_source_id = VALUES(changed_by_source_id);
  END IF;

  IF IFNULL(OLD.last_detected_at, '') <> IFNULL(NEW.last_detected_at, '')
  THEN
    INSERT INTO
      indicator_audit_log (indicator_id, event_type, field, new_value, run_uuid, changed_by_source_id)
    VALUES
      (NEW.id, 'updated', 'last_detected_at', IFNULL(NEW.last_detected_at, ''), fn_uuid_to_binary(@CONNECTOR_RUN_UUID), @OWNER_SOURCE_ID)
    ON DUPLICATE KEY UPDATE
      event_type = VALUES(event_type),
      new_value = VALUES(new_value),
      changed_by_source_id = VALUES(changed_by_source_id);
  END IF;

  IF IFNULL(OLD.expires_at, '') <> IFNULL(NEW.expires_at, '')
  THEN
    INSERT INTO
      indicator_audit_log (indicator_id, event_type, field, new_value, run_uuid, changed_by_source_id)
    VALUES
      (NEW.id, 'updated', 'expires_at', IFNULL(NEW.expires_at, ''), fn_uuid_to_binary(@CONNECTOR_RUN_UUID), @OWNER_SOURCE_ID)
    ON DUPLICATE KEY UPDATE
      event_type = VALUES(event_type),
      new_value = VALUES(new_value),
      changed_by_source_id = VALUES(changed_by_source_id);
  END IF;

  IF IFNULL(OLD.expired_at, '') <> IFNULL(NEW.expired_at, '')
  THEN
    INSERT INTO
      indicator_audit_log (indicator_id, event_type, field, new_value, run_uuid, changed_by_source_id)
    VALUES
      (NEW.id, 'updated', 'expired_at', IFNULL(NEW.expired_at, ''), fn_uuid_to_binary(@CONNECTOR_RUN_UUID), @OWNER_SOURCE_ID)
    ON DUPLICATE KEY UPDATE
      event_type = VALUES(event_type),
      new_value = VALUES(new_value),
      changed_by_source_id = VALUES(changed_by_source_id);
  END IF;

  IF IFNULL(OLD.deleted_at, '') <> IFNULL(new.deleted_at, '')
  THEN
    INSERT INTO
      indicator_audit_log (indicator_id, event_type, field, new_value, run_uuid, changed_by_source_id)
    VALUES
      (NEW.id, IF(NEW.deleted_at IS NULL, 'undeleted', 'deleted'), 'deleted_at', IFNULL(NEW.deleted_at, ''),
        fn_uuid_to_binary(@CONNECTOR_RUN_UUID), @OWNER_SOURCE_ID)
    ON DUPLICATE KEY UPDATE
      event_type = VALUES(event_type),
      new_value = VALUES(new_value),
      changed_by_source_id = VALUES(changed_by_source_id);

    -- cascade deleted
    IF NEW.deleted_at IS NOT NULL
    THEN

      -- prevent recursion in update triggers
      SET @TOUCH_PARENT_INDICATOR = FALSE;

      UPDATE
        object_links
      SET
        src_deleted = 'Y',
        deleted_at  = IFNULL(deleted_at, NEW.deleted_at)
      WHERE
        src_type = 'indicator' AND
        src_object_id = NEW.id;

      UPDATE
        object_links
      SET
        dest_deleted = 'Y',
        deleted_at  = IFNULL(deleted_at, NEW.deleted_at)
      WHERE
        dest_type = 'indicator' AND
        dest_object_id = NEW.id;

      UPDATE
        indicator_attributes
      SET
        deleted_at = IFNULL(deleted_at, NEW.deleted_at)
      WHERE
        indicator_id = NEW.id;

      UPDATE
        indicator_comments
      SET
        deleted_at = IFNULL(deleted_at, NEW.deleted_at)
      WHERE
        indicator_id = NEW.id;

      UPDATE
        indicator_sources
      SET
        deleted_at = IFNULL(deleted_at, NEW.deleted_at)
      WHERE
        indicator_id = NEW.id;

      DELETE FROM
        investigation_nodes
      WHERE
        object_id = NEW.id AND
        object_type = 'indicator';

      DELETE FROM
        watchlist
      WHERE
        object_id = NEW.id AND
        object_type = 'indicator';

      -- prevent recursion in update triggers
      SET @TOUCH_PARENT_INDICATOR = TRUE;

    END IF;

  END IF;

  IF @CONNECTOR_RUN_UUID IS NOT NULL
  THEN
    SELECT
      run_uuid
    INTO
      connectorRunUuid
    FROM
      connector_run_objects
    WHERE
      run_uuid = fn_uuid_to_binary(@CONNECTOR_RUN_UUID) AND object_id = NEW.id AND object_type = 'indicators';

    IF ISNULL(connectorRunUuid)
    THEN
      INSERT INTO
        connector_run_objects (run_uuid, object_id, object_type)
      VALUES
        (fn_uuid_to_binary(@CONNECTOR_RUN_UUID), NEW.id, 'indicators');
    END IF;
  END IF;

END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-10-31 14:05:05
