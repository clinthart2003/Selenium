-- MySQL dump 10.16  Distrib 10.3.9-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: threatquotient2
-- ------------------------------------------------------
-- Server version	10.3.9-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `indicator_comments`
--

DROP TABLE IF EXISTS `indicator_comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `indicator_comments` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `indicator_id` int(10) unsigned NOT NULL,
  `value` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `creator_source_id` int(10) unsigned DEFAULT NULL,
  `created_at` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `updated_at` datetime(3) NOT NULL DEFAULT current_timestamp(3) ON UPDATE current_timestamp(3),
  `deleted_at` datetime(3) DEFAULT NULL,
  `sync_hash` char(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `indicator_comments_updated_at_index` (`updated_at`),
  KEY `indicator_comments_indicator_id_index` (`indicator_id`),
  KEY `sync_hash_index` (`sync_hash`)
) ENGINE=InnoDB AUTO_INCREMENT=15029 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `indicator_comments`
--
-- WHERE:  `indicator_id` in (SELECT id FROM `object_audit_id_lookup` WHERE key_column = 'indicator_id')

LOCK TABLES `indicator_comments` WRITE;
/*!40000 ALTER TABLE `indicator_comments` DISABLE KEYS */;
INSERT  IGNORE INTO `indicator_comments` VALUES (12423,13844370,'Comment',481,'2019-03-15 15:26:48.670','2019-03-15 15:26:48.670',NULL,'002cc7aba056b8a6e804d5699531c966'),(12425,13844370,'Comment',481,'2019-03-15 15:26:48.670','2019-03-15 15:26:48.670',NULL,'002cc7aba056b8a6e804d5699531c966'),(12359,13844309,'Comment',481,'2019-03-15 15:26:13.555','2019-03-15 15:26:13.555',NULL,'8926133b0307b9324449c60812df5b91'),(12360,13844309,'Comment',481,'2019-03-15 15:26:13.555','2019-03-15 15:26:13.555',NULL,'8926133b0307b9324449c60812df5b91'),(9161,13842319,'Comment',481,'2019-03-15 15:14:11.234','2019-03-15 15:14:11.234',NULL,'12abb6aa76372162864e8ff0a99e2d06'),(9183,13842319,'Comment',481,'2019-03-15 15:14:11.234','2019-03-15 15:14:11.234',NULL,'12abb6aa76372162864e8ff0a99e2d06'),(9156,13842316,'Comment',481,'2019-03-15 15:14:11.234','2019-03-15 15:14:11.234',NULL,'3a6c3112b68b2a9361ee241c5eeec1aa'),(9163,13842316,'Comment',481,'2019-03-15 15:14:11.234','2019-03-15 15:14:11.234',NULL,'3a6c3112b68b2a9361ee241c5eeec1aa'),(13106,13844736,'Comment',481,'2019-03-15 15:29:50.754','2019-03-15 15:29:50.754',NULL,'9418c0f213148655d8bf49a97d3ae3f6'),(13121,13844750,'Comment',481,'2019-03-15 15:29:50.754','2019-03-15 15:29:50.754',NULL,'43e9bb1d252e9edc61f1664a241e0465'),(13122,13844751,'Comment',481,'2019-03-15 15:29:50.754','2019-03-15 15:29:50.754',NULL,'377c65bd5d3e2530e0ddb529ce5cc858'),(13123,13844752,'Comment',481,'2019-03-15 15:29:50.754','2019-03-15 15:29:50.754',NULL,'763f82a7fe017cfc355967f65a1ca1a6'),(13145,13844774,'Comment',481,'2019-03-15 15:29:50.754','2019-03-15 15:29:50.754',NULL,'7fd6758389279d18eea9fff67e99dce3'),(13143,13844772,'Comment',481,'2019-03-15 15:29:50.754','2019-03-15 15:29:50.754',NULL,'bd1aa36ef29398f7b1db732e228220c8'),(13082,13844713,'Comment',481,'2019-03-15 15:29:50.754','2019-03-15 15:29:50.754',NULL,'5267931660adb677be2bdbd1923fc592'),(13144,13844773,'Comment',481,'2019-03-15 15:29:50.754','2019-03-15 15:29:50.754',NULL,'5701171b007da821fb20f3e6c3f71627'),(13083,13844714,'Comment',481,'2019-03-15 15:29:50.754','2019-03-15 15:29:50.754',NULL,'3c852aec181442832ad04fd4dc717ce3'),(13084,13844715,'Comment',481,'2019-03-15 15:29:50.754','2019-03-15 15:29:50.754',NULL,'a83130dd60303dc1e5cba3d7ffc9bccb');
/*!40000 ALTER TABLE `indicator_comments` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`threatquotient`@`localhost`*/ /*!50003 TRIGGER trig_indicator_comments_before_insert BEFORE INSERT ON indicator_comments
FOR EACH ROW BEGIN

  SET NEW.sync_hash = MD5(CONCAT(NEW.indicator_id, '-', NEW.value, '-', NEW.creator_source_id));

END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`threatquotient`@`localhost`*/ /*!50003 TRIGGER trig_indicator_comments_after_insert AFTER INSERT ON indicator_comments
FOR EACH ROW BEGIN

  INSERT INTO
    indicator_comment_audit_log (indicator_comment_id, event_type, field, new_value, run_uuid, changed_by_source_id)
  VALUES
    (NEW.id, 'added', 'value', NEW.value, fn_uuid_to_binary(@CONNECTOR_RUN_UUID), @OWNER_SOURCE_ID);

  IF @CONNECTOR_RUN_UUID IS NOT NULL
  THEN
    INSERT INTO
      connector_run_objects (run_uuid, object_id, object_type)
    VALUES
      (fn_uuid_to_binary(@CONNECTOR_RUN_UUID), NEW.id, 'indicator_comments');
  END IF;

  -- touch parent
  IF IFNULL(@TOUCH_PARENT_INDICATOR, TRUE)
  THEN
    UPDATE
      indicators
    SET
      updated_at = updated_at,
      touched_at = NOW(3)
    WHERE
      id = NEW.indicator_id;
  END IF;

END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`threatquotient`@`localhost`*/ /*!50003 TRIGGER trig_indicator_comments_before_update BEFORE UPDATE ON indicator_comments
FOR EACH ROW BEGIN

  IF
    OLD.indicator_id <> NEW.indicator_id OR
    OLD.value <> NEW.value OR
    OLD.creator_source_id <> NEW.creator_source_id
  THEN
    SET NEW.sync_hash = MD5(CONCAT(NEW.indicator_id, '-', NEW.value, '-', NEW.creator_source_id));
  END IF;

END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`threatquotient`@`localhost`*/ /*!50003 TRIGGER trig_indicator_comments_after_update AFTER UPDATE ON indicator_comments
FOR EACH ROW BEGIN

  DECLARE connectorRunUuid BINARY(16);

  -- Audit Logging
  IF IFNULL(OLD.deleted_at, '') <> IFNULL(NEW.deleted_at, '')
  THEN
    INSERT INTO
      indicator_comment_audit_log (indicator_comment_id, event_type, field, new_value, run_uuid, changed_by_source_id)
    VALUES
      (NEW.id, IF(NEW.deleted_at IS NULL, 'undeleted', 'deleted'), 'deleted_at', NEW.value, fn_uuid_to_binary(@CONNECTOR_RUN_UUID), @OWNER_SOURCE_ID)
    ON DUPLICATE KEY UPDATE
      event_type = VALUES(event_type),
      new_value = VALUES(new_value),
      changed_by_source_id = VALUES(changed_by_source_id);
  ELSE
    IF IFNULL(OLD.value, '') <> IFNULL(NEW.value, '')
    THEN
      INSERT INTO
        indicator_comment_audit_log (indicator_comment_id, event_type, field, new_value, run_uuid, changed_by_source_id)
      VALUES
        (NEW.id, 'updated', 'value', NEW.value, fn_uuid_to_binary(@CONNECTOR_RUN_UUID), @OWNER_SOURCE_ID)
      ON DUPLICATE KEY UPDATE
        event_type = VALUES(event_type),
        new_value = VALUES(new_value),
        changed_by_source_id = VALUES(changed_by_source_id);
    END IF;
  END IF;

  IF @CONNECTOR_RUN_UUID IS NOT NULL
  THEN
    SELECT
      run_uuid
    INTO
      connectorRunUuid
    FROM
      connector_run_objects
    WHERE
      run_uuid = fn_uuid_to_binary(@CONNECTOR_RUN_UUID) AND object_id = NEW.id AND object_type = 'indicator_comments';

    IF ISNULL(connectorRunUuid)
    THEN
      INSERT INTO
        connector_run_objects (run_uuid, object_id, object_type)
      VALUES
        (fn_uuid_to_binary(@CONNECTOR_RUN_UUID), NEW.id, 'indicator_comments');
    END IF;
  END IF;

  -- touch parent
  IF IFNULL(@TOUCH_PARENT_INDICATOR, TRUE)
  THEN
    UPDATE
      indicators
    SET
      updated_at = updated_at,
      touched_at = NOW(3)
    WHERE
      id = NEW.indicator_id;
  END IF;

END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-10-31 14:05:05
