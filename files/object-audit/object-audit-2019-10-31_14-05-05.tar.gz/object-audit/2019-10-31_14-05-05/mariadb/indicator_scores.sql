-- MySQL dump 10.16  Distrib 10.3.9-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: threatquotient2
-- ------------------------------------------------------
-- Server version	10.3.9-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `indicator_scores`
--

DROP TABLE IF EXISTS `indicator_scores`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `indicator_scores` (
  `indicator_id` int(10) unsigned NOT NULL,
  `generated_score` decimal(5,2) NOT NULL DEFAULT 0.00,
  `manual_score` int(10) unsigned DEFAULT NULL,
  `score_config_hash` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `updated_at` datetime(3) NOT NULL DEFAULT current_timestamp(3) ON UPDATE current_timestamp(3),
  PRIMARY KEY (`indicator_id`),
  KEY `indicator_scores_score_config_hash_index` (`score_config_hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `indicator_scores`
--
-- WHERE:  `indicator_id` in (SELECT id FROM `object_audit_id_lookup` WHERE key_column = 'indicator_id')

LOCK TABLES `indicator_scores` WRITE;
/*!40000 ALTER TABLE `indicator_scores` DISABLE KEYS */;
INSERT  IGNORE INTO `indicator_scores` VALUES (13844370,0.00,NULL,'480d227bc478e57c2df890447db199f2a6ce5fc7','2019-03-15 15:26:55.232','2019-07-23 17:32:05.462'),(13844372,0.00,NULL,'480d227bc478e57c2df890447db199f2a6ce5fc7','2019-04-08 09:09:09.368','2019-07-23 17:32:05.465'),(13844309,0.00,NULL,'480d227bc478e57c2df890447db199f2a6ce5fc7','2019-03-15 15:26:13.790','2019-07-23 17:32:05.364'),(13844310,0.00,NULL,'480d227bc478e57c2df890447db199f2a6ce5fc7','2019-04-08 09:09:09.364','2019-07-23 17:32:05.366'),(13842319,0.00,NULL,'480d227bc478e57c2df890447db199f2a6ce5fc7','2019-03-15 15:14:12.684','2019-07-23 17:32:00.372'),(13842334,0.00,NULL,'480d227bc478e57c2df890447db199f2a6ce5fc7','2019-04-08 09:09:09.361','2019-07-23 17:32:00.402'),(13842316,0.00,NULL,'480d227bc478e57c2df890447db199f2a6ce5fc7','2019-03-15 15:14:12.684','2019-07-23 17:32:00.366'),(13842321,0.00,NULL,'480d227bc478e57c2df890447db199f2a6ce5fc7','2019-04-08 09:09:09.357','2019-07-23 17:32:00.375'),(13749394,0.00,NULL,'480d227bc478e57c2df890447db199f2a6ce5fc7','2019-03-11 17:25:39.120','2019-07-23 17:26:19.141'),(13749395,0.00,NULL,'480d227bc478e57c2df890447db199f2a6ce5fc7','2019-04-08 09:08:13.071','2019-07-23 17:26:19.142'),(13749396,0.00,NULL,'480d227bc478e57c2df890447db199f2a6ce5fc7','2019-04-08 09:08:13.085','2019-07-23 17:26:19.144'),(13749397,0.00,NULL,'480d227bc478e57c2df890447db199f2a6ce5fc7','2019-04-08 09:08:13.088','2019-07-23 17:26:19.145'),(13749398,0.00,NULL,'480d227bc478e57c2df890447db199f2a6ce5fc7','2019-04-08 09:08:13.091','2019-07-23 17:26:19.147'),(12922652,5.00,NULL,'480d227bc478e57c2df890447db199f2a6ce5fc7','2019-04-08 07:00:10.913','2019-07-23 00:29:15.538'),(3361708,5.00,NULL,'480d227bc478e57c2df890447db199f2a6ce5fc7','2017-09-27 12:56:51.401','2019-07-18 21:10:27.366'),(12940095,5.00,NULL,'480d227bc478e57c2df890447db199f2a6ce5fc7','2019-04-08 07:19:30.001','2019-07-23 00:33:22.920'),(4063043,5.00,NULL,'480d227bc478e57c2df890447db199f2a6ce5fc7','2017-10-01 21:45:16.501','2019-07-18 23:20:51.994'),(13844736,0.00,NULL,'480d227bc478e57c2df890447db199f2a6ce5fc7','2019-03-15 15:29:54.422','2019-07-23 17:32:05.811'),(23,12.00,NULL,'480d227bc478e57c2df890447db199f2a6ce5fc7','2017-09-14 06:38:27.490','2019-07-18 15:42:05.389'),(602,5.00,NULL,'480d227bc478e57c2df890447db199f2a6ce5fc7','2017-09-14 06:49:38.981','2019-07-18 15:42:06.217'),(12735005,5.00,NULL,'480d227bc478e57c2df890447db199f2a6ce5fc7','2019-01-30 11:13:30.644','2019-07-22 22:57:30.095'),(12916295,5.00,NULL,'480d227bc478e57c2df890447db199f2a6ce5fc7','2019-04-08 06:57:51.428','2019-07-23 00:25:28.557'),(12735006,5.00,NULL,'480d227bc478e57c2df890447db199f2a6ce5fc7','2019-01-30 11:13:30.644','2019-07-22 22:57:30.096'),(12916294,5.00,NULL,'480d227bc478e57c2df890447db199f2a6ce5fc7','2019-04-08 06:57:51.425','2019-07-23 00:25:28.554'),(12735004,5.00,NULL,'480d227bc478e57c2df890447db199f2a6ce5fc7','2019-01-30 11:13:30.644','2019-07-22 22:57:30.093'),(12916293,5.00,NULL,'480d227bc478e57c2df890447db199f2a6ce5fc7','2019-04-08 06:57:51.422','2019-07-23 00:25:28.551'),(13844750,0.00,NULL,'480d227bc478e57c2df890447db199f2a6ce5fc7','2019-03-15 15:29:54.422','2019-07-23 17:32:05.831'),(12202156,5.00,NULL,'480d227bc478e57c2df890447db199f2a6ce5fc7','2019-01-25 07:06:10.017','2019-07-22 18:47:14.958'),(13844751,0.00,NULL,'480d227bc478e57c2df890447db199f2a6ce5fc7','2019-03-15 15:29:54.422','2019-07-23 17:32:05.833'),(12202091,5.00,NULL,'480d227bc478e57c2df890447db199f2a6ce5fc7','2019-01-25 07:06:10.017','2019-07-22 18:47:14.824'),(13844752,0.00,NULL,'480d227bc478e57c2df890447db199f2a6ce5fc7','2019-03-15 15:29:54.422','2019-07-23 17:32:05.834'),(12202182,5.00,NULL,'480d227bc478e57c2df890447db199f2a6ce5fc7','2019-01-25 07:06:10.017','2019-07-22 18:47:15.006'),(13844774,0.00,NULL,'480d227bc478e57c2df890447db199f2a6ce5fc7','2019-03-15 15:29:54.422','2019-07-23 17:32:05.866'),(2713586,14.00,NULL,'480d227bc478e57c2df890447db199f2a6ce5fc7','2017-09-18 12:32:09.602','2019-07-18 19:28:02.511'),(13844772,0.00,NULL,'480d227bc478e57c2df890447db199f2a6ce5fc7','2019-03-15 15:29:54.422','2019-07-23 17:32:05.864'),(2713587,14.00,NULL,'480d227bc478e57c2df890447db199f2a6ce5fc7','2017-09-18 12:32:09.602','2019-07-18 19:28:02.514'),(13844713,0.00,NULL,'480d227bc478e57c2df890447db199f2a6ce5fc7','2019-03-15 15:29:54.422','2019-07-23 17:32:05.777'),(2713593,14.00,NULL,'480d227bc478e57c2df890447db199f2a6ce5fc7','2017-09-18 12:32:09.602','2019-07-18 19:28:02.523'),(13844773,0.00,NULL,'480d227bc478e57c2df890447db199f2a6ce5fc7','2019-03-15 15:29:54.422','2019-07-23 17:32:05.865'),(2713585,14.00,NULL,'480d227bc478e57c2df890447db199f2a6ce5fc7','2017-09-18 12:32:09.602','2019-07-18 19:28:02.510'),(13844714,0.00,NULL,'480d227bc478e57c2df890447db199f2a6ce5fc7','2019-03-15 15:29:54.422','2019-07-23 17:32:05.778'),(2713591,14.00,NULL,'480d227bc478e57c2df890447db199f2a6ce5fc7','2017-09-18 12:32:09.602','2019-07-18 19:28:02.520'),(13844715,0.00,NULL,'480d227bc478e57c2df890447db199f2a6ce5fc7','2019-03-15 15:29:54.422','2019-07-23 17:32:05.780'),(2713592,14.00,NULL,'480d227bc478e57c2df890447db199f2a6ce5fc7','2017-09-18 12:32:09.602','2019-07-18 19:28:02.521');
/*!40000 ALTER TABLE `indicator_scores` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`threatquotient`@`localhost`*/ /*!50003 TRIGGER trig_indicator_scores_after_insert AFTER INSERT ON indicator_scores
FOR EACH ROW BEGIN

  -- Audit Logging
  INSERT INTO indicator_score_audit_log (indicator_score_id, event_type, field, new_value, changed_by_source_id)
  VALUES (NEW.indicator_id, 'added', 'generated_score', NEW.generated_score, @owner_source_id);

  INSERT INTO indicator_score_audit_log (indicator_score_id, event_type, field, new_value, changed_by_source_id)
  VALUES (NEW.indicator_id, 'added', 'manual_score', NEW.manual_score, @owner_source_id);

  -- touch parent
  IF IFNULL(@TOUCH_PARENT_INDICATOR, TRUE)
  THEN
    SET @SCORE_INDICATOR_OLD = @SCORE_INDICATOR;
    SET @SCORE_INDICATOR = FALSE;

    UPDATE
      indicators
    SET
      updated_at = updated_at,
      touched_at = NOW(3)
    WHERE
      id = NEW.indicator_id;

    SET @SCORE_INDICATOR = @SCORE_INDICATOR_OLD;
  END IF;

END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`threatquotient`@`localhost`*/ /*!50003 TRIGGER trig_indicator_scores_after_update AFTER UPDATE ON indicator_scores
FOR EACH ROW BEGIN

  -- Audit Logging
  IF IFNULL(OLD.generated_score, '') <> IFNULL(NEW.generated_score, '')
  THEN
    INSERT INTO
      indicator_score_audit_log (indicator_score_id, event_type, field, new_value, changed_by_source_id)
    VALUES
      (NEW.indicator_id, 'updated', 'generated_score', NEW.generated_score, @owner_source_id);

    SET @SCORE_INDICATOR_OLD = @SCORE_INDICATOR;
    SET @SCORE_INDICATOR = FALSE;

    UPDATE
      indicators
    SET
      updated_at = NOW(3)
    WHERE
      id = NEW.indicator_id;

    SET @SCORE_INDICATOR = @SCORE_INDICATOR_OLD;
  END IF;

  IF IFNULL(OLD.manual_score, '') <> IFNULL(NEW.manual_score, '')
  THEN
    INSERT INTO
      indicator_score_audit_log (indicator_score_id, event_type, field, new_value, changed_by_source_id)
    VALUES
      (NEW.indicator_id, 'updated', 'manual_score', NEW.manual_score, @owner_source_id);

    SET @SCORE_INDICATOR_OLD = @SCORE_INDICATOR;
    SET @SCORE_INDICATOR = FALSE;

    UPDATE
      indicators
    SET
      updated_at = NOW(3)
    WHERE
      id = NEW.indicator_id;

    SET @SCORE_INDICATOR = @SCORE_INDICATOR_OLD;
  END IF;

  -- touch parent
  IF IFNULL(@TOUCH_PARENT_INDICATOR, TRUE)
  THEN
    SET @SCORE_INDICATOR_OLD = @SCORE_INDICATOR;
    SET @SCORE_INDICATOR = FALSE;

    UPDATE indicators
    SET
      updated_at = updated_at,
      touched_at = NOW(3)
    WHERE
      id = NEW.indicator_id;

    SET @SCORE_INDICATOR = @SCORE_INDICATOR_OLD;
  END IF;

END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-10-31 14:05:05
