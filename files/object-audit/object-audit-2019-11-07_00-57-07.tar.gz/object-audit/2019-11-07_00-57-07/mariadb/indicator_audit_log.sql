-- MySQL dump 10.16  Distrib 10.3.9-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: threatquotient2
-- ------------------------------------------------------
-- Server version	10.3.9-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `indicator_audit_log`
--

DROP TABLE IF EXISTS `indicator_audit_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `indicator_audit_log` (
  `indicator_id` int(10) unsigned NOT NULL,
  `event_type` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `field` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `new_value` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `run_uuid` binary(16) DEFAULT NULL,
  `changed_by_source_id` int(10) unsigned DEFAULT NULL,
  `changed_at` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  PRIMARY KEY (`indicator_id`,`changed_at`,`field`),
  KEY `indicator_audit_log_indicator_id_index` (`indicator_id`),
  KEY `indicator_audit_log_event_type_index` (`event_type`),
  KEY `indicator_audit_log_field_index` (`field`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `indicator_audit_log`
--
-- WHERE:  `indicator_id` in (SELECT id FROM `object_audit_id_lookup` WHERE key_column = 'indicator_id')

LOCK TABLES `indicator_audit_log` WRITE;
/*!40000 ALTER TABLE `indicator_audit_log` DISABLE KEYS */;
INSERT  IGNORE INTO `indicator_audit_log` VALUES (99958,'added','class','network',NULL,8,'2019-11-07 00:22:32.241'),(99958,'added','description',NULL,NULL,8,'2019-11-07 00:22:32.241'),(99958,'added','status_id','4',NULL,8,'2019-11-07 00:22:32.241'),(99958,'added','type_id','10',NULL,8,'2019-11-07 00:22:32.241'),(99958,'added','value','jamaican-vents.autos',NULL,8,'2019-11-07 00:22:32.241'),(99961,'added','class','network',NULL,8,'2019-11-07 00:22:32.241'),(99961,'added','description',NULL,NULL,8,'2019-11-07 00:22:32.241'),(99961,'added','status_id','4',NULL,8,'2019-11-07 00:22:32.241'),(99961,'added','type_id','10',NULL,8,'2019-11-07 00:22:32.241'),(99961,'added','value','jamaican-vents.autos',NULL,8,'2019-11-07 00:22:32.241'),(97061,'added','class','network',NULL,8,'2019-11-07 00:22:03.478'),(97061,'added','description',NULL,NULL,8,'2019-11-07 00:22:03.478'),(97061,'added','status_id','4',NULL,8,'2019-11-07 00:22:03.478'),(97061,'added','type_id','10',NULL,8,'2019-11-07 00:22:03.478'),(97061,'added','value','[redacted].wufoo.com',NULL,8,'2019-11-07 00:22:03.478'),(97063,'added','class','network',NULL,8,'2019-11-07 00:22:03.478'),(97063,'added','description',NULL,NULL,8,'2019-11-07 00:22:03.478'),(97063,'added','status_id','4',NULL,8,'2019-11-07 00:22:03.478'),(97063,'added','type_id','10',NULL,8,'2019-11-07 00:22:03.478'),(97063,'added','value','[redacted].wufoo.com',NULL,8,'2019-11-07 00:22:03.478'),(94239,'added','class','network',NULL,8,'2019-11-07 00:21:39.886'),(94239,'added','description',NULL,NULL,8,'2019-11-07 00:21:39.886'),(94239,'added','status_id','4',NULL,8,'2019-11-07 00:21:39.886'),(94239,'added','type_id','10',NULL,8,'2019-11-07 00:21:39.886'),(94239,'added','value','tinyurl.com',NULL,8,'2019-11-07 00:21:39.886'),(94240,'added','class','network',NULL,8,'2019-11-07 00:21:39.886'),(94240,'added','description',NULL,NULL,8,'2019-11-07 00:21:39.886'),(94240,'added','status_id','4',NULL,8,'2019-11-07 00:21:39.886'),(94240,'added','type_id','10',NULL,8,'2019-11-07 00:21:39.886'),(94240,'added','value','tinyurl.com',NULL,8,'2019-11-07 00:21:39.886'),(7249,'added','class','network',NULL,8,'2019-11-07 00:08:54.810'),(7249,'added','description',NULL,NULL,8,'2019-11-07 00:08:54.810'),(7249,'added','status_id','4',NULL,8,'2019-11-07 00:08:54.810'),(7249,'added','type_id','28',NULL,8,'2019-11-07 00:08:54.810'),(7249,'added','value','docs.google.com/uc',NULL,8,'2019-11-07 00:08:54.810'),(7249,'updated','status_id','1','�\0����\r�>b�',20,'2019-11-07 00:30:21.702'),(7255,'added','class','network',NULL,8,'2019-11-07 00:08:54.810'),(7255,'added','description',NULL,NULL,8,'2019-11-07 00:08:54.810'),(7255,'added','status_id','4',NULL,8,'2019-11-07 00:08:54.810'),(7255,'added','type_id','28',NULL,8,'2019-11-07 00:08:54.810'),(7255,'added','value','docs.google.com/uc',NULL,8,'2019-11-07 00:08:54.810'),(7257,'added','class','network',NULL,8,'2019-11-07 00:08:54.810'),(7257,'added','description',NULL,NULL,8,'2019-11-07 00:08:54.810'),(7257,'added','status_id','4',NULL,8,'2019-11-07 00:08:54.810'),(7257,'added','type_id','28',NULL,8,'2019-11-07 00:08:54.810'),(7257,'added','value','docs.google.com/uc',NULL,8,'2019-11-07 00:08:54.810'),(7258,'added','class','network',NULL,8,'2019-11-07 00:08:54.810'),(7258,'added','description',NULL,NULL,8,'2019-11-07 00:08:54.810'),(7258,'added','status_id','4',NULL,8,'2019-11-07 00:08:54.810'),(7258,'added','type_id','28',NULL,8,'2019-11-07 00:08:54.810'),(7258,'added','value','docs.google.com/uc',NULL,8,'2019-11-07 00:08:54.810'),(7262,'added','class','network',NULL,8,'2019-11-07 00:08:54.810'),(7262,'added','description',NULL,NULL,8,'2019-11-07 00:08:54.810'),(7262,'added','status_id','4',NULL,8,'2019-11-07 00:08:54.810'),(7262,'added','type_id','28',NULL,8,'2019-11-07 00:08:54.810'),(7262,'added','value','docs.google.com/uc',NULL,8,'2019-11-07 00:08:54.810'),(7270,'added','class','network',NULL,8,'2019-11-07 00:08:54.810'),(7270,'added','description',NULL,NULL,8,'2019-11-07 00:08:54.810'),(7270,'added','status_id','4',NULL,8,'2019-11-07 00:08:54.810'),(7270,'added','type_id','28',NULL,8,'2019-11-07 00:08:54.810'),(7270,'added','value','docs.google.com/uc',NULL,8,'2019-11-07 00:08:54.810'),(7273,'added','class','network',NULL,8,'2019-11-07 00:08:54.810'),(7273,'added','description',NULL,NULL,8,'2019-11-07 00:08:54.810'),(7273,'added','status_id','4',NULL,8,'2019-11-07 00:08:54.810'),(7273,'added','type_id','28',NULL,8,'2019-11-07 00:08:54.810'),(7273,'added','value','docs.google.com/uc',NULL,8,'2019-11-07 00:08:54.810'),(7274,'added','class','network',NULL,8,'2019-11-07 00:08:54.810'),(7274,'added','description',NULL,NULL,8,'2019-11-07 00:08:54.810'),(7274,'added','status_id','4',NULL,8,'2019-11-07 00:08:54.810'),(7274,'added','type_id','28',NULL,8,'2019-11-07 00:08:54.810'),(7274,'added','value','docs.google.com/uc',NULL,8,'2019-11-07 00:08:54.810'),(7275,'added','class','network',NULL,8,'2019-11-07 00:08:54.810'),(7275,'added','description',NULL,NULL,8,'2019-11-07 00:08:54.810'),(7275,'added','status_id','4',NULL,8,'2019-11-07 00:08:54.810'),(7275,'added','type_id','28',NULL,8,'2019-11-07 00:08:54.810'),(7275,'added','value','docs.google.com/uc',NULL,8,'2019-11-07 00:08:54.810'),(7277,'added','class','network',NULL,8,'2019-11-07 00:08:54.810'),(7277,'added','description',NULL,NULL,8,'2019-11-07 00:08:54.810'),(7277,'added','status_id','4',NULL,8,'2019-11-07 00:08:54.810'),(7277,'added','type_id','28',NULL,8,'2019-11-07 00:08:54.810'),(7277,'added','value','docs.google.com/uc',NULL,8,'2019-11-07 00:08:54.810'),(7293,'added','class','network',NULL,8,'2019-11-07 00:08:54.810'),(7293,'added','description',NULL,NULL,8,'2019-11-07 00:08:54.810'),(7293,'added','status_id','4',NULL,8,'2019-11-07 00:08:54.810'),(7293,'added','type_id','10',NULL,8,'2019-11-07 00:08:54.810'),(7293,'added','value','dooblo.net',NULL,8,'2019-11-07 00:08:54.810'),(7294,'added','class','network',NULL,8,'2019-11-07 00:08:54.810'),(7294,'added','description',NULL,NULL,8,'2019-11-07 00:08:54.810'),(7294,'added','status_id','4',NULL,8,'2019-11-07 00:08:54.810'),(7294,'added','type_id','10',NULL,8,'2019-11-07 00:08:54.810'),(7294,'added','value','dooblo.net',NULL,8,'2019-11-07 00:08:54.810'),(7280,'added','class','network',NULL,8,'2019-11-07 00:08:54.810'),(7280,'added','description',NULL,NULL,8,'2019-11-07 00:08:54.810'),(7280,'added','status_id','4',NULL,8,'2019-11-07 00:08:54.810'),(7280,'added','type_id','10',NULL,8,'2019-11-07 00:08:54.810'),(7280,'added','value','haberkat.com',NULL,8,'2019-11-07 00:08:54.810'),(7286,'added','class','network',NULL,8,'2019-11-07 00:08:54.810'),(7286,'added','description',NULL,NULL,8,'2019-11-07 00:08:54.810'),(7286,'added','status_id','4',NULL,8,'2019-11-07 00:08:54.810'),(7286,'added','type_id','10',NULL,8,'2019-11-07 00:08:54.810'),(7286,'added','value','haberkat.com',NULL,8,'2019-11-07 00:08:54.810');
/*!40000 ALTER TABLE `indicator_audit_log` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-11-07  0:57:08
