-- MySQL dump 10.16  Distrib 10.3.9-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: threatquotient2
-- ------------------------------------------------------
-- Server version	10.3.9-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `indicator_attribute_sources`
--

DROP TABLE IF EXISTS `indicator_attribute_sources`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `indicator_attribute_sources` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `indicator_attribute_id` int(10) unsigned NOT NULL,
  `source_id` int(10) unsigned NOT NULL,
  `tlp_id` int(10) unsigned DEFAULT NULL,
  `created_at` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `updated_at` datetime(3) NOT NULL DEFAULT current_timestamp(3) ON UPDATE current_timestamp(3),
  `published_at` datetime(3) DEFAULT NULL,
  `creator_source_id` int(10) unsigned NOT NULL,
  `deleted_at` datetime(3) DEFAULT NULL,
  `sync_hash` char(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `indicator_attribute_source_unique` (`indicator_attribute_id`,`source_id`),
  KEY `indicator_attribute_sources_source_id_index` (`source_id`),
  KEY `indicator_attribute_sources_tlp_id_index` (`tlp_id`),
  KEY `indicator_attribute_sources_published_at_index` (`published_at`),
  KEY `indicator_attribute_sources_updated_at_index` (`updated_at`),
  KEY `indicator_attribute_tlp_index` (`indicator_attribute_id`,`tlp_id`),
  KEY `ind_att_sou_indattid_souid_cresouid_index` (`indicator_attribute_id`,`source_id`,`creator_source_id`),
  KEY `sync_hash_index` (`sync_hash`)
) ENGINE=InnoDB AUTO_INCREMENT=165685 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `indicator_attribute_sources`
--
-- WHERE:  `indicator_attribute_id` in (SELECT id FROM `object_audit_id_lookup` WHERE key_column = 'indicator_attribute_id')

LOCK TABLES `indicator_attribute_sources` WRITE;
/*!40000 ALTER TABLE `indicator_attribute_sources` DISABLE KEYS */;
INSERT  IGNORE INTO `indicator_attribute_sources` VALUES (41304,41304,9,3,'2019-11-07 00:22:03.765','2019-11-07 00:22:03.765',NULL,8,NULL,'c2009fd9bf34f31fe2064e663f42b9f4'),(41305,41305,9,3,'2019-11-07 00:22:03.777','2019-11-07 00:22:03.777',NULL,8,NULL,'d71b3bbd758eb19f63fa13b7dd171c9d'),(41307,41307,9,3,'2019-11-07 00:22:03.789','2019-11-07 00:22:03.789',NULL,8,NULL,'16501a6082eaa8cc992f3915f866b679'),(41309,41309,9,3,'2019-11-07 00:22:03.802','2019-11-07 00:22:03.802',NULL,8,NULL,'c1fcceccfd1500c176974e692f969e20'),(40636,40636,9,4,'2019-11-07 00:21:40.307','2019-11-07 00:21:40.307',NULL,8,NULL,'18b707c29ddc028affcbf50a5b92a39a'),(40638,40638,9,4,'2019-11-07 00:21:40.317','2019-11-07 00:21:40.317',NULL,8,NULL,'8bf806b489e1bc04220a72cc67e77867'),(40640,40640,9,4,'2019-11-07 00:21:40.328','2019-11-07 00:21:40.328',NULL,8,NULL,'d3bd11c7e6d730584b108bd3b2ef0cfb'),(40642,40642,9,4,'2019-11-07 00:21:40.340','2019-11-07 00:21:40.340',NULL,8,NULL,'1459ec914312b927e2a9c3218a3782c5'),(9555,9555,9,3,'2019-11-07 00:08:55.234','2019-11-07 00:08:56.301','2018-01-02 14:36:19.000',8,NULL,'ca2fd9b4bb8888a8d6c1050ebaee2c55'),(9556,9556,9,3,'2019-11-07 00:08:55.239','2019-11-07 00:08:56.311','2018-01-02 14:36:19.000',8,NULL,'9adafd022703f0504266b19eda5e1c9d'),(9557,9557,9,3,'2019-11-07 00:08:55.243','2019-11-07 00:08:55.243','2018-01-02 14:36:19.000',8,NULL,'f5a73fa3c3820dc1ee60e9bb2f4012e3'),(9558,9558,9,3,'2019-11-07 00:08:55.247','2019-11-07 00:08:55.247','2018-01-02 14:36:19.000',8,NULL,'010afa70ff092175864449126d948828'),(9559,9559,9,3,'2019-11-07 00:08:55.251','2019-11-07 00:08:56.315','2018-01-02 14:36:19.000',8,NULL,'c6dd44b5997ec8f0891581f41c143621'),(9560,9560,9,3,'2019-11-07 00:08:55.255','2019-11-07 00:08:55.255','2018-01-02 14:36:19.000',8,NULL,'04092ea446fe138e55c6d639f2a6cda0'),(9561,9561,9,3,'2019-11-07 00:08:55.259','2019-11-07 00:08:56.327','2018-01-02 14:36:19.000',8,NULL,'a75857015a6f353ce4c88057796c7b36'),(9562,9562,9,3,'2019-11-07 00:08:55.263','2019-11-07 00:08:56.334','2018-01-02 14:36:19.000',8,NULL,'513e5ad9296e42f945c717bc80108f2b'),(9563,9563,9,3,'2019-11-07 00:08:55.267','2019-11-07 00:08:56.338',NULL,8,NULL,'6945d75350c321c956eae7805d6d7922'),(61582,9563,20,NULL,'2019-11-07 00:30:25.711','2019-11-07 00:30:25.786',NULL,20,NULL,'c837bfb584c73ea96624cb2e1306b374'),(9564,9564,9,3,'2019-11-07 00:08:55.271','2019-11-07 00:08:55.271',NULL,8,NULL,'04fe957fb53c3b6e70a4b4438dbf2a7f'),(9610,9610,9,3,'2019-11-07 00:08:55.473','2019-11-07 00:08:55.473','2018-01-02 14:36:19.000',8,NULL,'22476a121e4ff87f4e37ab4c2fee0295'),(9611,9611,9,3,'2019-11-07 00:08:55.477','2019-11-07 00:08:55.477','2018-01-02 14:36:19.000',8,NULL,'15b41b712d4e551ad486d4654a255ac3'),(9612,9612,9,3,'2019-11-07 00:08:55.481','2019-11-07 00:08:55.481','2018-01-02 14:36:19.000',8,NULL,'3e312fc7c987cbbc365790772ac4e9b7'),(9613,9613,9,3,'2019-11-07 00:08:55.500','2019-11-07 00:08:55.500',NULL,8,NULL,'4d91d592dfb1b868d1da93c1ce5a8235'),(9623,9623,9,3,'2019-11-07 00:08:55.548','2019-11-07 00:08:55.548','2018-01-02 14:36:19.000',8,NULL,'3f22f0168031dc3d7f1c960a4045fdeb'),(9624,9624,9,3,'2019-11-07 00:08:55.556','2019-11-07 00:08:55.556','2018-01-02 14:36:19.000',8,NULL,'63305d393589ebfa8767160c3fe24e69'),(9625,9625,9,3,'2019-11-07 00:08:55.560','2019-11-07 00:08:55.560','2018-01-02 14:36:19.000',8,NULL,'da66077ae31dae97242da89691c71097'),(9626,9626,9,3,'2019-11-07 00:08:55.579','2019-11-07 00:08:55.579',NULL,8,NULL,'03160dfcf4f11d80f3eea68f481ad091'),(9627,9627,9,3,'2019-11-07 00:08:55.587','2019-11-07 00:08:55.587','2018-01-02 14:36:19.000',8,NULL,'510fb2c596474ef278698d47b4a1d276'),(9628,9628,9,3,'2019-11-07 00:08:55.595','2019-11-07 00:08:55.595','2018-01-02 14:36:19.000',8,NULL,'d22670dec1b8c7ce9d9348c8e78ced7e'),(9629,9629,9,3,'2019-11-07 00:08:55.610','2019-11-07 00:08:55.610','2018-01-02 14:36:19.000',8,NULL,'ee0c03a8b4075bc14309e6882c173f89'),(9630,9630,9,3,'2019-11-07 00:08:55.618','2019-11-07 00:08:55.618',NULL,8,NULL,'aaf0de32e90d55ac79842261f4f962c6'),(9658,9658,9,3,'2019-11-07 00:08:55.751','2019-11-07 00:08:55.751','2018-01-02 14:36:19.000',8,NULL,'ad024645199e0328a5624dc882ff7d32'),(9659,9659,9,3,'2019-11-07 00:08:55.759','2019-11-07 00:08:55.759','2018-01-02 14:36:19.000',8,NULL,'0907e57992c230f882f223b37e765d4e'),(9660,9660,9,3,'2019-11-07 00:08:55.763','2019-11-07 00:08:55.763','2018-01-02 14:36:19.000',8,NULL,'94a7ef815af6fbe0440fd575068ab259'),(9661,9661,9,3,'2019-11-07 00:08:55.778','2019-11-07 00:08:55.778',NULL,8,NULL,'6d5e1806135e0a2275f3bcb8a7f40919'),(9721,9721,9,3,'2019-11-07 00:08:56.031','2019-11-07 00:08:56.031','2018-01-02 14:36:19.000',8,NULL,'3230bfadd20349f6d8dfdbf717d4e99a'),(9722,9722,9,3,'2019-11-07 00:08:56.043','2019-11-07 00:08:56.043','2018-01-02 14:36:19.000',8,NULL,'2bf0cbca06c8e8a89918c642b42dbb8d'),(9723,9723,9,3,'2019-11-07 00:08:56.047','2019-11-07 00:08:56.047','2018-01-02 14:36:19.000',8,NULL,'7ff342afef6d0b652b7dac7dc723f4ca'),(9724,9724,9,3,'2019-11-07 00:08:56.062','2019-11-07 00:08:56.062',NULL,8,NULL,'5a7edf4891f490909fbf8213045029a6'),(9743,9743,9,3,'2019-11-07 00:08:56.150','2019-11-07 00:08:56.150','2018-01-02 14:36:19.000',8,NULL,'212a94e6310361a37ae426b77a843a5f'),(9744,9744,9,3,'2019-11-07 00:08:56.158','2019-11-07 00:08:56.158','2018-01-02 14:36:19.000',8,NULL,'50d83838d05c88e45abc14c04a0ab889'),(9745,9745,9,3,'2019-11-07 00:08:56.163','2019-11-07 00:08:56.163','2018-01-02 14:36:19.000',8,NULL,'dab85efe678f30d8967c58a5ddc8df06'),(9746,9746,9,3,'2019-11-07 00:08:56.175','2019-11-07 00:08:56.175',NULL,8,NULL,'8cbdde4b54d008e7ba7bae481defb0ac'),(9747,9747,9,3,'2019-11-07 00:08:56.182','2019-11-07 00:08:56.182','2018-01-02 14:36:19.000',8,NULL,'9c7b2a458033de6e3e60fa10b2a6b70a'),(9748,9748,9,3,'2019-11-07 00:08:56.191','2019-11-07 00:08:56.191','2018-01-02 14:36:19.000',8,NULL,'fb2b10075e830c688bd01edc08092685'),(9749,9749,9,3,'2019-11-07 00:08:56.200','2019-11-07 00:08:56.200','2018-01-02 14:36:19.000',8,NULL,'098d26b7fa5b98d715a1cb397dcd6c7d'),(9750,9750,9,3,'2019-11-07 00:08:56.216','2019-11-07 00:08:56.216',NULL,8,NULL,'64a583afa9986f90596a9d5b01f14ccb'),(9751,9751,9,3,'2019-11-07 00:08:56.224','2019-11-07 00:08:56.224','2018-01-02 14:36:19.000',8,NULL,'b8f85202fc7246452fc5e626a3c12932'),(9752,9752,9,3,'2019-11-07 00:08:56.228','2019-11-07 00:08:56.228','2018-01-02 14:36:19.000',8,NULL,'1b6f7b836cca1a981123f4363676c095'),(9753,9753,9,3,'2019-11-07 00:08:56.236','2019-11-07 00:08:56.236','2018-01-02 14:36:19.000',8,NULL,'32b945888b9d07fa44b459f3ff15b694'),(9754,9754,9,3,'2019-11-07 00:08:56.256','2019-11-07 00:08:56.256',NULL,8,NULL,'b1f7ca8e3322deb0ce715275d8f4374b'),(9764,9764,9,3,'2019-11-07 00:08:56.306','2019-11-07 00:08:56.306','2018-01-02 14:36:19.000',8,NULL,'462554bfce93bf94487c5d9198f11f7f'),(9765,9765,9,3,'2019-11-07 00:08:56.319','2019-11-07 00:08:56.319','2018-01-02 14:36:19.000',8,NULL,'3ce76f7d9f6b969d457f41d5645199aa'),(9766,9766,9,3,'2019-11-07 00:08:56.323','2019-11-07 00:08:56.323','2018-01-02 14:36:19.000',8,NULL,'dc1f0364edff16e659b10c1c35cd00e4'),(9767,9767,9,3,'2019-11-07 00:08:56.342','2019-11-07 00:08:56.342',NULL,8,NULL,'3b84da9e5e9f75be09971bc4988c4deb'),(61581,61581,20,NULL,'2019-11-07 00:30:25.705','2019-11-07 00:30:25.772','2019-10-18 09:44:04.000',20,NULL,'c44f97e9041916e8bc54d39a2023c330'),(61583,61582,20,NULL,'2019-11-07 00:30:25.764','2019-11-07 00:30:25.764',NULL,20,NULL,'d4c16afe51ee9c6b78656dc1eeb47bf7'),(61584,61583,20,NULL,'2019-11-07 00:30:25.797','2019-11-07 00:30:25.797',NULL,20,NULL,'5f0a329619aa12e093bbef4b384875c1');
/*!40000 ALTER TABLE `indicator_attribute_sources` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`threatquotient`@`localhost`*/ /*!50003 TRIGGER trig_indicator_attribute_sources_before_insert BEFORE INSERT ON indicator_attribute_sources
FOR EACH ROW BEGIN

  DECLARE defaultTlpId INTEGER UNSIGNED;

  SELECT fn_get_default_tlp_id_for_source(NEW.source_id) INTO defaultTlpId;

  IF (defaultTlpId IS NOT NULL) AND (NEW.tlp_id IS NULL)
  THEN
    SET NEW.tlp_id = defaultTlpId;
  END IF;

  SET NEW.sync_hash = MD5(CONCAT(NEW.indicator_attribute_id, NEW.source_id, NEW.creator_source_id));

END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`threatquotient`@`localhost`*/ /*!50003 TRIGGER trig_indicator_attribute_sources_after_insert AFTER INSERT ON indicator_attribute_sources
FOR EACH ROW BEGIN

  -- touch parent
  IF IFNULL(@TOUCH_PARENT_INDICATOR_ATTRIBUTE, TRUE)
  THEN
    UPDATE indicator_attributes
    SET
      updated_at = updated_at,
      touched_at = NOW(3)
    WHERE
      id = new.indicator_attribute_id;
  END IF;

END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`threatquotient`@`localhost`*/ /*!50003 TRIGGER trig_indicator_attribute_sources_before_update BEFORE UPDATE ON indicator_attribute_sources
FOR EACH ROW BEGIN

  IF
    OLD.indicator_attribute_id <> NEW.indicator_attribute_id OR
    OLD.source_id <> NEW.source_id OR
    OLD.creator_source_id <> NEW.creator_source_id
  THEN
    SET NEW.sync_hash = MD5(CONCAT(NEW.indicator_attribute_id, NEW.source_id, NEW.creator_source_id));
  END IF;

END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`threatquotient`@`localhost`*/ /*!50003 TRIGGER trig_indicator_attribute_sources_after_update AFTER UPDATE ON indicator_attribute_sources
FOR EACH ROW BEGIN

  -- touch parent
  IF IFNULL(@TOUCH_PARENT_INDICATOR_ATTRIBUTE, TRUE)
  THEN
    UPDATE indicator_attributes
    SET
      updated_at = updated_at,
      touched_at = NOW(3)
    WHERE
      id = new.indicator_attribute_id;
  END IF;

END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-11-07  0:57:10
