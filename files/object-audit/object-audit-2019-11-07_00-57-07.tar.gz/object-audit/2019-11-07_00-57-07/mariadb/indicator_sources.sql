-- MySQL dump 10.16  Distrib 10.3.9-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: threatquotient2
-- ------------------------------------------------------
-- Server version	10.3.9-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `indicator_sources`
--

DROP TABLE IF EXISTS `indicator_sources`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `indicator_sources` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `indicator_id` int(10) unsigned NOT NULL,
  `source_id` int(10) unsigned NOT NULL,
  `creator_source_id` int(10) unsigned NOT NULL,
  `tlp_id` int(10) unsigned DEFAULT NULL,
  `created_at` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `updated_at` datetime(3) NOT NULL DEFAULT current_timestamp(3) ON UPDATE current_timestamp(3),
  `published_at` datetime(3) DEFAULT NULL,
  `deleted_at` datetime(3) DEFAULT NULL,
  `sync_hash` char(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_key` (`indicator_id`,`source_id`,`creator_source_id`),
  KEY `indicator_sources_tlp_id_index` (`tlp_id`),
  KEY `indicator_sources_published_at_index` (`published_at`),
  KEY `indicator_sources_updated_at_index` (`updated_at`),
  KEY `indicator_tlp_index` (`indicator_id`,`tlp_id`),
  KEY `ind_sou_indid_souid_cresouid_index` (`indicator_id`,`source_id`,`creator_source_id`),
  KEY `sync_hash_index` (`sync_hash`)
) ENGINE=InnoDB AUTO_INCREMENT=323516 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `indicator_sources`
--
-- WHERE:  `indicator_id` in (SELECT id FROM `object_audit_id_lookup` WHERE key_column = 'indicator_id')

LOCK TABLES `indicator_sources` WRITE;
/*!40000 ALTER TABLE `indicator_sources` DISABLE KEYS */;
INSERT  IGNORE INTO `indicator_sources` VALUES (109065,99958,9,8,NULL,'2019-11-07 00:22:32.358','2019-11-07 00:22:32.358',NULL,NULL,'41bce2920f41be3fb00d315191883b11'),(105693,97061,9,8,3,'2019-11-07 00:22:03.561','2019-11-07 00:22:03.561',NULL,NULL,'5fc6895b95ac52c75d401c0edb1f6358'),(102780,94239,9,8,4,'2019-11-07 00:21:39.915','2019-11-07 00:27:05.953',NULL,NULL,'bd79b20edca27dbbcff22d25a51e6059'),(7045,7249,9,8,3,'2019-11-07 00:08:54.909','2019-11-07 00:08:54.909','2018-01-02 14:36:19.000',NULL,'daa1f732aaa807b0bf31845d10bac231'),(161085,7249,20,20,NULL,'2019-11-07 00:30:25.685','2019-11-07 00:30:46.525','2019-10-18 09:44:04.000',NULL,'7fcd59c22eecb4758d1cc7799216a827'),(7093,7293,9,8,3,'2019-11-07 00:08:54.909','2019-11-07 00:08:54.909',NULL,NULL,'3a036760d79ea492edbf742555216723'),(7076,7280,9,8,3,'2019-11-07 00:08:54.909','2019-11-07 00:08:54.909',NULL,NULL,'06668d905eae79adea04fb1619279a46');
/*!40000 ALTER TABLE `indicator_sources` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`threatquotient`@`localhost`*/ /*!50003 TRIGGER trig_indicator_sources_before_insert BEFORE INSERT ON indicator_sources
FOR EACH ROW BEGIN

  DECLARE defaultTlpId INTEGER UNSIGNED;

  SELECT fn_get_default_tlp_id_for_source(NEW.source_id) INTO defaultTlpId;

  IF (defaultTlpId IS NOT NULL) AND (NEW.tlp_id IS NULL)
  THEN
    SET NEW.tlp_id = defaultTlpId;
  END IF;

  SET NEW.sync_hash = MD5(CONCAT(NEW.indicator_id, NEW.source_id, NEW.creator_source_id));

END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`threatquotient`@`localhost`*/ /*!50003 TRIGGER trig_indicator_sources_after_insert AFTER INSERT ON indicator_sources
FOR EACH ROW BEGIN

  INSERT INTO
    indicator_source_audit_log (indicator_source_id, event_type, field, new_value, run_uuid, changed_by_source_id)
  VALUES
    (NEW.id, 'added', 'source_id', NEW.source_id, fn_uuid_to_binary(@CONNECTOR_RUN_UUID), @OWNER_SOURCE_ID);

  IF IFNULL(NEW.tlp_id, 0) <> 0
  THEN
    INSERT INTO
      indicator_source_audit_log (indicator_source_id, event_type, field, new_value, run_uuid, changed_by_source_id)
    VALUES
      (NEW.id, 'added', 'tlp_id', NEW.tlp_id, fn_uuid_to_binary(@CONNECTOR_RUN_UUID), @OWNER_SOURCE_ID);
  END IF;

  IF IFNULL(NEW.published_at, '0000-00-00 00:00:00.000') <> '0000-00-00 00:00:00.000'
  THEN
    INSERT INTO
      indicator_source_audit_log (indicator_source_id, event_type, field, new_value, run_uuid, changed_by_source_id)
    VALUES
      (NEW.id, 'added', 'published_at', NEW.published_at, fn_uuid_to_binary(@CONNECTOR_RUN_UUID), @OWNER_SOURCE_ID);
  END IF;

  IF @CONNECTOR_RUN_UUID IS NOT NULL
  THEN
    INSERT INTO
      connector_run_objects (run_uuid, object_id, object_type)
    VALUES
      (fn_uuid_to_binary(@CONNECTOR_RUN_UUID), NEW.id, 'indicator_sources');
  END IF;

  IF IFNULL(@SCORE_INDICATOR, TRUE) THEN
    IF fn_source_scorable(NEW.source_id) <> 'N' THEN
      SET @TOUCH_PARENT_INDICATOR_OLD = @TOUCH_PARENT_INDICATOR;
      SET @TOUCH_PARENT_INDICATOR = FALSE;

      INSERT
      INTO
        indicator_scores
      (
        indicator_id,
        score_config_hash
      )
      VALUES
      (
        NEW.indicator_id,
        'pending_score'
      )
      ON DUPLICATE KEY
      UPDATE
        score_config_hash = 'pending_score';

      SET @TOUCH_PARENT_INDICATOR = @TOUCH_PARENT_INDICATOR_OLD;
    END IF;
  END IF;

  -- touch parent
  IF IFNULL(@TOUCH_PARENT_INDICATOR, TRUE)
  THEN
    UPDATE
      indicators
    SET
      updated_at = updated_at,
      touched_at = NOW(3)
    WHERE
      id = NEW.indicator_id;
  END IF;

END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`threatquotient`@`localhost`*/ /*!50003 TRIGGER trig_indicator_sources_before_update BEFORE UPDATE ON indicator_sources
FOR EACH ROW BEGIN

  IF OLD.indicator_id <> NEW.indicator_id OR
    OLD.source_id <> NEW.source_id OR
    OLD.creator_source_id <> NEW.creator_source_id
  THEN
    SET NEW.sync_hash = MD5(CONCAT(NEW.indicator_id, NEW.source_id, NEW.creator_source_id));
  END IF;

END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`threatquotient`@`localhost`*/ /*!50003 TRIGGER trig_indicator_sources_after_update AFTER UPDATE ON indicator_sources
FOR EACH ROW indicator_sources_update_trigger: BEGIN

  DECLARE connectorRunUuid BINARY(16);

  IF (@TRIGGER_AFTER_UPDATE_INDICATOR_SOURCES = FALSE) AND (USER() = 'threatquotient@localhost')
  THEN
    LEAVE indicator_sources_update_trigger;
  END IF;

  -- Audit Logging
  IF IFNULL(OLD.source_id, '') <> IFNULL(NEW.source_id, '')
  THEN
    INSERT INTO
      indicator_source_audit_log (indicator_source_id, event_type, field, new_value, run_uuid, changed_by_source_id)
    VALUES
      (NEW.id, 'updated', 'value', NEW.source_id, fn_uuid_to_binary(@CONNECTOR_RUN_UUID), @OWNER_SOURCE_ID)
    ON DUPLICATE KEY UPDATE
      event_type = VALUES(event_type),
      new_value = VALUES(new_value),
      changed_by_source_id = VALUES(changed_by_source_id);
  END IF;

  IF IFNULL(OLD.tlp_id, 0) <> IFNULL(NEW.tlp_id, 0)
  THEN
    INSERT INTO
      indicator_source_audit_log (indicator_source_id, event_type, field, new_value, run_uuid, changed_by_source_id)
    VALUES
      (NEW.id, 'updated', 'tlp_id', NEW.tlp_id, fn_uuid_to_binary(@CONNECTOR_RUN_UUID), @OWNER_SOURCE_ID)
    ON DUPLICATE KEY UPDATE
      event_type = VALUES(event_type),
      new_value = VALUES(new_value),
      changed_by_source_id = VALUES(changed_by_source_id);
  END IF;

  IF IFNULL(OLD.published_at, '0000-00-00 00:00:00.000') <> IFNULL(NEW.published_at, '0000-00-00 00:00:00.000')
  THEN
    INSERT INTO
      indicator_source_audit_log (indicator_source_id, event_type, field, new_value, run_uuid, changed_by_source_id)
    VALUES
      (NEW.id, 'updated', 'published_at', NEW.published_at, fn_uuid_to_binary(@CONNECTOR_RUN_UUID), @OWNER_SOURCE_ID)
    ON DUPLICATE KEY UPDATE
      event_type = VALUES(event_type),
      new_value = VALUES(new_value),
      changed_by_source_id = VALUES(changed_by_source_id);
  END IF;

  IF @CONNECTOR_RUN_UUID IS NOT NULL
  THEN
    SELECT
      run_uuid
    INTO
      connectorRunUuid
    FROM
      connector_run_objects
    WHERE
      run_uuid = fn_uuid_to_binary(@CONNECTOR_RUN_UUID) AND object_id = NEW.id AND object_type = 'indicator_sources';

    IF ISNULL(connectorRunUuid)
    THEN
      INSERT INTO
        connector_run_objects (run_uuid, object_id, object_type)
      VALUES
        (fn_uuid_to_binary(@CONNECTOR_RUN_UUID), NEW.id, 'indicator_sources');
    END IF;
  END IF;

  IF IFNULL(@SCORE_INDICATOR, TRUE) THEN
    IF IFNULL(OLD.deleted_at, '') <> IFNULL(NEW.deleted_at, '') THEN
      IF fn_source_scorable(NEW.source_id) <> 'N' THEN
        SET @TOUCH_PARENT_INDICATOR_OLD = @TOUCH_PARENT_INDICATOR;
        SET @TOUCH_PARENT_INDICATOR = FALSE;

        INSERT
        INTO
          indicator_scores
        (
          indicator_id,
          score_config_hash
        )
        VALUES
        (
          NEW.indicator_id,
          'pending_score'
        )
        ON DUPLICATE KEY
        UPDATE
          score_config_hash = 'pending_score';

        SET @TOUCH_PARENT_INDICATOR = @TOUCH_PARENT_INDICATOR_OLD;
      END IF;
    END IF;
  END IF;

  -- touch parent
  IF IFNULL(@TOUCH_PARENT_INDICATOR, TRUE)
  THEN
    UPDATE
      indicators
    SET
      updated_at = updated_at,
      touched_at = NOW(3)
    WHERE
      id = NEW.indicator_id;
  END IF;

END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-11-07  0:57:09
