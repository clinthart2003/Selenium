-- MySQL dump 10.16  Distrib 10.3.9-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: threatquotient2
-- ------------------------------------------------------
-- Server version	10.3.9-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `indicator_attributes`
--

DROP TABLE IF EXISTS `indicator_attributes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `indicator_attributes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `indicator_id` int(10) unsigned NOT NULL,
  `attribute_id` int(10) unsigned NOT NULL,
  `value` text COLLATE utf8_unicode_ci NOT NULL,
  `created_at` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `updated_at` datetime(3) NOT NULL DEFAULT current_timestamp(3) ON UPDATE current_timestamp(3),
  `touched_at` datetime(3) NOT NULL DEFAULT current_timestamp(3) ON UPDATE current_timestamp(3) COMMENT 'Date and time the Indicator Attribute or its'' Sources were modified.',
  `deleted_at` datetime(3) DEFAULT NULL,
  `sync_hash` char(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `indicator_attributes_indicator_id_index` (`indicator_id`),
  KEY `indicator_attributes_attribute_id_index` (`attribute_id`),
  KEY `indicator_attributes_deleted_at_index` (`deleted_at`),
  KEY `indicator_attributes_value_index` (`value`(255)),
  KEY `indicator_attributes_touched_at_index` (`touched_at`),
  KEY `indicator_attributes_updated_at_index` (`updated_at`),
  KEY `indicator_attribute_index` (`indicator_id`,`attribute_id`),
  KEY `sync_hash_index` (`sync_hash`)
) ENGINE=InnoDB AUTO_INCREMENT=165668 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `indicator_attributes`
--
-- WHERE:  `indicator_id` in (SELECT id FROM `object_audit_id_lookup` WHERE key_column = 'indicator_id')

LOCK TABLES `indicator_attributes` WRITE;
/*!40000 ALTER TABLE `indicator_attributes` DISABLE KEYS */;
INSERT  IGNORE INTO `indicator_attributes` VALUES (41304,97061,36,'NCCIC:Observable-843e9509-7a42-4b0b-a3d8-1ea9039de35f','2019-11-07 00:22:03.759','2019-11-07 00:22:03.759','2019-11-07 00:22:03.759',NULL,'3113f6656c61e427a1d7deb55dc273d6'),(41305,97061,36,'NCCIC:Package-bdcfb4e2-af52-47f1-a625-318ddf67cc29','2019-11-07 00:22:03.772','2019-11-07 00:22:03.772','2019-11-07 00:22:03.772',NULL,'849eac7de75627f5e22b099b79ff7847'),(41307,97061,36,'NCCIC:URI-62ce3219-de20-4416-995d-7e8f23d62653','2019-11-07 00:22:03.784','2019-11-07 00:22:03.784','2019-11-07 00:22:03.784',NULL,'bbb273413e26eb4a2ed55aa55ffae209'),(41309,97061,57,'The victim was redacted from the URI address. The domain, wufoo.com is a legitimate online form service owned by SurveyMonkey.','2019-11-07 00:22:03.796','2019-11-07 00:22:03.796','2019-11-07 00:22:03.796',NULL,'f1b4765a10682f7281fb9451a938e706'),(40636,94239,36,'NCCIC:URI-e1e7bbbf-981e-409c-a4f8-f6a747ccbd7d','2019-11-07 00:21:40.299','2019-11-07 00:21:40.299','2019-11-07 00:21:40.299',NULL,'3ffcde3ceded61418a9d2186b313e29f'),(40638,94239,57,'Connects to \"www.imageliners.com/nitel\"','2019-11-07 00:21:40.313','2019-11-07 00:21:40.313','2019-11-07 00:21:40.313',NULL,'a1ddd96784c41eec55cd1973b6cd3d71'),(40640,94239,36,'NCCIC:Observable-7fe33c63-e41b-4129-a50e-9ef83645b719','2019-11-07 00:21:40.323','2019-11-07 00:21:40.323','2019-11-07 00:21:40.323',NULL,'d9bba59728e14aa9b3fe7a710e020c8b'),(40642,94239,36,'NCCIC:Package-c52b3a4a-4191-446b-845a-c621367ad123','2019-11-07 00:21:40.335','2019-11-07 00:21:40.335','2019-11-07 00:21:40.335',NULL,'72519020d9a620cd9c51fc2d0ebcad52'),(9555,7249,75,'URL Watchlist','2019-11-07 00:08:55.233','2019-11-07 00:08:56.299','2019-11-07 00:08:56.299',NULL,'c4ee63f41e3ab46c1568cc3e118bbb6d'),(9556,7249,57,'According to a trusted third party, this is a payload URL.','2019-11-07 00:08:55.237','2019-11-07 00:08:56.309','2019-11-07 00:08:56.309',NULL,'8e692ecc60ca33f584a3da7a180c3c29'),(9557,7249,36,'NCCIC:Object-f135be0c-cf94-11e7-83dd-0050569c6b2d','2019-11-07 00:08:55.241','2019-11-07 00:08:55.241','2019-11-07 00:08:55.241',NULL,'7f2e9407f1f60a5a56a0ff63df8ca926'),(9558,7249,36,'indicator-f135be0b-cf94-11e7-a71f-0050569c6b2d','2019-11-07 00:08:55.245','2019-11-07 00:08:55.245','2019-11-07 00:08:55.245',NULL,'4b7aaf99ba6132e2b4f8a8dc88cf6a7f'),(9559,7249,36,'IB-17-20294A','2019-11-07 00:08:55.249','2019-11-07 00:08:56.313','2019-11-07 00:08:56.313',NULL,'7da769f057fd411070cc77e4a21f06a2'),(9560,7249,36,'NCCIC:Observable-6973ec32-6138-494f-95aa-45b5c6e2094e','2019-11-07 00:08:55.253','2019-11-07 00:08:55.253','2019-11-07 00:08:55.253',NULL,'1201c5c6f1061297490bad16f1a42c1e'),(9561,7249,77,'Malicious URL Indicator','2019-11-07 00:08:55.257','2019-11-07 00:08:56.326','2019-11-07 00:08:56.326',NULL,'1e85321c198204e31c7f6268286c3e03'),(9562,7249,44,'Delivery','2019-11-07 00:08:55.261','2019-11-07 00:08:56.332','2019-11-07 00:08:56.332',NULL,'03203fd2779dc1201245adff0bcf4391'),(9563,7249,1,'https','2019-11-07 00:08:55.265','2019-11-07 00:30:25.781','2019-11-07 00:30:25.781',NULL,'879ed2fca030f350154b0f0c0951da9f'),(9564,7249,2,'authuser=0&id=17HxItEeUg2cdIsg3VnMPqhUe5yEc5bgr','2019-11-07 00:08:55.269','2019-11-07 00:08:55.269','2019-11-07 00:08:55.269',NULL,'5630665d3e20219da06a8ff2f9752ceb'),(9610,7249,36,'NCCIC:Observable-971c8ecd-dbe6-47bf-b3f4-67f4f3c56082','2019-11-07 00:08:55.471','2019-11-07 00:08:55.471','2019-11-07 00:08:55.471',NULL,'21ba3e0e87b3044b08ba799f7302e946'),(9611,7249,36,'indicator-f135bdf0-cf94-11e7-bb9f-0050569c6b2d','2019-11-07 00:08:55.475','2019-11-07 00:08:55.475','2019-11-07 00:08:55.475',NULL,'36337b0ee24e5780c38e62024e34f650'),(9612,7249,36,'NCCIC:Object-f135bdf1-cf94-11e7-b364-0050569c6b2d','2019-11-07 00:08:55.479','2019-11-07 00:08:55.479','2019-11-07 00:08:55.479',NULL,'f8765c976b337cc303a848d5b5f0e743'),(9613,7249,2,'authuser=0&id=14HDwZSKvR0fD_iv6nadCSm7LKv19MlC0','2019-11-07 00:08:55.498','2019-11-07 00:08:55.498','2019-11-07 00:08:55.498',NULL,'2dc26d668d67787d454beb2ec691be3e'),(9623,7249,36,'NCCIC:Observable-19cf347d-0aad-454e-a3e8-727801fc3c3e','2019-11-07 00:08:55.546','2019-11-07 00:08:55.546','2019-11-07 00:08:55.546',NULL,'abe36f1ad40a1be96fb6a4e632cd0ce4'),(9624,7249,36,'NCCIC:Object-f135bdf4-cf94-11e7-ab96-0050569c6b2d','2019-11-07 00:08:55.554','2019-11-07 00:08:55.554','2019-11-07 00:08:55.554',NULL,'71d109f5f0a09944a8eee50efa45282b'),(9625,7249,36,'indicator-f135bdf3-cf94-11e7-a318-0050569c6b2d','2019-11-07 00:08:55.558','2019-11-07 00:08:55.558','2019-11-07 00:08:55.558',NULL,'94a198e7cb9be3b2d369780cb8876f93'),(9626,7249,2,'authuser=0&id=1izsHmAct9vptBXTuRSOqGDBjj-0yOWSt','2019-11-07 00:08:55.577','2019-11-07 00:08:55.577','2019-11-07 00:08:55.577',NULL,'a405c300eb622df18eee65e934a84e4e'),(9627,7249,36,'NCCIC:Object-f135be06-cf94-11e7-bbb0-0050569c6b2d','2019-11-07 00:08:55.585','2019-11-07 00:08:55.585','2019-11-07 00:08:55.585',NULL,'c50755803b5863c9892849e240a41e9d'),(9628,7249,36,'indicator-f135be05-cf94-11e7-9867-0050569c6b2d','2019-11-07 00:08:55.593','2019-11-07 00:08:55.593','2019-11-07 00:08:55.593',NULL,'62fd31244786acb265ac9e69088bbe4b'),(9629,7249,36,'NCCIC:Observable-d983e01a-3b5b-4417-a75f-62a88b4f733b','2019-11-07 00:08:55.608','2019-11-07 00:08:55.608','2019-11-07 00:08:55.608',NULL,'1e7354c5a433a15176c836e50c049a06'),(9630,7249,2,'authuser=0&id=1oquCzJxsv0EeuvSca4r31k07asN2_pp4','2019-11-07 00:08:55.616','2019-11-07 00:08:55.616','2019-11-07 00:08:55.616',NULL,'2c2c3440ac1f35ab80e0555e0b23e31d'),(9658,7249,36,'NCCIC:Observable-6004495d-1b5e-4a57-b7c6-29b562e7de79','2019-11-07 00:08:55.748','2019-11-07 00:08:55.748','2019-11-07 00:08:55.748',NULL,'cf5b674635f44b469be6c424f36d91cf'),(9659,7249,36,'indicator-f135be02-cf94-11e7-a38a-0050569c6b2d','2019-11-07 00:08:55.757','2019-11-07 00:08:55.757','2019-11-07 00:08:55.757',NULL,'d47589e4113bee324bda2f1571341f89'),(9660,7249,36,'NCCIC:Object-f135be03-cf94-11e7-bd51-0050569c6b2d','2019-11-07 00:08:55.761','2019-11-07 00:08:55.761','2019-11-07 00:08:55.761',NULL,'eb3d9f9c8e031e180581cecd1997fccb'),(9661,7249,2,'authuser=0&id=1WegQDVKPDTdUB-gp4yqGqGcNPCVt6LHz','2019-11-07 00:08:55.776','2019-11-07 00:08:55.776','2019-11-07 00:08:55.776',NULL,'c9e78c633845dc32be1670680c59b158'),(9721,7249,36,'indicator-f135bdf6-cf94-11e7-97d6-0050569c6b2d','2019-11-07 00:08:56.029','2019-11-07 00:08:56.029','2019-11-07 00:08:56.029',NULL,'f84651ee201e2d519dba91f3ccac6338'),(9722,7249,36,'NCCIC:Observable-b6bf4e52-b40e-4f18-9a18-112fc1032f49','2019-11-07 00:08:56.041','2019-11-07 00:08:56.041','2019-11-07 00:08:56.041',NULL,'5cb179dd6690b6d93c9e1770059fa529'),(9723,7249,36,'NCCIC:Object-f135bdf7-cf94-11e7-be5a-0050569c6b2d','2019-11-07 00:08:56.045','2019-11-07 00:08:56.045','2019-11-07 00:08:56.045',NULL,'9e09eb33da4f84a48e9e737b3e851245'),(9724,7249,2,'authuser=0&id=1eMK86QEeKfnpWH_TkfPVJRGPRk6YxI7D','2019-11-07 00:08:56.060','2019-11-07 00:08:56.060','2019-11-07 00:08:56.060',NULL,'088f76007a57043ca779fa47e9768acd'),(9743,7249,36,'NCCIC:Object-f135bdfd-cf94-11e7-83cb-0050569c6b2d','2019-11-07 00:08:56.148','2019-11-07 00:08:56.148','2019-11-07 00:08:56.148',NULL,'ebc7c501dca81c822fe3ab55715fa788'),(9744,7249,36,'indicator-f135bdfc-cf94-11e7-ad54-0050569c6b2d','2019-11-07 00:08:56.157','2019-11-07 00:08:56.157','2019-11-07 00:08:56.157',NULL,'6367c7c7799189261ecab3642580e2ad'),(9745,7249,36,'NCCIC:Observable-d12b46b2-f76a-475e-a64a-5cf6286e363d','2019-11-07 00:08:56.161','2019-11-07 00:08:56.161','2019-11-07 00:08:56.161',NULL,'dc2a010f8151ece84f7aee8a0608bbd6'),(9746,7249,2,'authuser=0&id=108Zu3Xx7yMIzqolAUuXLryhbnXkygm4y','2019-11-07 00:08:56.173','2019-11-07 00:08:56.173','2019-11-07 00:08:56.173',NULL,'669f81200ad70b1807844debf037c10b'),(9747,7249,36,'indicator-f135bdff-cf94-11e7-89c2-0050569c6b2d','2019-11-07 00:08:56.180','2019-11-07 00:08:56.180','2019-11-07 00:08:56.180',NULL,'cb20eb577ab147a250437d8111037d8a'),(9748,7249,36,'NCCIC:Observable-fb1d1e94-4c2e-4770-9816-15f94ba82bd2','2019-11-07 00:08:56.188','2019-11-07 00:08:56.188','2019-11-07 00:08:56.188',NULL,'4b3a43e4919987202f6a266a0068938e'),(9749,7249,36,'NCCIC:Object-f135be00-cf94-11e7-927b-0050569c6b2d','2019-11-07 00:08:56.198','2019-11-07 00:08:56.198','2019-11-07 00:08:56.198',NULL,'0214c568fa4da9666fa3f975eb0dacf4'),(9750,7249,2,'authuser=0&id=1ssfADbXZy8Xydz92GYE8wB1ZedQrjSDj','2019-11-07 00:08:56.214','2019-11-07 00:08:56.214','2019-11-07 00:08:56.214',NULL,'821c6a089e923b36354bd1d56aa642e7'),(9751,7249,36,'NCCIC:Object-f135be09-cf94-11e7-8c10-0050569c6b2d','2019-11-07 00:08:56.222','2019-11-07 00:08:56.222','2019-11-07 00:08:56.222',NULL,'fdfe190f15df4287baddd1b12543ce4f'),(9752,7249,36,'indicator-f135be08-cf94-11e7-bc32-0050569c6b2d','2019-11-07 00:08:56.226','2019-11-07 00:08:56.226','2019-11-07 00:08:56.226',NULL,'5de634ac31363fa1b058037db736201b'),(9753,7249,36,'NCCIC:Observable-2ae8cde4-5b8f-40e5-882f-f56bf74b7cea','2019-11-07 00:08:56.234','2019-11-07 00:08:56.234','2019-11-07 00:08:56.234',NULL,'4138758e13a51c37b198cf86984cf4a6'),(9754,7249,2,'authuser=0&id=188a48hkZoADY_w_dg_9dVVxdfaK7ZD-I','2019-11-07 00:08:56.254','2019-11-07 00:08:56.254','2019-11-07 00:08:56.254',NULL,'a45ffde809fa51d52f3028c467f39a21'),(9764,7249,36,'NCCIC:Object-f135bdfa-cf94-11e7-8a5b-0050569c6b2d','2019-11-07 00:08:56.304','2019-11-07 00:08:56.304','2019-11-07 00:08:56.304',NULL,'120237190afc37506eeb8f0f609c4695'),(9765,7249,36,'NCCIC:Observable-b45fcbaf-0dac-4fa3-b55d-1b16bb2492ed','2019-11-07 00:08:56.317','2019-11-07 00:08:56.317','2019-11-07 00:08:56.317',NULL,'5ba3859186aa010b4377f92d9b82a650'),(9766,7249,36,'indicator-f135bdf9-cf94-11e7-a08f-0050569c6b2d','2019-11-07 00:08:56.321','2019-11-07 00:08:56.321','2019-11-07 00:08:56.321',NULL,'fbf6e453bcee9170bc8069125f3e230d'),(9767,7249,2,'authuser=0&id=1e1Jx_g6VvsgClWE4KsA69gGTtYf4bcrv','2019-11-07 00:08:56.340','2019-11-07 00:08:56.340','2019-11-07 00:08:56.340',NULL,'b8c38d9bccba3bd56ab49816aa36e855'),(61581,7249,115,'rar','2019-11-07 00:30:25.698','2019-11-07 00:30:25.769','2019-11-07 00:30:25.769',NULL,'0f1e8d47d4c96a23ed4e312da0cdb99d'),(61582,7249,2,'export=download&id=181IOXflgdim7TLux1mXD9VRIT51XLWrI','2019-11-07 00:30:25.741','2019-11-07 00:30:25.741','2019-11-07 00:30:25.741',NULL,'bf9ece077dafd59bd1324453a963f8d2'),(61583,7249,2,'export=download&id=1ns2KLQ3FFNY9YOFjRwJENly3vxBlTPi0','2019-11-07 00:30:25.789','2019-11-07 00:30:25.789','2019-11-07 00:30:25.789',NULL,'25c6f828454fbdd40d050bf22aace81c');
/*!40000 ALTER TABLE `indicator_attributes` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`threatquotient`@`localhost`*/ /*!50003 TRIGGER trig_indicator_attributes_before_insert BEFORE INSERT ON indicator_attributes
FOR EACH ROW BEGIN

  SET NEW.sync_hash = MD5(CONCAT(NEW.indicator_id, NEW.attribute_id, NEW.value));

END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`threatquotient`@`localhost`*/ /*!50003 TRIGGER trig_indicator_attributes_after_insert AFTER INSERT ON indicator_attributes
FOR EACH ROW BEGIN

  INSERT INTO
    indicator_attribute_audit_log (indicator_attribute_id, event_type, attribute_id, new_value, run_uuid, changed_by_source_id)
  VALUES
    (NEW.id, 'added', NEW.attribute_id, NEW.value, fn_uuid_to_binary(@CONNECTOR_RUN_UUID), @OWNER_SOURCE_ID);

  IF @CONNECTOR_RUN_UUID IS NOT NULL
  THEN
    INSERT INTO
      connector_run_objects (run_uuid, object_id, object_type)
    VALUES
      (fn_uuid_to_binary(@CONNECTOR_RUN_UUID), NEW.id, 'indicator_attributes');
  END IF;

  IF IFNULL(@SCORE_INDICATOR, TRUE) THEN
    IF fn_attribute_value_scorable(NEW.attribute_id, NEW.value) <> 'N' THEN
      SET @TOUCH_PARENT_INDICATOR_OLD = @TOUCH_PARENT_INDICATOR;
      SET @TOUCH_PARENT_INDICATOR = FALSE;

      INSERT
      INTO
        indicator_scores
      (
        indicator_id,
        score_config_hash
      )
      VALUES
      (
        NEW.indicator_id,
        'pending_score'
      )
      ON DUPLICATE KEY
      UPDATE
        score_config_hash = 'pending_score';

      SET @TOUCH_PARENT_INDICATOR = @TOUCH_PARENT_INDICATOR_OLD;
    END IF;
  END IF;

  -- touch parent
  IF IFNULL(@TOUCH_PARENT_INDICATOR, TRUE)
  THEN
    UPDATE
      indicators
    SET
      updated_at = updated_at,
      touched_at = NOW(3)
    WHERE
      id = NEW.indicator_id;
  END IF;

END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`threatquotient`@`localhost`*/ /*!50003 TRIGGER trig_indicator_attributes_before_update BEFORE UPDATE ON indicator_attributes
FOR EACH ROW BEGIN

  IF OLD.indicator_id <> NEW.indicator_id OR OLD.attribute_id <> NEW.attribute_id OR OLD.value <> NEW.value THEN
    SET NEW.sync_hash = MD5(CONCAT(NEW.indicator_id, NEW.attribute_id, NEW.value));
  END IF;

END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`threatquotient`@`localhost`*/ /*!50003 TRIGGER trig_indicator_attributes_after_update AFTER UPDATE ON indicator_attributes
FOR EACH ROW BEGIN

  DECLARE connectorRunUuid BINARY(16);

  IF IFNULL(OLD.deleted_at, '') <> IFNULL(NEW.deleted_at, '')
  THEN
    INSERT INTO
      indicator_attribute_audit_log (indicator_attribute_id, event_type, attribute_id, new_value, run_uuid, changed_by_source_id)
    VALUES
      (NEW.id, IF(NEW.deleted_at IS NULL, 'undeleted', 'deleted'), NEW.attribute_id, NEW.value, fn_uuid_to_binary(@CONNECTOR_RUN_UUID), @OWNER_SOURCE_ID)
    ON DUPLICATE KEY UPDATE
      event_type = VALUES(event_type),
      new_value = VALUES(new_value),
      changed_by_source_id = VALUES(changed_by_source_id);

    -- cascade delete
    IF IFNULL(NEW.deleted_at, FALSE)
    THEN
      -- prevent cascade recursion
      SET @TOUCH_PARENT_INDICATOR_ATTRIBUTE = FALSE;

      UPDATE
        indicator_attribute_sources
      SET
        deleted_at = NEW.deleted_at
      WHERE
        indicator_attribute_id = NEW.id AND
        deleted_at IS NULL;

      -- prevent cascade recursion
      SET @TOUCH_PARENT_INDICATOR_ATTRIBUTE = TRUE;
    END IF;

  ELSE
    IF OLD.value <> NEW.value
    THEN
      INSERT INTO
        indicator_attribute_audit_log (indicator_attribute_id, event_type, attribute_id, new_value, run_uuid, changed_by_source_id)
      VALUES
        (NEW.id, 'updated', NEW.attribute_id, NEW.value, fn_uuid_to_binary(@CONNECTOR_RUN_UUID), @OWNER_SOURCE_ID)
      ON DUPLICATE KEY UPDATE
        event_type = VALUES(event_type),
        new_value = VALUES(new_value),
        changed_by_source_id = VALUES(changed_by_source_id);
    END IF;
  END IF;

  IF @CONNECTOR_RUN_UUID IS NOT NULL
  THEN
    SELECT
      run_uuid
    INTO
      connectorRunUuid
    FROM
      connector_run_objects
    WHERE
      run_uuid = fn_uuid_to_binary(@CONNECTOR_RUN_UUID) AND object_id = NEW.id AND object_type = 'indicator_attributes';

    IF ISNULL(connectorRunUuid)
    THEN
      INSERT INTO
        connector_run_objects (run_uuid, object_id, object_type)
      VALUES
        (fn_uuid_to_binary(@CONNECTOR_RUN_UUID), NEW.id, 'indicator_attributes');
    END IF;
  END IF;

  IF IFNULL(@SCORE_INDICATOR, TRUE) THEN
    IF (
      OLD.attribute_id <> NEW.attribute_id
      OR OLD.value <> NEW.value
      OR IFNULL(OLD.deleted_at, '') <> IFNULL(NEW.deleted_at, '')
    ) THEN
      IF fn_attribute_value_scorable(NEW.attribute_id, NEW.value) <> 'N' THEN
        SET @TOUCH_PARENT_INDICATOR_OLD = @TOUCH_PARENT_INDICATOR;
        SET @TOUCH_PARENT_INDICATOR = FALSE;

        INSERT
        INTO
          indicator_scores
        (
          indicator_id,
          score_config_hash
        )
        VALUES
        (
          NEW.indicator_id,
          'pending_score'
        )
        ON DUPLICATE KEY
        UPDATE
          score_config_hash = 'pending_score';

        SET @TOUCH_PARENT_INDICATOR = @TOUCH_PARENT_INDICATOR_OLD;
      END IF;
    END IF;
  END IF;

  -- touch parent
  IF IFNULL(@TOUCH_PARENT_INDICATOR, TRUE)
  THEN
    UPDATE
      indicators
    SET
      updated_at = updated_at,
      touched_at = NOW(3)
    WHERE
      id = NEW.indicator_id;
  END IF;

END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-11-07  0:57:10
