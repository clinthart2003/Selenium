-- MySQL dump 10.16  Distrib 10.3.9-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: threatquotient2
-- ------------------------------------------------------
-- Server version	10.3.9-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `indicator_types`
--

DROP TABLE IF EXISTS `indicator_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `indicator_types` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` char(32) COLLATE utf8_unicode_ci NOT NULL,
  `class` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `score` int(11) DEFAULT NULL,
  `wildcard_matching` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `created_at` datetime(3) NOT NULL DEFAULT '0000-00-00 00:00:00.000',
  `updated_at` datetime(3) NOT NULL DEFAULT '0000-00-00 00:00:00.000',
  `deleted_at` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `indicator_types_name_unique` (`name`),
  KEY `indicator_types_deleted_at_index` (`deleted_at`),
  KEY `indicator_types_updated_at_index` (`updated_at`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `indicator_types`
--

LOCK TABLES `indicator_types` WRITE;
/*!40000 ALTER TABLE `indicator_types` DISABLE KEYS */;
INSERT  IGNORE INTO `indicator_types` VALUES (1,'Binary String','host',NULL,'Y','2019-03-26 18:21:23.000','2019-03-26 18:21:23.000',NULL),(2,'CIDR Block','network',NULL,'Y','2019-03-26 18:21:23.000','2019-03-26 18:21:23.000',NULL),(3,'CVE','host',NULL,'Y','2019-03-26 18:21:23.000','2019-03-26 18:21:23.000',NULL),(4,'Email Address','network',NULL,'Y','2019-03-26 18:21:23.000','2019-03-26 18:21:23.000',NULL),(5,'Email Attachment','network',NULL,'Y','2019-03-26 18:21:23.000','2019-03-26 18:21:23.000',NULL),(6,'Email Subject','network',NULL,'Y','2019-03-26 18:21:23.000','2019-03-26 18:21:23.000',NULL),(7,'File Mapping','host',NULL,'Y','2019-03-26 18:21:23.000','2019-03-26 18:21:23.000',NULL),(8,'File Path','host',NULL,'Y','2019-03-26 18:21:23.000','2019-03-26 18:21:23.000',NULL),(9,'Filename','host',NULL,'Y','2019-03-26 18:21:23.000','2019-03-26 18:21:23.000',NULL),(10,'FQDN','network',NULL,'Y','2019-03-26 18:21:23.000','2019-03-26 18:21:23.000',NULL),(11,'Fuzzy Hash','host',NULL,'N','2019-03-26 18:21:23.000','2019-03-26 18:21:23.000',NULL),(12,'GOST Hash','host',NULL,'N','2019-03-26 18:21:23.000','2019-03-26 18:21:23.000',NULL),(13,'Hash ION','host',NULL,'Y','2019-03-26 18:21:23.000','2019-03-26 18:21:23.000',NULL),(14,'IP Address','network',NULL,'N','2019-03-26 18:21:23.000','2019-03-26 18:21:23.000',NULL),(15,'IPv6 Address','network',NULL,'N','2019-03-26 18:21:23.000','2019-03-26 18:21:23.000',NULL),(16,'MD5','host',NULL,'N','2019-03-26 18:21:23.000','2019-03-26 18:21:23.000',NULL),(17,'Mutex','host',NULL,'N','2019-03-26 18:21:23.000','2019-03-26 18:21:23.000',NULL),(18,'Password','host',NULL,'Y','2019-03-26 18:21:23.000','2019-03-26 18:21:23.000',NULL),(19,'Registry Key','host',NULL,'N','2019-03-26 18:21:23.000','2019-03-26 18:21:23.000',NULL),(20,'Service Name','host',NULL,'Y','2019-03-26 18:21:23.000','2019-03-26 18:21:23.000',NULL),(21,'SHA-1','host',NULL,'N','2019-03-26 18:21:23.000','2019-03-26 18:21:23.000',NULL),(22,'SHA-256','host',NULL,'N','2019-03-26 18:21:23.000','2019-03-26 18:21:23.000',NULL),(23,'SHA-384','host',NULL,'N','2019-03-26 18:21:23.000','2019-03-26 18:21:23.000',NULL),(24,'SHA-512','host',NULL,'N','2019-03-26 18:21:23.000','2019-03-26 18:21:23.000',NULL),(25,'String','network',NULL,'Y','2019-03-26 18:21:23.000','2019-03-26 18:21:23.000',NULL),(26,'x509 Serial','network',NULL,'Y','2019-03-26 18:21:23.000','2019-03-26 18:21:23.000',NULL),(27,'x509 Subject','network',NULL,'Y','2019-03-26 18:21:23.000','2019-03-26 18:21:23.000',NULL),(28,'URL','network',NULL,'Y','2019-03-26 18:21:23.000','2019-03-26 18:21:23.000',NULL),(29,'URL Path','network',NULL,'Y','2019-03-26 18:21:23.000','2019-03-26 18:21:23.000',NULL),(30,'User-agent','network',NULL,'Y','2019-03-26 18:21:23.000','2019-03-26 18:21:23.000',NULL),(31,'Username','host',NULL,'Y','2019-03-26 18:21:23.000','2019-03-26 18:21:23.000',NULL),(32,'X-Mailer','network',NULL,'Y','2019-03-26 18:21:23.000','2019-03-26 18:21:23.000',NULL);
/*!40000 ALTER TABLE `indicator_types` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-11-07  1:10:56
