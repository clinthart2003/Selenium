-- MySQL dump 10.16  Distrib 10.3.9-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: threatquotient2
-- ------------------------------------------------------
-- Server version	10.3.9-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tagged_object_audit_log`
--

DROP TABLE IF EXISTS `tagged_object_audit_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tagged_object_audit_log` (
  `tag_id` int(10) unsigned NOT NULL,
  `object_id` int(10) unsigned NOT NULL,
  `object_type` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `event_type` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `changed_by_source_id` int(10) unsigned DEFAULT NULL,
  `changed_at` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  PRIMARY KEY (`tag_id`,`object_id`,`object_type`,`changed_at`),
  KEY `tagged_object_audit_log_tag_id_index` (`tag_id`),
  KEY `tagged_object_audit_log_object_id_index` (`object_id`),
  KEY `tagged_object_audit_log_object_type_index` (`object_type`),
  KEY `tagged_object_audit_log_event_type_index` (`event_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tagged_object_audit_log`
--
-- WHERE:  `object_type`='indicator' AND `object_id` IN (SELECT id FROM `object_audit_id_lookup` WHERE key_column = 'indicator_id')

LOCK TABLES `tagged_object_audit_log` WRITE;
/*!40000 ALTER TABLE `tagged_object_audit_log` DISABLE KEYS */;
INSERT  IGNORE INTO `tagged_object_audit_log` VALUES (68,99958,'indicator','added',8,'2019-11-07 00:22:39.386'),(67,97061,'indicator','added',8,'2019-11-07 00:22:03.880'),(66,94239,'indicator','added',8,'2019-11-07 00:21:40.359'),(73,94239,'indicator','added',8,'2019-11-07 00:27:20.227'),(48,7249,'indicator','added',8,'2019-11-07 00:08:56.446'),(48,7293,'indicator','added',8,'2019-11-07 00:08:56.446'),(48,7280,'indicator','added',8,'2019-11-07 00:08:56.446');
/*!40000 ALTER TABLE `tagged_object_audit_log` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-11-07  1:10:57
