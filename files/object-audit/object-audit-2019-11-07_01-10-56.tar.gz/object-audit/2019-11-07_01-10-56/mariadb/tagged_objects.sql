-- MySQL dump 10.16  Distrib 10.3.9-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: threatquotient2
-- ------------------------------------------------------
-- Server version	10.3.9-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tagged_objects`
--

DROP TABLE IF EXISTS `tagged_objects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tagged_objects` (
  `tag_id` int(10) unsigned NOT NULL,
  `object_id` int(10) unsigned NOT NULL,
  `object_type` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` datetime(3) NOT NULL DEFAULT '0000-00-00 00:00:00.000',
  `updated_at` datetime(3) NOT NULL DEFAULT '0000-00-00 00:00:00.000',
  PRIMARY KEY (`object_type`,`object_id`,`tag_id`),
  KEY `tagged_objects_object_id_index` (`object_id`),
  KEY `tagged_objects_tag_id_index` (`tag_id`),
  KEY `tagged_objects_updated_at_index` (`updated_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tagged_objects`
--
-- WHERE:  `object_type`='indicator' AND `object_id` IN (SELECT id FROM `object_audit_id_lookup` WHERE key_column = 'indicator_id')

LOCK TABLES `tagged_objects` WRITE;
/*!40000 ALTER TABLE `tagged_objects` DISABLE KEYS */;
INSERT  IGNORE INTO `tagged_objects` VALUES (68,99958,'indicator','2019-11-07 00:22:39.386','2019-11-07 00:22:39.386'),(67,97061,'indicator','2019-11-07 00:22:03.880','2019-11-07 00:22:03.880'),(66,94239,'indicator','2019-11-07 00:21:40.359','2019-11-07 00:21:40.359'),(73,94239,'indicator','2019-11-07 00:27:20.227','2019-11-07 00:27:20.227'),(48,7249,'indicator','2019-11-07 00:08:56.446','2019-11-07 00:08:56.446'),(48,7293,'indicator','2019-11-07 00:08:56.446','2019-11-07 00:08:56.446'),(48,7280,'indicator','2019-11-07 00:08:56.446','2019-11-07 00:08:56.446');
/*!40000 ALTER TABLE `tagged_objects` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`threatquotient`@`localhost`*/ /*!50003 TRIGGER trig_tagged_objects_after_insert AFTER INSERT ON tagged_objects
FOR EACH ROW BEGIN

  INSERT INTO tagged_object_audit_log (tag_id, object_id, object_type, event_type, changed_by_source_id)
  VALUES (new.tag_id, new.object_id, new.object_type, 'added', @owner_source_id);

  IF IFNULL(@TOUCH_PARENT_OBJECT, TRUE) THEN
    CASE
      WHEN new.object_type = 'adversary' THEN
        IF IFNULL(@TOUCH_PARENT_ADVERSARY, TRUE) THEN
            UPDATE adversaries
            SET
              updated_at = updated_at,
              touched_at = NOW(3)
            WHERE
              id = new.object_id;
        END IF;

      WHEN new.object_type = 'attachment' THEN
        IF IFNULL(@TOUCH_PARENT_ATTACHMENT, TRUE) THEN
            UPDATE attachments
            SET
              updated_at = updated_at,
              touched_at = NOW(3)
            WHERE
              id = new.object_id;
        END IF;

      WHEN new.object_type = 'event' THEN
        IF IFNULL(@TOUCH_PARENT_EVENT, TRUE) THEN
            UPDATE events
            SET
              updated_at = updated_at,
              touched_at = NOW(3)
            WHERE
              id = new.object_id;
        END IF;

      WHEN new.object_type = 'indicator' THEN
        IF IFNULL(@TOUCH_PARENT_INDICATOR, TRUE) THEN
            UPDATE indicators
            SET
              updated_at = updated_at,
              touched_at = NOW(3)
            WHERE
              id = new.object_id;
        END IF;

      WHEN new.object_type = 'signature' THEN
        IF IFNULL(@TOUCH_PARENT_SIGNATURE, TRUE) THEN
            UPDATE signatures
            SET
              updated_at = updated_at,
              touched_at = NOW(3)
            WHERE
              id = new.object_id;
        END IF;

      WHEN new.object_type = 'task' THEN
        IF IFNULL(@TOUCH_PARENT_TASK, TRUE) THEN
            UPDATE tasks
            SET
              updated_at = NOW(3)
            WHERE
              id = new.object_id;
        END IF;
      
        -- The following code is used to generate triggers for custom objects
        -- and the section is replicated for each campaign defined
      WHEN new.object_type = 'campaign' THEN
        IF IFNULL(@TOUCH_PARENT_campaign, TRUE) THEN
            UPDATE campaign
            SET
              updated_at = updated_at,
              touched_at = NOW(3)
            WHERE
              id = new.object_id;
        END IF;
      	
        -- The following code is used to generate triggers for custom objects
        -- and the section is replicated for each course_of_action defined
      WHEN new.object_type = 'course_of_action' THEN
        IF IFNULL(@TOUCH_PARENT_course_of_action, TRUE) THEN
            UPDATE course_of_action
            SET
              updated_at = updated_at,
              touched_at = NOW(3)
            WHERE
              id = new.object_id;
        END IF;
      	
        -- The following code is used to generate triggers for custom objects
        -- and the section is replicated for each exploit_target defined
      WHEN new.object_type = 'exploit_target' THEN
        IF IFNULL(@TOUCH_PARENT_exploit_target, TRUE) THEN
            UPDATE exploit_target
            SET
              updated_at = updated_at,
              touched_at = NOW(3)
            WHERE
              id = new.object_id;
        END IF;
      	
        -- The following code is used to generate triggers for custom objects
        -- and the section is replicated for each incident defined
      WHEN new.object_type = 'incident' THEN
        IF IFNULL(@TOUCH_PARENT_incident, TRUE) THEN
            UPDATE incident
            SET
              updated_at = updated_at,
              touched_at = NOW(3)
            WHERE
              id = new.object_id;
        END IF;
      	
        -- The following code is used to generate triggers for custom objects
        -- and the section is replicated for each ttp defined
      WHEN new.object_type = 'ttp' THEN
        IF IFNULL(@TOUCH_PARENT_ttp, TRUE) THEN
            UPDATE ttp
            SET
              updated_at = updated_at,
              touched_at = NOW(3)
            WHERE
              id = new.object_id;
        END IF;
      
      ELSE
        BEGIN
        END;
    END CASE;
  END IF;

END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`threatquotient`@`localhost`*/ /*!50003 TRIGGER trig_tagged_objects_after_delete AFTER DELETE ON tagged_objects
FOR EACH ROW BEGIN

  INSERT INTO tagged_object_audit_log (tag_id, object_id, object_type, event_type, changed_by_source_id)
  VALUES (old.tag_id, old.object_id, old.object_type, 'removed', @owner_source_id);

  IF IFNULL(@TOUCH_PARENT_OBJECT, TRUE) THEN
    CASE
      WHEN old.object_type = 'adversary' THEN
        IF IFNULL(@TOUCH_PARENT_ADVERSARY, TRUE) THEN
            UPDATE adversaries
            SET
              updated_at = updated_at,
              touched_at = NOW(3)
            WHERE
              id = old.object_id;
        END IF;

      WHEN old.object_type = 'attachment' THEN
        IF IFNULL(@TOUCH_PARENT_ATTACHMENT, TRUE) THEN
            UPDATE attachments
            SET
              updated_at = updated_at,
              touched_at = NOW(3)
            WHERE
              id = old.object_id;
        END IF;

      WHEN old.object_type = 'event' THEN
        IF IFNULL(@TOUCH_PARENT_EVENT, TRUE) THEN
            UPDATE events
            SET
              updated_at = updated_at,
              touched_at = NOW(3)
            WHERE
              id = old.object_id;
        END IF;

      WHEN old.object_type = 'indicator' THEN
        IF IFNULL(@TOUCH_PARENT_INDICATOR, TRUE) THEN
            UPDATE indicators
            SET
              updated_at = updated_at,
              touched_at = NOW(3)
            WHERE
              id = old.object_id;
        END IF;

      WHEN old.object_type = 'signature' THEN
        IF IFNULL(@TOUCH_PARENT_SIGNATURE, TRUE) THEN
            UPDATE signatures
            SET
              updated_at = updated_at,
              touched_at = NOW(3)
            WHERE
              id = old.object_id;
        END IF;
      
        -- The following code is used to generate triggers for custom objects
        -- and the section is replicated for each campaign defined
      WHEN old.object_type = 'campaign' THEN
        IF IFNULL(@TOUCH_PARENT_campaign, TRUE) THEN
            UPDATE campaign
            SET
              updated_at = updated_at,
              touched_at = NOW(3)
            WHERE
              id = old.object_id;
        END IF;
      	
        -- The following code is used to generate triggers for custom objects
        -- and the section is replicated for each course_of_action defined
      WHEN old.object_type = 'course_of_action' THEN
        IF IFNULL(@TOUCH_PARENT_course_of_action, TRUE) THEN
            UPDATE course_of_action
            SET
              updated_at = updated_at,
              touched_at = NOW(3)
            WHERE
              id = old.object_id;
        END IF;
      	
        -- The following code is used to generate triggers for custom objects
        -- and the section is replicated for each exploit_target defined
      WHEN old.object_type = 'exploit_target' THEN
        IF IFNULL(@TOUCH_PARENT_exploit_target, TRUE) THEN
            UPDATE exploit_target
            SET
              updated_at = updated_at,
              touched_at = NOW(3)
            WHERE
              id = old.object_id;
        END IF;
      	
        -- The following code is used to generate triggers for custom objects
        -- and the section is replicated for each incident defined
      WHEN old.object_type = 'incident' THEN
        IF IFNULL(@TOUCH_PARENT_incident, TRUE) THEN
            UPDATE incident
            SET
              updated_at = updated_at,
              touched_at = NOW(3)
            WHERE
              id = old.object_id;
        END IF;
      	
        -- The following code is used to generate triggers for custom objects
        -- and the section is replicated for each ttp defined
      WHEN old.object_type = 'ttp' THEN
        IF IFNULL(@TOUCH_PARENT_ttp, TRUE) THEN
            UPDATE ttp
            SET
              updated_at = updated_at,
              touched_at = NOW(3)
            WHERE
              id = old.object_id;
        END IF;
      
      ELSE
        BEGIN
        END;
    END CASE;
  END IF;

END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-11-07  1:10:57
