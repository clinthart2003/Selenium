-- MySQL dump 10.16  Distrib 10.3.9-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: threatquotient2
-- ------------------------------------------------------
-- Server version	10.3.9-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `indicator_expiration_bumps`
--

DROP TABLE IF EXISTS `indicator_expiration_bumps`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `indicator_expiration_bumps` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `indicator_id` int(10) unsigned NOT NULL,
  `type` varchar(32) COLLATE utf8_unicode_ci NOT NULL COMMENT 'bump type',
  `object_id` int(10) unsigned NOT NULL COMMENT 'id of object related to bump',
  `creator_source_id` int(10) unsigned DEFAULT NULL COMMENT 'id of source requesting the bump',
  `days` int(11) DEFAULT NULL COMMENT 'bump amount in days',
  `prior_expires_at` datetime(3) DEFAULT NULL COMMENT 'indicator''s prior expires_at value',
  `expires_at` datetime(3) DEFAULT NULL COMMENT 'indicator''s new expires_at value',
  `created_at` datetime(3) NOT NULL DEFAULT current_timestamp(3) COMMENT 'time that the bump occurred',
  `updated_at` datetime(3) NOT NULL DEFAULT current_timestamp(3) ON UPDATE current_timestamp(3) COMMENT 'time that the bump occurred',
  PRIMARY KEY (`id`),
  KEY `indicator_expiration_bumps_indicator_id_index` (`indicator_id`),
  KEY `indicator_expiration_bumps_type_index` (`type`),
  KEY `indicator_expiration_bumps_object_id_index` (`object_id`),
  KEY `indicator_expiration_bumps_creator_source_id_index` (`creator_source_id`),
  KEY `indicator_expiration_bumps_updated_at_index` (`updated_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `indicator_expiration_bumps`
--
-- WHERE:  `indicator_id` in (SELECT id FROM `object_audit_id_lookup` WHERE key_column = 'indicator_id')

LOCK TABLES `indicator_expiration_bumps` WRITE;
/*!40000 ALTER TABLE `indicator_expiration_bumps` DISABLE KEYS */;
/*!40000 ALTER TABLE `indicator_expiration_bumps` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`threatquotient`@`localhost`*/ /*!50003 TRIGGER trig_indicator_expiration_bumps_before_insert BEFORE INSERT ON indicator_expiration_bumps
FOR EACH ROW indExpBmpBfrInsrt: BEGIN
  DECLARE expiresAt DATETIME;
  DECLARE currentDateTime DATETIME DEFAULT NOW(3);
  DECLARE expiredStatusId INTEGER UNSIGNED;
  DECLARE newExpiresAt DATETIME;

  SET expiredStatusId = fn_indicator_status_id('Expired');
  SET new.creator_source_id = @owner_source_id;
  SET new.prior_expires_at = indicator_calc_expiration(new.indicator_id); -- get current calculated expires_at

  -- set indicator to expire using source/type expiration rules if bump days is null
  IF new.days IS NULL
  THEN
    -- clear our current expires_at so we can recalculate without existing user bumps
    UPDATE indicators
    SET
      expires_at = NULL,
      expired_at = NULL,
      status_id  = IF(status_id = expiredStatusId, fn_indicator_status_id('Active'), status_id)
    WHERE
      deleted_at IS NULL
      AND id = new.indicator_id;

    -- recalculate expires_at using current source/type rules
    SET new.prior_expires_at = indicator_calc_expiration(new.indicator_id);
    SET newExpiresAt = IFNULL(new.prior_expires_at, NULL);

    IF newExpiresAt IS NOT NULL THEN
      UPDATE
        indicators
      SET
        expires_at = newExpiresAt,
        expired_at = NULL,
        status_id  = IF(status_id = expiredStatusId, fn_indicator_status_id('Active'), status_id)
      WHERE
        id = new.indicator_id
        AND deleted_at IS NULL
        AND IFNULL(expires_at, 0) < newExpiresAt;
    END IF;

  ELSE


    -- set indicator to never expire if bump days is 0
    IF new.days = 0
    THEN
      SET newExpiresAt = '0000-00-00 00:00:00';

      -- update indicator's expires_at column
      UPDATE
        indicators
      SET
        expires_at = newExpiresAt,
        expired_at = NULL,
        status_id  = IF(status_id = expiredStatusId, fn_indicator_status_id('Active'), status_id)
      WHERE
        id = new.indicator_id
        AND deleted_at IS NULL;

    ELSE
      SET newExpiresAt = IFNULL(new.prior_expires_at, DATE(currentDateTime) + INTERVAL 1 DAY);

      -- override expires_at
      IF newExpiresAt = '0000-00-00 00:00:00'
      THEN
        SET newExpiresAt = DATE(currentDateTime) + INTERVAL 1 DAY;
      END IF;

      SET newExpiresAt = newExpiresAt + INTERVAL new.days DAY; -- add bump days to current expires_at

      -- update indicator's expires_at column
      UPDATE
        indicators
      SET
        expires_at = newExpiresAt,
        expired_at = NULL,
        status_id  = IF(status_id = expiredStatusId, fn_indicator_status_id('Active'), status_id)
      WHERE
        id = new.indicator_id
        AND deleted_at IS NULL
        AND IFNULL(expires_at, 0) < newExpiresAt;

    END IF;
  END IF;

  -- if expires_at update was successful, reflect that in the bumps table
  IF ROW_COUNT() > 0
  THEN
    SET new.expires_at = newExpiresAt;
  END IF;

END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-11-07  1:10:58
