-- MySQL dump 10.16  Distrib 10.3.9-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: threatquotient2
-- ------------------------------------------------------
-- Server version	10.3.9-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `object_links`
--

DROP TABLE IF EXISTS `object_links`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `object_links` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `src_object_id` int(10) unsigned NOT NULL,
  `src_type` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `dest_object_id` int(10) unsigned NOT NULL,
  `dest_type` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `updated_at` datetime(3) NOT NULL DEFAULT current_timestamp(3) ON UPDATE current_timestamp(3),
  `deleted_at` datetime(3) DEFAULT NULL,
  `src_deleted` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `dest_deleted` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `sync_hash` char(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `object_to_object_idx` (`src_object_id`,`src_type`,`dest_object_id`,`dest_type`),
  KEY `object_links_src_type_index` (`src_type`),
  KEY `object_links_src_object_id_index` (`src_object_id`),
  KEY `object_links_dest_type_index` (`dest_type`),
  KEY `object_links_dest_object_id_index` (`dest_object_id`),
  KEY `object_links_deleted_at_index` (`deleted_at`),
  KEY `object_links_src_deleted_index` (`src_deleted`),
  KEY `object_links_dest_deleted_index` (`dest_deleted`),
  KEY `object_links_updated_at_index` (`updated_at`),
  KEY `object_links_src_object_type_id_index` (`src_type`,`src_object_id`),
  KEY `object_links_dest_object_type_id_index` (`dest_type`,`dest_object_id`),
  KEY `sync_hash_index` (`sync_hash`)
) ENGINE=InnoDB AUTO_INCREMENT=53636 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `object_links`
--
-- WHERE:  `dest_type`='indicator' AND `dest_object_id` IN (SELECT id FROM `object_audit_id_lookup` WHERE key_column = 'indicator_id')

LOCK TABLES `object_links` WRITE;
/*!40000 ALTER TABLE `object_links` DISABLE KEYS */;
INSERT  IGNORE INTO `object_links` VALUES (19902,97060,'indicator',97061,'indicator','2019-11-07 00:22:03.967','2019-11-07 00:22:03.967',NULL,'N','N','920a5b3499a8c3a3498300dd7604f0a7'),(19590,94232,'indicator',94239,'indicator','2019-11-07 00:21:40.535','2019-11-07 00:21:40.535',NULL,'N','N','bf8aebea8a39b5d853acc64f475d874d'),(19591,94236,'indicator',94239,'indicator','2019-11-07 00:21:40.535','2019-11-07 00:21:40.535',NULL,'N','N','d86b6e8a0433389433a2b80dbaec60c2'),(19592,94231,'indicator',94239,'indicator','2019-11-07 00:21:40.535','2019-11-07 00:21:40.535',NULL,'N','N','29aa91971357603296fc9a6f3f48bd81'),(19593,94238,'indicator',94239,'indicator','2019-11-07 00:21:40.535','2019-11-07 00:21:40.535',NULL,'N','N','9bf08d7b832723dd4584822928cc9b57'),(31610,146234,'indicator',7249,'indicator','2019-11-07 00:30:46.541','2019-11-07 00:30:46.541',NULL,'N','N','32419ab6d587410130bbb7fd5537719c');
/*!40000 ALTER TABLE `object_links` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`threatquotient`@`localhost`*/ /*!50003 TRIGGER trig_object_links_before_insert BEFORE INSERT ON object_links
FOR EACH ROW BEGIN
  DECLARE srcPos INTEGER;
  DECLARE destPos INTEGER;
  DECLARE srcType VARCHAR(20);
  DECLARE srcObjId INTEGER UNSIGNED;
  DECLARE destType VARCHAR(20);
  DECLARE destObjId INTEGER UNSIGNED;
  DECLARE srcObjectTable VARCHAR(255);
  DECLARE destObjectTable VARCHAR(255);
  DECLARE srcObjectHash CHAR(32);
  DECLARE destObjectHash CHAR(32);

  SELECT
    find_in_set(NEW.src_type, fn_tq_objectlink_precedence()),
    find_in_set(NEW.dest_type, fn_tq_objectlink_precedence())
  INTO
    srcPos,
    destPos;

  IF srcPos > destPos THEN
    SET
      srcType = NEW.src_type,
      srcObjId = NEW.src_object_id,
      destType = NEW.dest_type,
      destObjId = NEW.dest_object_id;
    SET
      NEW.dest_type = srcType,
      NEW.dest_object_id = srcObjId,
      NEW.src_type = destType,
      NEW.src_object_id = destObjId;
  END IF;

  SELECT fn_tq_type_to_table(NEW.src_type) INTO srcObjectTable;
  SELECT fn_tq_type_to_table(NEW.dest_type) INTO destObjectTable;

  SET NEW.sync_hash = MD5(CONCAT(NEW.src_object_id, NEW.src_type, NEW.dest_object_id, NEW.dest_type));

END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`threatquotient`@`localhost`*/ /*!50003 TRIGGER trig_object_links_after_insert AFTER INSERT ON object_links
FOR EACH ROW BEGIN

  INSERT INTO object_link_audit_log (object_link_id, event_type, field, run_uuid, changed_by_source_id)
  VALUES (NEW.id, 'linked', 'link', fn_uuid_to_binary(@CONNECTOR_RUN_UUID), @OWNER_SOURCE_ID);

  IF @CONNECTOR_RUN_UUID IS NOT NULL
  THEN
    INSERT INTO
      connector_run_objects (run_uuid, object_id, object_type)
    VALUES
      (fn_uuid_to_binary(@CONNECTOR_RUN_UUID), NEW.id, 'object_links');
  END IF;

  IF IFNULL(@SCORE_INDICATOR, TRUE) THEN
    IF NEW.src_type = 'indicator' THEN
      IF fn_indicator_relation_scorable(NEW.dest_type, NEW.dest_object_id) <> 'N' THEN
        SET @TOUCH_PARENT_INDICATOR_OLD = @TOUCH_PARENT_INDICATOR;
        SET @TOUCH_PARENT_INDICATOR = FALSE;

        INSERT
        INTO
          indicator_scores
        (
          indicator_id,
          score_config_hash
        )
        VALUES
        (
          NEW.src_object_id,
          'pending_score'
        )
        ON DUPLICATE KEY
        UPDATE
          score_config_hash = 'pending_score';

        SET @TOUCH_PARENT_INDICATOR = @TOUCH_PARENT_INDICATOR_OLD;
      END IF;
    END IF;
  END IF;

  INSERT INTO object_relations (object_type, object_id, relation_type, relation_ids_json)
  VALUES
    (NEW.src_type, NEW.src_object_id, NEW.dest_type, JSON_ARRAY(NEW.dest_object_id)),
    (NEW.dest_type, NEW.dest_object_id, NEW.src_type, JSON_ARRAY(NEW.src_object_id))
  ON DUPLICATE KEY UPDATE
    relation_ids_json = IF(
      relation_ids_json <> '[]' AND NOT JSON_CONTAINS(relation_ids_json, JSON_EXTRACT(VALUES(relation_ids_json), '$[0]')),
      JSON_ARRAY_APPEND(relation_ids_json, '$', JSON_EXTRACT(VALUES(relation_ids_json), '$[0]')),
      VALUES(relation_ids_json)
    );

    
    IF IFNULL(@TOUCH_PARENT_INDICATOR, TRUE)
    THEN
        IF NEW.src_type = 'indicator'
        THEN
          UPDATE
            `indicators`
          SET
            updated_at = updated_at,
            touched_at = NOW(3)
          WHERE
            id = NEW.src_object_id;
        END IF;
      
        IF NEW.dest_type = 'indicator'
        THEN
          UPDATE
            `indicators`
          SET
            updated_at = updated_at,
            touched_at = NOW(3)
          WHERE
            id = NEW.dest_object_id;
        END IF;
    END IF;
    
    IF IFNULL(@TOUCH_PARENT_ADVERSARY, TRUE)
    THEN
        IF NEW.src_type = 'adversary'
        THEN
          UPDATE
            `adversaries`
          SET
            updated_at = updated_at,
            touched_at = NOW(3)
          WHERE
            id = NEW.src_object_id;
        END IF;
      
        IF NEW.dest_type = 'adversary'
        THEN
          UPDATE
            `adversaries`
          SET
            updated_at = updated_at,
            touched_at = NOW(3)
          WHERE
            id = NEW.dest_object_id;
        END IF;
    END IF;
    
    IF IFNULL(@TOUCH_PARENT_EVENT, TRUE)
    THEN
        IF NEW.src_type = 'event'
        THEN
          UPDATE
            `events`
          SET
            updated_at = updated_at,
            touched_at = NOW(3)
          WHERE
            id = NEW.src_object_id;
        END IF;
      
        IF NEW.dest_type = 'event'
        THEN
          UPDATE
            `events`
          SET
            updated_at = updated_at,
            touched_at = NOW(3)
          WHERE
            id = NEW.dest_object_id;
        END IF;
    END IF;
    
    IF IFNULL(@TOUCH_PARENT_ATTACHMENT, TRUE)
    THEN
        IF NEW.src_type = 'attachment'
        THEN
          UPDATE
            `attachments`
          SET
            updated_at = updated_at,
            touched_at = NOW(3)
          WHERE
            id = NEW.src_object_id;
        END IF;
      
        IF NEW.dest_type = 'attachment'
        THEN
          UPDATE
            `attachments`
          SET
            updated_at = updated_at,
            touched_at = NOW(3)
          WHERE
            id = NEW.dest_object_id;
        END IF;
    END IF;
    
    IF IFNULL(@TOUCH_PARENT_SIGNATURE, TRUE)
    THEN
        IF NEW.src_type = 'signature'
        THEN
          UPDATE
            `signatures`
          SET
            updated_at = updated_at,
            touched_at = NOW(3)
          WHERE
            id = NEW.src_object_id;
        END IF;
      
        IF NEW.dest_type = 'signature'
        THEN
          UPDATE
            `signatures`
          SET
            updated_at = updated_at,
            touched_at = NOW(3)
          WHERE
            id = NEW.dest_object_id;
        END IF;
    END IF;
    
    IF IFNULL(@TOUCH_PARENT_CAMPAIGN, TRUE)
    THEN
        IF NEW.src_type = 'campaign'
        THEN
          UPDATE
            `campaign`
          SET
            updated_at = updated_at,
            touched_at = NOW(3)
          WHERE
            id = NEW.src_object_id;
        END IF;
      
        IF NEW.dest_type = 'campaign'
        THEN
          UPDATE
            `campaign`
          SET
            updated_at = updated_at,
            touched_at = NOW(3)
          WHERE
            id = NEW.dest_object_id;
        END IF;
    END IF;
    
    IF IFNULL(@TOUCH_PARENT_COURSE_OF_ACTION, TRUE)
    THEN
        IF NEW.src_type = 'course_of_action'
        THEN
          UPDATE
            `course_of_action`
          SET
            updated_at = updated_at,
            touched_at = NOW(3)
          WHERE
            id = NEW.src_object_id;
        END IF;
      
        IF NEW.dest_type = 'course_of_action'
        THEN
          UPDATE
            `course_of_action`
          SET
            updated_at = updated_at,
            touched_at = NOW(3)
          WHERE
            id = NEW.dest_object_id;
        END IF;
    END IF;
    
    IF IFNULL(@TOUCH_PARENT_EXPLOIT_TARGET, TRUE)
    THEN
        IF NEW.src_type = 'exploit_target'
        THEN
          UPDATE
            `exploit_target`
          SET
            updated_at = updated_at,
            touched_at = NOW(3)
          WHERE
            id = NEW.src_object_id;
        END IF;
      
        IF NEW.dest_type = 'exploit_target'
        THEN
          UPDATE
            `exploit_target`
          SET
            updated_at = updated_at,
            touched_at = NOW(3)
          WHERE
            id = NEW.dest_object_id;
        END IF;
    END IF;
    
    IF IFNULL(@TOUCH_PARENT_INCIDENT, TRUE)
    THEN
        IF NEW.src_type = 'incident'
        THEN
          UPDATE
            `incident`
          SET
            updated_at = updated_at,
            touched_at = NOW(3)
          WHERE
            id = NEW.src_object_id;
        END IF;
      
        IF NEW.dest_type = 'incident'
        THEN
          UPDATE
            `incident`
          SET
            updated_at = updated_at,
            touched_at = NOW(3)
          WHERE
            id = NEW.dest_object_id;
        END IF;
    END IF;
    
    IF IFNULL(@TOUCH_PARENT_TTP, TRUE)
    THEN
        IF NEW.src_type = 'ttp'
        THEN
          UPDATE
            `ttp`
          SET
            updated_at = updated_at,
            touched_at = NOW(3)
          WHERE
            id = NEW.src_object_id;
        END IF;
      
        IF NEW.dest_type = 'ttp'
        THEN
          UPDATE
            `ttp`
          SET
            updated_at = updated_at,
            touched_at = NOW(3)
          WHERE
            id = NEW.dest_object_id;
        END IF;
    END IF;


END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`threatquotient`@`localhost`*/ /*!50003 TRIGGER trig_object_links_before_update BEFORE UPDATE ON object_links
FOR EACH ROW BEGIN
  DECLARE srcPos INTEGER;
  DECLARE destPos INTEGER;
  DECLARE srcType VARCHAR(20);
  DECLARE srcObjId INTEGER UNSIGNED;
  DECLARE destType VARCHAR(20);
  DECLARE destObjId INTEGER UNSIGNED;

  SELECT
    find_in_set(NEW.src_type, fn_tq_objectlink_precedence()),
    find_in_set(NEW.dest_type, fn_tq_objectlink_precedence())
  INTO
   srcPos,
   destPos;

  IF srcPos > destPos THEN
    SET
      srcType = NEW.src_type,
      srcObjId = NEW.src_object_id,
      destType = NEW.dest_type,
      destObjId = NEW.dest_object_id;
    SET
      NEW.dest_type = srcType,
      NEW.dest_object_id = srcObjId,
      NEW.src_type = destType,
      NEW.src_object_id = destObjId;
  END IF;

  IF
    OLD.src_object_id <> NEW.src_object_id OR
    OLD.src_type <> NEW.src_type OR
    OLD.dest_object_id <> NEW.dest_object_id OR
    OLD.dest_type <> NEW.dest_type
  THEN
    SET NEW.sync_hash = MD5(CONCAT(NEW.src_object_id, NEW.src_type, NEW.dest_object_id, NEW.dest_type));
  END IF;

END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`threatquotient`@`localhost`*/ /*!50003 TRIGGER trig_object_links_after_update AFTER UPDATE ON object_links
FOR EACH ROW BEGIN

  DECLARE connectorRunUuid BINARY(16);
  DECLARE srcRemove VARCHAR(32);
  DECLARE destRemove VARCHAR(32);

  IF IFNULL(OLD.deleted_at, '') <> IFNULL(new.deleted_at, '')
  THEN
    INSERT INTO
      object_link_audit_log (object_link_id, event_type, field, new_value, run_uuid, changed_by_source_id)
    VALUES
      (NEW.id, IF(NEW.deleted_at IS NOT NULL, 'unlinked', 'linked'), 'deleted_at', IFNULL(NEW.deleted_at, ''),
        fn_uuid_to_binary(@CONNECTOR_RUN_UUID), @OWNER_SOURCE_ID)
    ON DUPLICATE KEY UPDATE
      event_type = VALUES(event_type),
      new_value = VALUES(new_value),
      changed_by_source_id = VALUES(changed_by_source_id);

    IF NEW.deleted_at IS NULL
    THEN
      INSERT INTO object_relations (object_type, object_id, relation_type, relation_ids_json)
      VALUES
        (NEW.src_type, NEW.src_object_id, NEW.dest_type, JSON_ARRAY(NEW.dest_object_id)),
        (NEW.dest_type, NEW.dest_object_id, NEW.src_type, JSON_ARRAY(NEW.src_object_id))
      ON DUPLICATE KEY UPDATE
          relation_ids_json = IF(
            relation_ids_json <> '[]' AND NOT JSON_CONTAINS(relation_ids_json, JSON_EXTRACT(VALUES(relation_ids_json), '$[0]')),
            JSON_ARRAY_APPEND(relation_ids_json, '$', JSON_EXTRACT(VALUES(relation_ids_json), '$[0]')),
            VALUES(relation_ids_json)
          );

    ELSE
      SELECT JSON_SEARCH(relation_ids_json, 'one', NEW.src_object_id) INTO srcRemove
      FROM object_relations
      WHERE object_type = NEW.dest_type
        AND object_id = NEW.dest_object_id
        AND relation_type = NEW.src_type;

      IF IFNULL(srcRemove, '') <> ''
      THEN
        UPDATE object_relations
          SET relation_ids_json = JSON_REMOVE(relation_ids_json, JSON_UNQUOTE(srcRemove))
          WHERE object_type = NEW.dest_type
            AND object_id = NEW.dest_object_id
            AND relation_type = NEW.src_type;
      END IF;

      SELECT JSON_SEARCH(relation_ids_json, 'one', NEW.dest_object_id) INTO destRemove
      FROM object_relations
      WHERE object_type = NEW.src_type
        AND object_id = NEW.src_object_id
        AND relation_type = NEW.dest_type;

      IF IFNULL(destRemove, '') <> ''
      THEN
        UPDATE object_relations
          SET relation_ids_json = JSON_REMOVE(relation_ids_json, JSON_UNQUOTE(destRemove))
          WHERE object_type = NEW.src_type
            AND object_id = NEW.src_object_id
            AND relation_type = NEW.dest_type;
      END IF;

    END IF;
  END IF;

  IF OLD.src_deleted <> NEW.src_deleted
  THEN
    IF NEW.deleted_at IS NULL
    THEN
      INSERT INTO
        object_link_audit_log (object_link_id, event_type, field, new_value, run_uuid, changed_by_source_id)
      VALUES
        (NEW.id, IF(NEW.src_deleted = 'Y', 'UnlinkedViaDelete', 'LinkedRestore'), 'src_deleted', NEW.src_object_id,
          fn_uuid_to_binary(@CONNECTOR_RUN_UUID), @OWNER_SOURCE_ID)
      ON DUPLICATE KEY UPDATE
        event_type = VALUES(event_type),
        new_value = VALUES(new_value),
        changed_by_source_id = VALUES(changed_by_source_id);
    END IF;
  END IF;

  IF OLD.dest_deleted <> NEW.dest_deleted
  THEN
    IF NEW.deleted_at IS NULL
    THEN
      INSERT INTO
        object_link_audit_log (object_link_id, event_type, field, new_value, run_uuid, changed_by_source_id)
      VALUES
        (NEW.id, IF(NEW.dest_deleted = 'Y', 'UnlinkedViaDelete', 'LinkedRestore'), 'dest_deleted', NEW.dest_object_id,
         fn_uuid_to_binary(@CONNECTOR_RUN_UUID), @OWNER_SOURCE_ID)
      ON DUPLICATE KEY UPDATE
        event_type = VALUES(event_type),
        new_value = VALUES(new_value),
        changed_by_source_id = VALUES(changed_by_source_id);
    END IF;
  END IF;

  IF @CONNECTOR_RUN_UUID IS NOT NULL
  THEN
    SELECT
      run_uuid
    INTO
      connectorRunUuid
    FROM
      connector_run_objects
    WHERE
      run_uuid = fn_uuid_to_binary(@CONNECTOR_RUN_UUID) AND object_id = NEW.id AND object_type = 'object_links';

    IF ISNULL(connectorRunUuid)
    THEN
      INSERT INTO
        connector_run_objects (run_uuid, object_id, object_type)
      VALUES
        (fn_uuid_to_binary(@CONNECTOR_RUN_UUID), NEW.id, 'object_links');
    END IF;
  END IF;

  IF IFNULL(@SCORE_INDICATOR, TRUE) THEN
    IF NEW.src_type = 'indicator'
    AND (
      IFNULL(OLD.deleted_at, '') <> IFNULL(NEW.deleted_at, '')
      OR OLD.src_deleted <> NEW.src_deleted
      OR OLD.dest_deleted <> NEW.dest_deleted
    ) THEN
      IF fn_indicator_relation_scorable(NEW.dest_type, NEW.dest_object_id) <> 'N' THEN
        SET @TOUCH_PARENT_INDICATOR_OLD = @TOUCH_PARENT_INDICATOR;
        SET @TOUCH_PARENT_INDICATOR = FALSE;

        INSERT
        INTO
          indicator_scores
        (
          indicator_id,
          score_config_hash
        )
        VALUES
        (
          NEW.src_object_id,
          'pending_score'
        )
        ON DUPLICATE KEY
        UPDATE
          score_config_hash = 'pending_score';

        SET @TOUCH_PARENT_INDICATOR = @TOUCH_PARENT_INDICATOR_OLD;
      END IF;
    END IF;
  END IF;

    
    IF IFNULL(@TOUCH_PARENT_INDICATOR, TRUE)
    THEN
        IF NEW.src_type = 'indicator'
        THEN
          UPDATE
            `indicators`
          SET
            updated_at = updated_at,
            touched_at = NOW(3)
          WHERE
            id = NEW.src_object_id;
        END IF;
      
        IF NEW.dest_type = 'indicator'
        THEN
          UPDATE
            `indicators`
          SET
            updated_at = updated_at,
            touched_at = NOW(3)
          WHERE
            id = NEW.dest_object_id;
        END IF;
    END IF;
    
    IF IFNULL(@TOUCH_PARENT_ADVERSARY, TRUE)
    THEN
        IF NEW.src_type = 'adversary'
        THEN
          UPDATE
            `adversaries`
          SET
            updated_at = updated_at,
            touched_at = NOW(3)
          WHERE
            id = NEW.src_object_id;
        END IF;
      
        IF NEW.dest_type = 'adversary'
        THEN
          UPDATE
            `adversaries`
          SET
            updated_at = updated_at,
            touched_at = NOW(3)
          WHERE
            id = NEW.dest_object_id;
        END IF;
    END IF;
    
    IF IFNULL(@TOUCH_PARENT_EVENT, TRUE)
    THEN
        IF NEW.src_type = 'event'
        THEN
          UPDATE
            `events`
          SET
            updated_at = updated_at,
            touched_at = NOW(3)
          WHERE
            id = NEW.src_object_id;
        END IF;
      
        IF NEW.dest_type = 'event'
        THEN
          UPDATE
            `events`
          SET
            updated_at = updated_at,
            touched_at = NOW(3)
          WHERE
            id = NEW.dest_object_id;
        END IF;
    END IF;
    
    IF IFNULL(@TOUCH_PARENT_ATTACHMENT, TRUE)
    THEN
        IF NEW.src_type = 'attachment'
        THEN
          UPDATE
            `attachments`
          SET
            updated_at = updated_at,
            touched_at = NOW(3)
          WHERE
            id = NEW.src_object_id;
        END IF;
      
        IF NEW.dest_type = 'attachment'
        THEN
          UPDATE
            `attachments`
          SET
            updated_at = updated_at,
            touched_at = NOW(3)
          WHERE
            id = NEW.dest_object_id;
        END IF;
    END IF;
    
    IF IFNULL(@TOUCH_PARENT_SIGNATURE, TRUE)
    THEN
        IF NEW.src_type = 'signature'
        THEN
          UPDATE
            `signatures`
          SET
            updated_at = updated_at,
            touched_at = NOW(3)
          WHERE
            id = NEW.src_object_id;
        END IF;
      
        IF NEW.dest_type = 'signature'
        THEN
          UPDATE
            `signatures`
          SET
            updated_at = updated_at,
            touched_at = NOW(3)
          WHERE
            id = NEW.dest_object_id;
        END IF;
    END IF;
    
    IF IFNULL(@TOUCH_PARENT_CAMPAIGN, TRUE)
    THEN
        IF NEW.src_type = 'campaign'
        THEN
          UPDATE
            `campaign`
          SET
            updated_at = updated_at,
            touched_at = NOW(3)
          WHERE
            id = NEW.src_object_id;
        END IF;
      
        IF NEW.dest_type = 'campaign'
        THEN
          UPDATE
            `campaign`
          SET
            updated_at = updated_at,
            touched_at = NOW(3)
          WHERE
            id = NEW.dest_object_id;
        END IF;
    END IF;
    
    IF IFNULL(@TOUCH_PARENT_COURSE_OF_ACTION, TRUE)
    THEN
        IF NEW.src_type = 'course_of_action'
        THEN
          UPDATE
            `course_of_action`
          SET
            updated_at = updated_at,
            touched_at = NOW(3)
          WHERE
            id = NEW.src_object_id;
        END IF;
      
        IF NEW.dest_type = 'course_of_action'
        THEN
          UPDATE
            `course_of_action`
          SET
            updated_at = updated_at,
            touched_at = NOW(3)
          WHERE
            id = NEW.dest_object_id;
        END IF;
    END IF;
    
    IF IFNULL(@TOUCH_PARENT_EXPLOIT_TARGET, TRUE)
    THEN
        IF NEW.src_type = 'exploit_target'
        THEN
          UPDATE
            `exploit_target`
          SET
            updated_at = updated_at,
            touched_at = NOW(3)
          WHERE
            id = NEW.src_object_id;
        END IF;
      
        IF NEW.dest_type = 'exploit_target'
        THEN
          UPDATE
            `exploit_target`
          SET
            updated_at = updated_at,
            touched_at = NOW(3)
          WHERE
            id = NEW.dest_object_id;
        END IF;
    END IF;
    
    IF IFNULL(@TOUCH_PARENT_INCIDENT, TRUE)
    THEN
        IF NEW.src_type = 'incident'
        THEN
          UPDATE
            `incident`
          SET
            updated_at = updated_at,
            touched_at = NOW(3)
          WHERE
            id = NEW.src_object_id;
        END IF;
      
        IF NEW.dest_type = 'incident'
        THEN
          UPDATE
            `incident`
          SET
            updated_at = updated_at,
            touched_at = NOW(3)
          WHERE
            id = NEW.dest_object_id;
        END IF;
    END IF;
    
    IF IFNULL(@TOUCH_PARENT_TTP, TRUE)
    THEN
        IF NEW.src_type = 'ttp'
        THEN
          UPDATE
            `ttp`
          SET
            updated_at = updated_at,
            touched_at = NOW(3)
          WHERE
            id = NEW.src_object_id;
        END IF;
      
        IF NEW.dest_type = 'ttp'
        THEN
          UPDATE
            `ttp`
          SET
            updated_at = updated_at,
            touched_at = NOW(3)
          WHERE
            id = NEW.dest_object_id;
        END IF;
    END IF;


END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-11-07  1:10:57
