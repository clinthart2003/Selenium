-- MySQL dump 10.16  Distrib 10.3.9-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: threatquotient2
-- ------------------------------------------------------
-- Server version	10.3.9-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `indicator_source_audit_log`
--

DROP TABLE IF EXISTS `indicator_source_audit_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `indicator_source_audit_log` (
  `indicator_source_id` int(10) unsigned NOT NULL,
  `event_type` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `field` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `new_value` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `run_uuid` binary(16) DEFAULT NULL,
  `changed_by_source_id` int(10) unsigned DEFAULT NULL,
  `changed_at` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  PRIMARY KEY (`indicator_source_id`,`changed_at`,`field`),
  KEY `indicator_source_audit_log_indicator_source_id_index` (`indicator_source_id`),
  KEY `indicator_source_audit_log_event_type_index` (`event_type`),
  KEY `indicator_source_audit_log_field_index` (`field`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `indicator_source_audit_log`
--
-- WHERE:  `indicator_source_id` in (SELECT id FROM `object_audit_id_lookup` WHERE key_column = 'indicator_source_id')

LOCK TABLES `indicator_source_audit_log` WRITE;
/*!40000 ALTER TABLE `indicator_source_audit_log` DISABLE KEYS */;
INSERT  IGNORE INTO `indicator_source_audit_log` VALUES (109065,'added','source_id','9',NULL,8,'2019-11-07 00:22:32.358'),(105693,'added','source_id','9',NULL,8,'2019-11-07 00:22:03.561'),(105693,'added','tlp_id','3',NULL,8,'2019-11-07 00:22:03.561'),(102780,'added','source_id','9',NULL,8,'2019-11-07 00:21:39.915'),(102780,'added','tlp_id','4',NULL,8,'2019-11-07 00:21:39.915'),(7045,'added','published_at','2018-01-02 14:36:19.000',NULL,8,'2019-11-07 00:08:54.909'),(7045,'added','source_id','9',NULL,8,'2019-11-07 00:08:54.909'),(7045,'added','tlp_id','3',NULL,8,'2019-11-07 00:08:54.909'),(161085,'added','published_at','2019-10-18 09:44:04.000','�\0����\r�>b�',20,'2019-11-07 00:30:25.685'),(161085,'added','source_id','20','�\0����\r�>b�',20,'2019-11-07 00:30:25.685'),(7093,'added','source_id','9',NULL,8,'2019-11-07 00:08:54.909'),(7093,'added','tlp_id','3',NULL,8,'2019-11-07 00:08:54.909'),(7076,'added','source_id','9',NULL,8,'2019-11-07 00:08:54.909'),(7076,'added','tlp_id','3',NULL,8,'2019-11-07 00:08:54.909');
/*!40000 ALTER TABLE `indicator_source_audit_log` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-11-07  1:10:57
